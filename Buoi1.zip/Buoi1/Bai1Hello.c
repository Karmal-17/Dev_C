#include <stdio.h>
int main(){
	printf("Xin ch�o xb");
	return 0;
}

