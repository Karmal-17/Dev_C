//Tinh Tong Cac So Tu 1 Den n
#include <stdio.h>

int main(){
	int i, n, tong = 0;
	printf("Nhap so nguyen n: ");
	scanf("%d",&n);
	for ( i = 1;i <= n;i++){
			tong += i;
	}

    printf("Tong Cac so tu 1 den %d la: %d\n ", n, tong);
    return 0;
    }
    
