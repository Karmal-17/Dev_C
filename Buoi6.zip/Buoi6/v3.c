#include <stdio.h>

int main() {
    int n, i;
    
    // Nh?p s? nguy�n n
    printf("Nhap so nguyen n: ");
    scanf("%d", &n);
    
    // In danh s�ch c�c s? ch?n
    printf("Cac so chan trong day tu 1 den %d la:\n", n);
    for (i = 1; i <= n; i++) {
        if (i % 2 == 0) { // Ki?m tra s? ch?n
            printf("%d ", i);
        }
    }
    
    // In danh s�ch c�c s? l?
    printf("\nCac so le trong day tu 1 den %d la:\n", n);
    for (i = 1; i <= n; i++) {
        if (i % 2 != 0) { // Ki?m tra s? l?
            printf("%d ", i);
        }
    }
    
    return 0;
}

