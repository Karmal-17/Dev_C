#include <stdio.h>

int main(){
	int n, i, chan=0, le=0;
	printf("nhap n: ");
	scanf("%d", &n);
	
	for(i=1; i<=n; i++){
		if(i % 2==0){
			chan++;
	}
	else{
	  le++;
	}
  }	
  printf("luong so chan tu 1 den %d l�: %d\n", n, chan);
  printf("luong so le tu 1 den %d l�: %d\n", n, le);	
}
