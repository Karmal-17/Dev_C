#include <stdio.h>

int main() {
    int gioVao, gioRa, soGio;
    float tongTien = 0;

    // Nh?p gi? v�o v� gi? ra
    printf("Nhap gio vao (12 - 23): ");
    scanf("%d", &gioVao);
    printf("Nhap gio ra (12 - 23): ");
    scanf("%d", &gioRa);

    // Ki?m tra gi? h?p l?
    if (gioVao < 12 || gioVao > 23 || gioRa < 12 || gioRa > 23 || gioRa <= gioVao) {
        printf("Gio nhap khong hop le. Vui long nhap lai!\n");
        return 1;
    }

    // T�nh s? gi?
    soGio = gioRa - gioVao;

    // T�nh ti?n
    if (soGio <= 3) {
        tongTien = soGio * 150; // Gi� 150/gi? cho 3 gi? d?u
    } else {
        tongTien = 3 * 150; // Gi� c?a 3 gi? d?u
        tongTien += (soGio - 3) * 150 * 0.7; // C�c gi? ti?p theo gi?m 30%
    }

    // Gi?m 10% n?u gi? v�o t? 14h d?n 17h
    if (gioVao >= 14 && gioVao <= 17) {
        tongTien *= 0.9;
    }

    // In k?t qu?
    printf("Tong tien can thanh toan: %.2f VND\n", tongTien);

    return 0;
}

