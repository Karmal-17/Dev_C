#include <stdio.h>
//B�i t?p: Nh?p v�o s? nguy�n n v� d?m s? lu?ng s? ch?n v� s? l? trong d�y s? t? 1 d?n n
int main(){
	int n,i;
	int sole = 0;
	int sochan = 0;
	printf("Nhap So Nguyen n: ");
	scanf("%d",&n);
	printf("\n Ban Vua Nhap So Nguyen n La: %d\n",n);
	for (i = 1;i <= n;i++){
	if (i % 2 == 0){
	sochan += 1 ;
	} else {
	    sole += 1 ;
	}
	}
	printf("\n  Cac So Chan Tu 1 Den %d la: %d\n",n,sochan);
	printf("\n  Cac So Le Tu 1 Den %d la: %d\n ",n,sole);
	return 0;	
			}
	
