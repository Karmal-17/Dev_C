#include <stdio.h>

int main(){
	int i , n, sochan = 0, sole = 0;
	printf("Nhap So Nguyen n: ");
	scanf("%d",&n);
	printf("\n Ban Vua Nhap So Nguyen n: %d",n);
    printf("\n Cac So Chan Trong Day Tu 0 Den %d La: ",n);
    printf("\n Cac So Le Trong Day So Tu 0 Den %d La:  ",n);
	for (i = 0;i <= n;i++){
		    if (i % 2 == 0){
		    	
		    	printf("%d ",i);
		sochan += 1;
	} else {
		
		printf("%d ",i);
		sole += 1;
			}
        }
        	printf("\n Luong Cac So Chan Tu 0 den %d La: %d ",n,sochan);
        	printf("\n Luong Cac So Le Tu 0 Den %d La: %d ",n,sole);
        	return 0;
}
