#include <stdio.h>

int main(){
	int i, n;
	printf("Nhap So Nguyen n: ");
	scanf("%d",&n);
	printf("\n So Nguyen Ban Vua Nhap La: %d",n);
	for (i = 1;i <= 10;i++){
		
			printf("\n Bang Cuu Chuong Cua So %d la : ",n);
			printf("%d * %d = %d\n",n,i,n * i);	
		}
		return 0;
		}
