#include <stdio.h>

int main(){
	int n, i, chan = 0, le = 0;
	printf("Xin moi nhap bat ki mot so nguyen n: ");
	scanf("%d", &n);
	printf("So luong cac so chan tu 0 den %d l�: ", n);
	
	for(i = 0; i <= n; i++){
		if(i % 2 == 0){
			printf("%d", i);
			chan++;	
		}
    }
	printf("\nSo luong cac so le tu 0 den %d l�: ", n);
	for(i = 0; i <= n; i++){
		if(i % 2 != 0){
			printf("%d", i);
			le++;
		}
			
	}
	printf("\nSo luong so chan tu 0 den %d l�: %d", n, chan);
	printf("\nSo luong so le tu 0 den %d l�: %d", n, le);
	}
