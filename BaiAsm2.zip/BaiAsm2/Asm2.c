#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void HienThiMeNu (){
	printf("\n ======= Hien Thi MeNu Chinh Cua Chuong Trinh =======");
	printf("\n + 1.Kiem Tra So Nguyen.                            +");
	printf("\n + 2.Tim Uoc Chung Va Boi So Chung Cua Hai So.      +");
	printf("\n + 3.Truong Trinh Tinh Ten Cho Quan Karaoke.        +");
	printf("\n + 4.Tinh Tien Dien.                                +");
	printf("\n + 5.Doi Tien.                                      +");
	printf("\n + 6.Tinh Lai Xuat Ngan Hang Vay Tra Gop.           +");
	printf("\n + 7.Vay Tien Mua Xe.                               +");
	printf("\n + 8.Sap Xep Thong Tin Sinh Vien.                   +");
	printf("\n + 9.Game Poly - Lott.                              +");
	printf("\n + 10.Tinh Phan So.                                 +");
	printf("\n + 0.Thoat Truong Trinh.                           +");
	printf("\n ====================================================");	
}

void HienThi1() {
    printf("\n ===== Kiem Tra So Nguyen ======");
    printf("\n + 1. Xac Dinh So Nguyen.       +");
    printf("\n + 2. Xac Dinh So Nguyen To.    +");
    printf("\n + 3. Xac Dinh So Chinh Phuong. +");
    printf("\n + 4. Xac Dinh Ca.              +");
    printf("\n + 0. Thoat Chuong Trinh.       +");
    printf("\n ===============================");
}

void SuLyHienThi1() {
    int LuaChon1;
    do {
        system("cls");
        HienThi1();
        printf("\n Nhap Lua Chon Cua Ban: ");
        scanf("%d", &LuaChon1);
        switch (LuaChon1) {
            case 1: { 
                printf("\n 1. Xac Dinh So Nguyen.");
                float a;
                printf("\n Vui Long Nhap So (Am Hoac Duong): ");
                scanf("%f", &a);
                if (a == (int)a) { // Ki?m tra n?u a l� s? nguy�n
                    if (a > 0) {
                        printf("\n So %d Ban Vua Nhap La So Nguyen Duong.", (int)a);
                    } else if (a == 0) {
                        printf("\n So %d Ban Vua Nhap La So Nguyen Khong Am.", (int)a);
                    } else {
                        printf("\n So %d Ban Vua Nhap La So Nguyen Am.", (int)a);
                    }
                } else {
                    printf("\n So Ban Vua Nhap Khong Phai La So Nguyen.");
                }
                break;
            }
            case 2: { 
                printf("\n 2. Xac Dinh So Nguyen To.");
                float a;
                int i, XacDinh = 1;
                printf("\n Nhap So Nguyen Can Kiem Tra: ");
                scanf("%f", &a);
                if (a != (int)a) { // Ki?m tra n?u a l� s? th?p ph�n
                    printf("\n So Vua Nhap Khong Phai La So Nguyen.");
                } else {
                    int n = (int)a; // Chuy?n v? ki?u int
                    if (n <= 1) {
                        XacDinh = 0;
                    } else {
                        for (i = 2; i <= sqrt(n); i++) {
                            if (n % i == 0) {
                                XacDinh = 0;
                                break;
                            }
                        }
                    }
                    if (XacDinh) {
                        printf("\n So %d Ban Vua Nhap La So Nguyen To.", n);
                    } else {
                        printf("\n So %d Ban Vua Nhap Khong Phai La So Nguyen To.", n);
                    }
                }
                break;
            }
            case 3: { 
                printf("\n 3. Xac Dinh So Chinh Phuong.");
                float a;
                printf("\n Nhap So Nguyen Can Kiem Tra: ");
                scanf("%f", &a);
                if (a != (int)a) { // Ki?m tra n?u a l� s? th?p ph�n
                    printf("\n So Vua Nhap Khong Phai La So Nguyen.");
                } else {
                    int n = (int)a;
                    if (n >= 0) {
                        int sqrtA = (int)sqrt(n);
                        if (sqrtA * sqrtA == n) {
                            printf("\n So %d Ban Vua Nhap La So Chinh Phuong.", n);
                        } else {
                            printf("\n So %d Ban Vua Nhap Khong Phai La So Chinh Phuong.", n);
                        }
                    } else {
                        printf("\n So %d Khong Phai So Chinh Phuong (Khong Ap Dung Cho So Am).", n);
                    }
                }
                break;
            }
            case 4: { 
                printf("\n 4. Xac Dinh Ca So Nguyen To Va So Chinh Phuong.");
                float a;
                printf("\n Nhap So Nguyen Can Kiem Tra: ");
                scanf("%f", &a);
                if (a != (int)a) { 
                    printf("\n So Vua Nhap Khong Phai La So Nguyen.");
                } else {
                    int n = (int)a;
                    int XacDinh = 1, i;
                    if (n <= 1) {
                        XacDinh = 0;
                    } else {
                        for (i = 2; i <= sqrt(n); i++) {
                            if (n % i == 0) {
                                XacDinh = 0;
                                break;
                            }
                        }
                    }
                    if (XacDinh) {
                        printf("\n So %d Ban Vua Nhap La So Nguyen To.", n);
                    } else {
                        printf("\n So %d Ban Vua Nhap Khong Phai La So Nguyen To.", n);
                    }
                    if (n >= 0) {
                        int sqrtA = (int)sqrt(n);
                        if (sqrtA * sqrtA == n) {
                            printf("\n So %d Ban Vua Nhap La So Chinh Phuong.", n);
                        } else {
                            printf("\n So %d Ban Vua Nhap Khong Phai La So Chinh Phuong.", n);
                        }
                    } else {
                        printf("\n So %d Khong Phai So Chinh Phuong (Khong Ap Dung Cho So Am).", n);
                    }
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Su Dung.");
                break;
            }
            default:
                printf("\n Chon Sai Roi! Vui Long Chon Lai Nhe.");
        }
        if (LuaChon1 != 0) {
            printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Chuong Trinh.......");
            getchar();
            getchar();
        }
    } while (LuaChon1 != 0);
} 

void HienThi2(){
	printf("\n ====== Tim Uoc Va Boi Chung ======");
	printf("\n + 1.Tim Uoc Chung.               +");
	printf("\n + 2.Tim Boi Chung.               +");
	printf("\n + 3.Tim Ca Uoc Va Boi Chung.     +");
	printf("\n + 0.Thoat Truong Trinh.          +");
	printf("\n ==================================");
}

int UocChungLN(int a, int b) {
    while (b != 0) {
        int So = b;
        b = a % b;
        a = So;
    }
    return a;
}

int BoiChungNN(int a, int b) {
    return (a * b) / UocChungLN(a, b);
}

void SuLyHienThi2(){
    int LuaChon2;
    do {
        system("cls");
        HienThi2();
        printf("\n Nhap Lua Chon Cua Ban: ");
        scanf("%d", &LuaChon2);
        switch(LuaChon2){
            case 1: {
                printf("\n 1.Tim Uoc Chung Cua Hai So.");
                int a, b;
                printf("\n Nhap So Thu Nhat: ");
                scanf("%d", &a);
                printf("\n Nhap So Thu Hai: ");
                scanf("%d", &b);
                printf("\n So Ban Vua Nhap La: a = %d va b = %d", a, b);
                if (a <= 0 || b <= 0) {
                    printf("\n Ca Hai So Deu Be Hon Hoac Bang 0.");
                    printf("\n Phep Tinh Chua Duoc Thuc Hien.");
                } else {
                    printf("\n Uoc chung lon nhat cua %d va %d la: %d\n", a, b, UocChungLN(a, b));
                }
                break;
            }
            case 2: {
                printf("\n Tim Boi Chung Nho Nhat Cua Hai So.");
                int a, b;
                printf("\n Nhap So a = ");
                scanf("%d", &a);
                printf("\n Nhap So b = ");
                scanf("%d", &b);
                printf("\n Cac So Ban Vua Nhap La: a = %d va b = %d", a, b);
                if (a <= 0 || b <= 0) {
                    printf("\n Hai So Ban Vua Nhap Be Hon Hoac Bang 0.");
                    printf("\n Nen Phep Tinh Chua Duoc Thuc Hien.");
                } else {
                    printf("\n Boi Chung Nho Nhat Cua %d va %d La: %d", a, b, BoiChungNN(a, b));
                }
                break;
            }
            case 3: {
                printf("\n Tim Ca Uoc Chung Lon Nhat Va Boi Chung Nho Nhat Cua Hai So.");
                int a, b;
                printf("\n Nhap So a = ");
                scanf("%d", &a);
                printf("\n Nhap So b = ");
                scanf("%d", &b);
                printf("\n Cac So Ban Vua Nhap La: a = %d va b = %d", a, b);
                if (a <= 0 || b <= 0) {
                    printf("\n Hai So Ban Vua Nhap Be Hon Hoac Bang 0.");
                    printf("\n Nen Phep Tinh Chua Duoc Thuc Hien.");
                } else {
                    printf("\n Uoc Chung Lon Nhat Cua %d Va %d La: %d", a, b, UocChungLN(a, b));
                    printf("\n Boi Chung Nho Nhat Cua %d Va %d La: %d", a, b, BoiChungNN(a, b));
                }
                break;
            }
            case 4: {
                printf("\n Dang Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Tinh.");
                break;
            }
            default:
                printf("\n Ban Chon Sai So Rui!");
                printf("\n Vui Long Chon lai So Nhe.");
        }
        if (LuaChon2 != 0) {
            printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe........");
            getchar();
            getchar();
        }
    } while (LuaChon2 != 0);
}

void HienThi3(){
	printf("\n ====== Tinh Tien Karaoke ======");
	printf("\n + 1.Tinh Tien Karaoke.        +");
	printf("\n + 2.Thoat Chuong Trinh.       +");
	printf("\n ===============================");
}

void SuLyHienThi3(){
	int LuaChon3;
	do {
		system("cls");
		HienThi3();
		printf("\n Vui Long Chon So Ban Muon: ");
		scanf("%d",&LuaChon3);
		switch(LuaChon3){
			case 1: {
				int GioVao,GioRa,TongGio;
	            float ThanhTien = 0;
	            printf("\n Vui Long Nhap So Gio Vao (12h - 23h): ");
	            scanf("%d",&GioVao);
	            printf("\n Vui Long Nhap So Gio Ra (12h - 23h): ");
	            scanf("%d",&GioRa);
	            printf("\n So Gio Ban Vua Nhap Tu %d gio Den %d gio.",GioVao,GioRa);
	            TongGio = GioRa - GioVao;
	            if (GioVao < 12 || GioVao > 23 || GioRa < 12 || GioRa > 23 || GioVao >= GioRa){
	            	printf("\n Ban Da Nhap Sai So Gio Vao Hoac So Gio Ra");
	            	printf("\n Vui Long Nhap Lai So Gio Nhe.");
	            } else {
	        	    if (TongGio <= 3) {
                        ThanhTien = TongGio * 50.000;
                    } else {
                    	ThanhTien = 3 * 50.000;
                	    ThanhTien += (TongGio - 3) * 50.000 * 0.7;
		    	    }
			        if (GioVao >= 14 && GioVao <= 17){
			    	    ThanhTien *= 0.9; 
			        }
			        printf("\n Tong Tien Ma Ban Phai Tra Sau %d Gio La: %.3f VND\n",TongGio,ThanhTien);
	        	}
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Tinh.");
				break;
			}
			default :
				printf("\n Ban Da Chon Sai So!");
				printf("\n Vui Long Chon Lai.");
		} if (LuaChon3 != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe.......");
		    getchar();
		    getchar();
		}
	} while (LuaChon3 != 0);
}

void HienThi4(){
	printf("\n ===== Tinh Tien Dien =====");
	printf("\n + 1.Tinh Tien Dien.      +");
	printf("\n + 2.Thoat Chuong Trinh.  +");
	printf("\n ==========================");
}

void SuLyHienThi4(){
	int LuaChon4;
	do {
		system("cls");
		HienThi4();
		printf("\n Nhap Lua Chon Cua Ban.");
		scanf("%d",&LuaChon4);
		switch(LuaChon4){
			case 1: {
				float SoDien,ThanhTien = 0;
				printf("\n Nhap So Dien Ban Muon Tinh: ");
				scanf("%f",&SoDien);
				printf("\n Ban Vua Nhap So Dien La: %.2f",SoDien);
				if (SoDien <= 50){
					ThanhTien = 50 * 1.678;
				} else 
				if (SoDien <= 100){
					ThanhTien = (50 * 1.678) + (SoDien - 50) * 1734;
				} else 
				if (SoDien <= 200) {
					ThanhTien = (50 * 1.678) + (50 * 1734) + (SoDien - 100) * 2014;
				} else
				if (SoDien <= 300) {
					ThanhTien = (50 * 1.678) + (50 * 1734) + (100 * 2014) + (SoDien - 200) * 2536;
				} else 
				if (SoDien <= 400) {
				    ThanhTien = (50 * 1.678) + (50 * 1734) + (100 * 2014) + (100 * 2536) + (SoDien - 300) * 2.834;
				} else {
					ThanhTien = (50 * 1.678) + (50 * 1734) + (100 * 2014) + (100 * 2536) + (100 * 2834) + (SoDien - 400) * 2927;
				}
				printf("\n Tong Tien Dien Cua %.2f La: %.3f VND \n",SoDien,ThanhTien);
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung.");
				break;
			}
			default :
				printf("\n Ban Da Chon Sai So Rui!");
				printf("\n Vui Long Chon Lai.");
		}
		if(LuaChon4 != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe....");
			getchar();
			getchar();
		}
	} while (LuaChon4 != 0);
}

void HienThi5() {
    printf("\n ====== Hien Thi Doi Tien Theo Menh Gia ======");
    printf("\n + 1. Doi Tien Voi Menh Gia Hop Ly.          +");
    printf("\n + 0. Thoat Chuong Trinh.                    +");
    printf("\n =============================================");
}

void SuLyHienThi5() {
    int LuaChon5;
    do {
        system("cls");
        HienThi5();
        printf("\n Moi Ban Chon So: ");
        scanf("%d", &LuaChon5);
        switch (LuaChon5) {
            case 1: {
                printf("\n Doi Tien Voi Menh Gia Hop Ly.");
                int SoTienCanDoi;
                int MenhGia[] = {500, 200, 100, 50, 20, 10, 5, 2, 1};
                int SoLuongTien[9] = {0};
                int i;

                printf("\n Nhap So Tien Ban Muon Doi: ");
                scanf("%d", &SoTienCanDoi);

                if (SoTienCanDoi <= 0) {
                    printf("\n So tien phai la so duong. Vui long nhap lai!");
                    break;
                }

                printf("\n So Tien Ban Da Nhap La: %d", SoTienCanDoi);
                for (i = 0; i < 9; i++) {
                    if (SoTienCanDoi >= MenhGia[i]) {
                        SoLuongTien[i] = SoTienCanDoi / MenhGia[i];
                        SoTienCanDoi %= MenhGia[i];
                    }
                }
                printf("\n Ket Qua Doi Tien La: \n");
                for (i = 0; i < 9; i++) {
                    if (SoLuongTien[i] > 0) {
                        printf(" - %d To Tien Gia %d.000 VND\n", SoLuongTien[i], MenhGia[i]);
                    }
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh Tinh Tien.");
                printf("\n Cam On Ban Da Su Dung.");
                break;
            }
            default:
                printf("\n Ban Da Chon Sai So Rui!");
                printf("\n Vui Long Chon Lai So.");
        }

        if (LuaChon5 != 0) {
            printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe......");
            getchar(); 
            getchar();
        }
    } while (LuaChon5 != 0);
}

void HienThi6(){
	printf("\n ======== Tinh Lai =========");
	printf("\n + 1.Tinh Lai Ngan Hang.   +");
	printf("\n + 0.Thoat Chuong Trinh.   +");
	printf("\n ===========================");
}

void SuLyHienThi6() {
    int LuaChon6;
    do {
        system("cls");
        HienThi6();
        printf("\n Vui Long Chon So: ");
        scanf("%d", &LuaChon6);
        switch (LuaChon6) {
            case 1: {
                printf("\n Tinh Lai Xuat Ngan Hang.");
                int TienVay, KyHan = 12;
                float LaiXuat = 0.05;
                printf("\n Nhap So Tien Vay (VND): ");
                scanf("%d", &TienVay);
                int SoTienGocPhaiTra = TienVay / KyHan;
                int SoDu = TienVay; 
                printf("\n Ky Han \t Tien Lai Phai Tra \t Tien Goc Phai Tra \t Tong Tien Phai Tra \t So Du Con Lai\n");
                int i;
                for (i = 1; i <= KyHan; i++) {
                    int TienLaiPhaiTra = (int)(SoDu * LaiXuat);  
                    int TongTienPhaiTra = SoTienGocPhaiTra + TienLaiPhaiTra; 
                    SoDu -= SoTienGocPhaiTra; 

                    printf("%6d \t %18d \t %17d \t %20d \t %15d\n", i, TienLaiPhaiTra, SoTienGocPhaiTra, TongTienPhaiTra, SoDu);
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh Tinh Tien Lai.");
                printf("\n Cam On Ban Da Su Dung Nha.");
                break;
            }
            default:
                printf("\n Lua Chon Khong Hop Le! Vui Long Chon Lai.");
        }
        if (LuaChon6 != 0) {
            printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc.");
            getchar();
            getchar();
        }
    } while (LuaChon6 != 0);
}

void HienThi7(){
	printf("\n ==== Mua Xe Tra Gop ====");
	printf("\n + 1.Vay Tien Mua Xe.   +");
	printf("\n + 0.Thoat Chuong Trinh.+");
	printf("\n ========================");
}

void SuLyHienThi7() {
    int LuaChon7;
    do {
        system("cls");
        HienThi7();
        printf("\n Nhap Lua Chon Cua Ban: ");
        scanf("%d", &LuaChon7);
        switch (LuaChon7) {
            case 1: {
                printf("\n Tinh Lai Mua Xe.\n");
                float GiaTriCuaXe, LaiXuatNamCoDinh, PhanTramVayCoDinh;
                int ThoiHanVay;
                printf("\n Nhap Gia Tri Cua Xe Ma Ban Muon (VND): ");
                scanf("%f", &GiaTriCuaXe);
                if (GiaTriCuaXe <= 0) {
                    printf("\n Gia tri cua xe khong hop le. Vui long nhap lai.\n");
                    break;
                }
                printf("\n Nhap Lai Xuat Co Dinh Theo Nam (%%): ");
                scanf("%f", &LaiXuatNamCoDinh);
                if (LaiXuatNamCoDinh <= 0 || LaiXuatNamCoDinh > 100) {
                    printf("\n Lai xuat khong hop le. Vui long nhap lai.\n");
                    break;
                }
                printf("\n Nhap Thoi Han Vay Cua Ban (So Nam): ");
                scanf("%d", &ThoiHanVay);
                if (ThoiHanVay <= 0) {
                    printf("\n Thoi han vay khong hop le. Vui long nhap lai.\n");
                    break;
                }
                printf("\n Nhap Phan Tram Vay Toi Da (0 - 100): ");
                scanf("%f", &PhanTramVayCoDinh);
                if (PhanTramVayCoDinh < 0 || PhanTramVayCoDinh > 100) {
                    printf("\n Phan tram vay khong hop le. Vui long nhap lai.\n");
                    break;
                }
                float SoTienTraTruoc = (1 - PhanTramVayCoDinh / 100) * GiaTriCuaXe;
                float SoTienDuocVayDeMuaXe = GiaTriCuaXe - SoTienTraTruoc;
                float LaiXuatThang = LaiXuatNamCoDinh / 12 / 100;
                int SoThangPhaiTra = ThoiHanVay * 12;
                float SoTienPhaiTraHangThang = SoTienDuocVayDeMuaXe * (LaiXuatThang * pow(1 + LaiXuatThang, SoThangPhaiTra)) / (pow(1 + LaiXuatThang, SoThangPhaiTra) - 1);
                printf("\n So Tien Ban Phai Tra Truoc La: %.2f VND \n", SoTienTraTruoc);
                printf("\n So Tien Ban Phai Tra Hang Thang La: %.2f VND \n", SoTienPhaiTraHangThang);
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Tinh Lai Xuat Vay Mua Xe.\n");
                break;
            }
            default:
                printf("\n Lua Chon Khong Hop Le. Vui Long Thu Lai.\n");
        }
        if (LuaChon7 != 0) {
            printf("\n Nhan Phim Bat Ky De Tiep Tuc Tinh...\n");
            getchar();
            getchar();
        }
    } while (LuaChon7 != 0);
}

void HienThi8(){
	printf("\n ========== Thong Tin =========");
	printf("\n + 1.Thong Tin Sinh Vien.     +");
	printf("\n + 0.Thoat Chuong Trinh.      +");
	printf("\n ==============================");
}

void SuLyHienThi8(){
	int LuaChon8;
	do {
	system("cls");
	HienThi8();
	printf("\n Nhap Lua Chon Cua Ban: ");
	scanf("%d",&LuaChon8);
	switch(LuaChon8){
		case 1: {
			printf("\n Bai Toan Xap Xep Sinh Vien.");
			int SoLuongSinhVien;
			printf("\n Moi Ban Nhap So Luong Sinh Vien: ");
			scanf("%d",&SoLuongSinhVien);
			getchar();
			char Ten[SoLuongSinhVien][100];
			int Diem[SoLuongSinhVien];
			int i,j;
			if (SoLuongSinhVien <= 0 ){
				printf("\n So LuongSinh Vien Ban Ma Ban Vua Nhap Be Hon Hoac Bang 0.");
				printf("\n Vui Long Chon Va Nhap Lai.");
			} else {
				for (i = 0;i < SoLuongSinhVien;i ++){
					printf("\n Nhap Ten Sinh Vien Thu %d La: ",i+1);
					gets(Ten[i]);
					printf("\n Nhap Diem Cua Sinh Vien %s La: ",Ten[i]);
					scanf("%d",&Diem[i]);
					getchar();
				}
				for (i = 0;i <SoLuongSinhVien; i ++){
					for( j = 0; j < SoLuongSinhVien ; j ++){
						if(Diem[i] > Diem[j]){
							int Diemx = Diem[i];
						    Diem[i] = Diem[j];
							Diem[j] = Diemx;
						
							char Tenx[100];
							strcpy(Tenx,Ten[i]);
							strcpy(Ten[i], Ten[j]);
							(Ten[j],Tenx);
						}
					}
				}
				printf("\n Thong Tin Xep Hang Diem Cua Cac Sinh Vien.");
				for (i = 0;i <SoLuongSinhVien;i++){
					printf("\n Ten Sinh Vien Thu %d La: %s",i+1,Ten[i]);
					printf("\n Diem Sinh Vien Thu %d La: %d ",i+1,Diem[i]);
				}
			}
			break;
		}
	case 0:{
		printf("\n Thoat Chuong Trinh.");
		
		break;
	}
	default:
	printf("\n Ban Da Chon Sai So!");	
	}
	if (LuaChon8 != 0){
		printf("\n Nhap Vao Phim Bat Ky De Tiep Tuc.......");
		getchar();
		getchar();
	}
	} while (LuaChon8 != 0);
}
void HienThi9(){
	printf("\n ======= Tro Choi =======");
	printf("\n + 1.Game Poly - Lott.  +");
	printf("\n + 0.Thoat Chuong Trinh.+");
	printf("\n ========================");	
}

void SuLyHienThi9(){
	int LuaChon9;
	do {
		system("cls");
		HienThi9();
		printf("\n Nhap Su Lua Chon Cua Ban: ");
		scanf("%d",&LuaChon9);
		switch(LuaChon9){
			case 1: {
				printf("\n 1. Game Poly - Lott.");
				int SoNguoiChon[2], SoCuaHeThong[2];
	            int TrungSo = 0;
	            printf("Nhap 2 so (tu 1 den 15):\n");
	            int i;
                for ( i = 0; i < 2; i++) {
                    printf("So thu %d: ", i + 1);
                    scanf("%d", &SoNguoiChon[i]);
                    if (SoNguoiChon[i] < 1 || SoNguoiChon[i] > 15) {
                        printf("So khong hop le! Vui long nhap lai.\n");
                        i--;
                    }
                }
	            srand(time(NULL));
                for (i = 0; i < 2; i++) {
                SoCuaHeThong[i] = rand() % 15 + 1;
                } 
				printf("\nHe thong da chon 2 so: %d va %d\n", SoCuaHeThong[0], SoCuaHeThong[1]);
				int  j;
				for ( i = 0; i < 2; i++) {
                    for ( j = 0; j < 2; j++) {
                        if (SoNguoiChon[i] == SoCuaHeThong[j]) {
                            TrungSo++;
                            SoCuaHeThong[j] = -1; 
                        }
                    }
                }
                if (TrungSo == 0) {
                    printf("\nChuc ban may man lan sau!\n");
                } else if (TrungSo == 1) {
                    printf("\nChuc mung ban da trung giai nhi!\n");
                } else if (TrungSo == 2) {
                   printf("\nChuc mung ban da trung giai nhat!\n");
                } 
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Choi Tro Choi.");
				break;
			}
			default :
				printf("\n Da Da Chon Sai So Rui!");
				printf("\n Vui Long Chon Lai So Nhe.");
		}
		if (LuaChon9 != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Choi Nhe......");
			getchar();
			getchar();
		}
	} while (LuaChon9 != 0);
}

void HienThi10(){
	printf("\n =========== Tinh Phan So ===========");
	printf("\n + 1.Cong Hai Phan So.              +");
	printf("\n + 2.Tru Phan So.                   +");
	printf("\n + 3.Nhan Phan So.                  +");
	printf("\n + 4.Chia Phan So.                  +");
	printf("\n + 5.Hien Ca Cac Phep Tinh.         +");
	printf("\n + 0.Thoat Chuong Trinh.            +");
	printf("\n ====================================");
}

int UCLonNhat(int a, int b) {
    while (b != 0) {
        int So = b;
        b = a % b;
        a = So;
    }
    return abs(a);
}

void RutGonPhanSo(int *Tu, int *Mau) {
    int uocchungln = UCLonNhat(*Tu, *Mau);
    *Tu /= uocchungln;
    *Mau /= uocchungln;
}
void SuLyHienThi10() {
    int LuaChon10;
    do {
        system("cls");
        HienThi10();
        printf("\n Nhap Lua Chon Cua Ban: ");
        scanf("%d", &LuaChon10);
        switch (LuaChon10) {
            case 1: {
                printf("\n 1. Cong Hai Phan So. ");
                int Tu1, Tu2, Mau1, Mau2;
                printf("\n Nhap Tu So Phan So Thu Nhat: ");
                scanf("%d", &Tu1);
                printf("\n Nhap Mau So Phan So Thu Nhat: ");
                scanf("%d", &Mau1);
                printf("\n Nhap Tu So Phan So Thu Hai: ");
                scanf("%d", &Tu2);
                printf("\n Nhap Mau So Phan So Thu Hai: ");
                scanf("%d", &Mau2);

                if (Mau1 == 0 || Mau2 == 0) {
                    printf("\n Loi: Mau So Khong Duoc Bang 0.\n");
                } else {
                    int KetQuaTu = Tu1 * Mau2 + Tu2 * Mau1;
                    int KetQuaMau = Mau1 * Mau2;
                    RutGonPhanSo(&KetQuaTu, &KetQuaMau);
                    printf("\n Ket Qua Phep Cong: %d / %d\n", KetQuaTu, KetQuaMau);
                }
                break;
            }
            case 2: {
                printf("\n 2. Tru Hai Phan So. ");
                int Tu1, Tu2, Mau1, Mau2;
                printf("\n Nhap Tu So Phan So Thu Nhat: ");
                scanf("%d", &Tu1);
                printf("\n Nhap Mau So Phan So Thu Nhat: ");
                scanf("%d", &Mau1);
                printf("\n Nhap Tu So Phan So Thu Hai: ");
                scanf("%d", &Tu2);
                printf("\n Nhap Mau So Phan So Thu Hai: ");
                scanf("%d", &Mau2);

                if (Mau1 == 0 || Mau2 == 0) {
                    printf("\n Loi: Mau So Khong Duoc Bang 0.\n");
                } else {
                    int KetQuaTu = Tu1 * Mau2 - Tu2 * Mau1;
                    int KetQuaMau = Mau1 * Mau2;
                    RutGonPhanSo(&KetQuaTu, &KetQuaMau);
                    printf("\n Ket Qua Phep Tru: %d / %d\n", KetQuaTu, KetQuaMau);
                }
                break;
            }
            case 3: {
                printf("\n 3. Nhan Hai Phan So. ");
                int Tu1, Tu2, Mau1, Mau2;
                printf("\n Nhap Tu So Phan So Thu Nhat: ");
                scanf("%d", &Tu1);
                printf("\n Nhap Mau So Phan So Thu Nhat: ");
                scanf("%d", &Mau1);
                printf("\n Nhap Tu So Phan So Thu Hai: ");
                scanf("%d", &Tu2);
                printf("\n Nhap Mau So Phan So Thu Hai: ");
                scanf("%d", &Mau2);

                if (Mau1 == 0 || Mau2 == 0) {
                    printf("\n Loi: Mau So Khong Duoc Bang 0.\n");
                } else {
                    int KetQuaTu = Tu1 * Tu2;
                    int KetQuaMau = Mau1 * Mau2;
                    RutGonPhanSo(&KetQuaTu, &KetQuaMau);
                    printf("\n Ket Qua Phep Nhan: %d / %d\n", KetQuaTu, KetQuaMau);
                }
                break;
            }
            case 4: {
                printf("\n 4. Chia Hai Phan So. ");
                int Tu1, Tu2, Mau1, Mau2;
                printf("\n Nhap Tu So Phan So Thu Nhat: ");
                scanf("%d", &Tu1);
                printf("\n Nhap Mau So Phan So Thu Nhat: ");
                scanf("%d", &Mau1);
                printf("\n Nhap Tu So Phan So Thu Hai: ");
                scanf("%d", &Tu2);
                printf("\n Nhap Mau So Phan So Thu Hai: ");
                scanf("%d", &Mau2);

                if (Mau1 == 0 || Mau2 == 0 || Tu2 == 0) {
                    printf("\n Loi: Mau So Hoac Tu So Cua Phan So Thu Hai Khong Duoc Bang 0.\n");
                } else {
                    int KetQuaTu = Tu1 * Mau2;
                    int KetQuaMau = Mau1 * Tu2;
                    RutGonPhanSo(&KetQuaTu, &KetQuaMau);
                    printf("\n Ket Qua Phep Chia: %d / %d\n", KetQuaTu, KetQuaMau);
                }
                break;
            }
            case 5: {
                printf("\n 5. Chia Hai Phan So. ");
                int Tu1, Tu2, Mau1, Mau2;
                printf("\n Nhap Tu So Phan So Thu Nhat: ");
                scanf("%d", &Tu1);
                printf("\n Nhap Mau So Phan So Thu Nhat: ");
                scanf("%d", &Mau1);
                printf("\n Nhap Tu So Phan So Thu Hai: ");
                scanf("%d", &Tu2);
                printf("\n Nhap Mau So Phan So Thu Hai: ");
                scanf("%d", &Mau2);

                if (Mau1 == 0 || Mau2 == 0 || Tu2 == 0) {
                    printf("\n Loi: Mau So Hoac Tu So Cua Phan So Thu Hai Khong Duoc Bang 0.\n");
                } else {
                    int KetQuaTu1 = Tu1 * Mau2 + Tu2 * Mau1;
                    int KetQuaMau1 = Mau1 * Mau2;
                    RutGonPhanSo(&KetQuaTu1, &KetQuaMau1);
                    int KetQuaTu2 = Tu1 * Mau2 - Tu2 * Mau1;
                    int KetQuaMau2 = Mau1 * Mau2;
                    RutGonPhanSo(&KetQuaTu2, &KetQuaMau2);
                    int KetQuaTu3 = Tu1 * Tu2;
                    int KetQuaMau3 = Mau1 * Mau2;
                    RutGonPhanSo(&KetQuaTu3, &KetQuaMau3);
                    int KetQuaTu4 = Tu1 * Mau2;
                    int KetQuaMau4 = Mau1 * Tu2;
                    RutGonPhanSo(&KetQuaTu4, &KetQuaMau4);
                    printf("\n Ket Qua Phep Cong: %d / %d\n", KetQuaTu1, KetQuaMau1);
                    printf("\n Ket Qua Phep Tru: %d / %d\n", KetQuaTu2, KetQuaMau2);
                    printf("\n Ket Qua Phep Nhan: %d / %d\n", KetQuaTu3, KetQuaMau3);
                    printf("\n Ket Qua Phep Chia: %d / %d\n", KetQuaTu4, KetQuaMau4);
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh. Cam On Ban!\n");
                break;
            }
            default: {
                printf("\n Lua Chon Khong Hop Le. Vui Long Thu Lai!\n");
            }
        }
        if (LuaChon10 != 0) {
            printf("\n Nhan Phim Bat Ky De Tiep Tuc...");
            getchar();
            getchar();
        }
    } while (LuaChon10 != 0);
}
int main(){
	int LuaChon;
	do {
		system("cls");
		HienThiMeNu();
		printf("\n Nhap Lua Chuon Cua Ban: ");
	    scanf("%d",&LuaChon);
	    
	    switch(LuaChon){
	    	case 1: {
	    		SuLyHienThi1();
				break;
			}
			case 2:{
				SuLyHienThi2();
				break;
			}
			case 3: {
				SuLyHienThi3();
				break;
			}
			case 4: {
				SuLyHienThi4();
				break;
			}
			case 5:{
				SuLyHienThi5();
				break;
			}
			case 6:{
				SuLyHienThi6();
				break;
			}
			case 7: {
				SuLyHienThi7();
				break;
			}
			case 8: {
				SuLyHienThi8();
				break;
			}
			case 9: {
				SuLyHienThi9();
				break;
			}
			case 10: {
				SuLyHienThi10();
				break;
			}
			case 0:{
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung.");
				break;
			}
			default:
				printf("\n Ban Da Chon Sai So!");
				printf("\n Vui Long Chon Lai.");
		}
		if (LuaChon != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe.......");
			getchar();
			getchar();
		}
	} while (LuaChon != 0);
	return 0;
}
