// viet chuong trinh doan so su dung vvong lap do while
#include <stdio.h>
int main(){
	int sobimat = 16;
	int songuoidoan;
	int solandoan = 0;
	printf("\n Chuong trinh doan so bi mat nhe:) ");
	do {
	printf("\n Doan so bi an cua chuong trinh la: ");
	scanf("%d",&songuoidoan);
	solandoan ++;
	if (songuoidoan < sobimat){
		printf("\n so bn doan be hon so bi mat.");
	}	else if ( songuoidoan > sobimat) {
			printf("\n so ban doan lon hon so bi mat.");
			}else {
				printf("\n Chuc Mung Ban:) da doan dung so bi mat %d\n",sobimat);
				printf("\n Ban Da Doan trung so bi mat sau %d lan doan. ",solandoan);
	} 
	} 
	while (songuoidoan != sobimat);
	return 0;
	}	
