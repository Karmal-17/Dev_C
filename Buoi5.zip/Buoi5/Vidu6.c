#include <stdio.h>
#include <string.h>
int main(){
	char bainhac[20];
	printf("Nhap De Bat Dau:  ");
	scanf("%s",&bainhac);
	printf("Ban Vua Nhap So: %s\n");
	if (strcmp(bainhac, "batdau") == 0){
		printf("\n Mashup 2017");
		printf("\n Rot Den Chan Ly.");
		printf("\n Anh Chim Dong Trong Men Caya Dang Nong. ");
		printf("\n Tham Uot Le Sau Mon Dang. ");
		printf("\n Vi Danh Mat Hy Vong. ");
		printf("\n Cho Dem Choi Voi ");
		printf("\n De Nhung Anh Mat Doi Moi ");
		printf("\n Tinh Cam Dam Mua Tham Lau ");
		printf("\n Lac Giua May Ngan Ve Chon Xa Xoi ");
		printf("\n Em La Ai Tu Dau Buoc Den Noi Day Diu Dang Chan Phuong");
		printf("\n Em La Ai Tua Nhu Anh Nang Ban Mai Ngot Ngao Trong Suong ");
		printf("\n Ngam Em That Lau ");	
		printf("\n Con Tim Anh Yeu Mem ");	
		printf("\n Dam Say Tu Phut Do ");	
		printf("\n Tung Giay Thoi Yeu Them ");	
		printf("\n Theo Mua Xa May Mu Giang Loi ");	
		printf("\n Lan Suong Khoi Phoi Pha  ");	
		printf("\n Dua Buoc Ai xa Dan ");	
		printf("\n Don Coi Minh Ta Van Vuong ");	
		printf("\n Nhe Buoc Trong Men Say Chieu Mua Buon ");	
		printf("\n Ngan Giot Le Ngung Khien Khoe Mi Sau Bi ");	
		printf("\n Minh Tu Roi Bo Nhau Say Den Dien Dai ");	
		printf("\n Say Het Kiep Nguoi Say Cho Chay Long ");	
		printf("\n Vi Da Lo Yeu Em Roi ");	
		printf("\n Tham Uot Le Sau Mon Dang ");	
		printf("\n ((: ____ :)) ");	
		printf("\n Nhe Nhang Au Yem Giua Chon Mo ");
		printf("\n Cung Tim Kiem Bao Y Tho ");	
		printf("\n De Dam Say Trong Tieng Nhac Du Duong ");	
	    printf("\n Hon Theo Buoc Ta NgAn Ngo ");
		printf("\n Du Ngan Kiep Ta Van Cho ");
		printf("\n Chi Can Co Phut Giay Nay Trao Yeu Thuong ");
		printf("\n Cuz Baby It's Always You ");
		printf("\n ((: ____ :)) ");
} else {
	printf("Het Bai Rui Nhe!");
}
return 0;
}


