#include <stdio.h>
int main() {
    // In ra c�c s? t? 1 d?n 5
    int i = 1;
    // Gi� tr? kh?i t?o c?a i = 1
    while (i <= 5) {
        // V�ng l?p while s? th?c hi?n cho d?n khi di?u ki?n i <= 5 kh�ng c�n d�ng
        printf("%d\n", i);
        // M?i v�ng l?p th� chuong tr�nh s? in ra 1 gi� tr? c?a i
        i++;
        // M?i v�ng l?p chuong tr�nh s? cho i tang l�n 1 gi� tr?
    }

    printf("\nV� d? s? 2: T�nh t?ng t? 1 d?n n\n");
    int n, tong = 0;
    
    // Nhap gi� tr? n t? ngu?i d�ng
    printf("Nhap so nguyen duong n: ");
    scanf("%d", &n);

    // �at lai gi� tri i = 1
    i = 1;

    // V�ng l?p t�nh t?ng t? 1 d?n n
    while (i <= n) {
        tong += i; // Cang gi� tri i v�o tong
        i++;       // Tang i l�n 1
    }

    // In ra ket qua sau khi v�ng lap ket th�c
    printf("Tong tu 1 den %d la: %d\n", n, tong);

    return 0;
}

