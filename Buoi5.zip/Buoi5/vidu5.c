#include <stdio.h>

int main() {
    int sobimat = 16; // S? b� m?t
    int songuoidoan;

    printf("Chuong trinh doan so bi mat nhe :)\n");

    do {
        // Ngu?i d�ng nh?p s? do�n
        printf("Doan so bi an cua chuong trinh la: ");
        scanf("%d", &songuoidoan);

        // So s�nh s? ngu?i do�n v?i s? b� m?t
        if (songuoidoan < sobimat) {
            printf("\nSo ban doan be hon so bi mat.\n");
        } else if (songuoidoan > sobimat) {
            printf("\nSo ban doan lon hon so bi mat.\n");
        } else {
            printf("\nChuc mung ban :) da doan dung so bi mat la %d\n", sobimat);
        }
    } while (songuoidoan != sobimat); // �i?u ki?n l?p: ti?p t?c khi do�n sai

    return 0;
}

