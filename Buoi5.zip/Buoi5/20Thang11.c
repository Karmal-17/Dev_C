#include <stdio.h>
#include <string.h>
int main(){
	char n[20] ;
	printf("Nhap Ten Giang Vien Cua Bn:  ");
	scanf("%s",&n);
	printf("Ban Vua Nhap Ten Giang Vien Yeu Quy Cua Ban: %s",n);
		if (strcmp ( n , "Nguyen_Thi_Thanh") == 0) {
		printf("\n Hom Nay 20 Thang 11 Nhung Con Khung Ve Duoc.");
		printf("\n Thoi Gui Co Nhung Dong Tri An Nay Vay.");
		printf("\n Con Chuc Co Thanh Vui Tuoi Moi Ngay.");
		printf("\n Chuc Co Luon Xinh Dep.");
		printf("\n Thanh Cong Trong Su Nghiep Nguoi Lai Do.");
		printf("\n Du It Gap Co Hon Nhung Co Van Trong Tim Con.");
		printf("Tang Co Nhung Dong Tho Cua Tac Gia Nguyen Trung Dung");
		printf("\n Nguoi Mang Anh Sang Soi Doi Tre.");
		printf("\n Lai Chuyen Do Chieu Xang Ben Day.");
		printf("\n Do Den Vinh Quang Noi Dat La.");
		printf("\n Cam On Nguoi Da Lai Do Hay.");
		printf("\n On Nay Tro Mai Ghi Trong Da.");
		printf("\n Nguoi Da Giup Con Vuot Qua Dang Cay.");
		printf("\n Cam On Co Mot Giang Vien Cua Pho Thong Cao Dang FPT Mai Trong Tim Toi.");
		printf("\n Loi Nhan Tu Nguoi Hoc Tro Co Luon Yeu Quy.");
	}	else {
		if (strcmp ( n , "Nguyen_Phuong_Thao") == 0) {
			printf("\n Hom Nay 20 Thang 11 Mac Du Con Khung Ve Duoc Nhung Van Luon Nho Toi Co .");
			printf("\n Danh Phai Gui Qua Nhung Cau Chu Nay Thui.");
			printf("\n Con Chuc Co Thao Lon Luon Luon Vui Ve Moi Ngay.");
			printf("\n Chuc Co Luon Xinh Dep.");
			printf("\n Mai La Phu Ba Trong Tim Nguoi Hoc Tro .");
			printf("\n Gui Co Nhung Loi Tho Cua Tac Gia Thao Nguyen.");
			printf("\n Mot Doi Nguoi - Mot Dong Song.");
			printf("\n May Ai Lam Ke Dung Trong Ben Bo.");
			printf("\n 5 Bai Tho Ngan Ma Sau Nang Tinh Co Tro Anh 3.");
			printf("\n Muon Qua Song Phai Luy Do.");
			printf("\n Duong Doi Muon Buoc Cay Nho Nho Nguoi Dua.");
			printf("\n Thang Nam Dau Dai Nang Mua.");
			printf("\n Con Do Tri Thuc Co Dua Bao Nguoi.");
			printf("\n Qua Song Gui Lai Nu Cuoi. ");
			printf("\n Tinh Yeu Xin Tang Nguoi Co Kinh Thuong.");
			printf("\n Con Do Moc - Mai Dau Suong.");
			printf("\n Mai Theo Ta Khap Muon Phuong Van Ngay.");
			printf("\n Khuc Song Ay Van Con Day.");
			printf("\n Co Dua Tiep Nhung Do Day Qua Song.");
		    printf("\n Luon Thanh Cong Trong Su Nghiep Nguoi Lai Do Cua FPT Bac Giang.");
			printf("\n Cam On Co Mot Giang Vien Cua Pho Thong Cao Dang FPT Bac Giang.");	
			printf("\n Loi Nhan Gui Tu Nguoi Hoc Tro Co Luon Yeu Quy .");
			} else {
				if (strcmp ( n , "Do_Nhat_Minh") == 0) {
			printf("\n Hom Nay 20 Thang 11.");
			printf("\n Con Chuc Thay Minh Luon Luon Vui Ve Moi Ngay.");
			printf("\n Mai Giang Tay Chao Don Khi Con Tro Ve.");
			printf("\n Mai La Nguoi Thay Dep Nhat Trong Tim Nguoi Hoc Tro .");
			printf("\n Gui Thay Nhung Loi Tho Cua Tac Gia Pham Minh Dung .");
			printf("\n Van Theo Toi Nhung Loi Nhac Nho .");
			printf("\n Moi Khi Toi Tim Duoc Vinh Quang  .");
			printf("\n Qua Buon Vui Qua Nhung Thang Tram  .");
			printf("\n Cau Tra Loi Sang Len Lap Lanh .");
			printf("\n Voi Toi Thay Ky Thac .");
			printf("\n Thay Gui Toi Khat Vong Nguoi Cha .");
			printf("\n Duong Van Dai Va Xa .");
			printf("\n Thay Giao Cu Don Toi Tung Buoc .");
			printf("\n Tung Buoc Mot Toi Buoc .");
			printf("\n Voi Ki Niem Thay Toi .");
		    printf("\n Luon Thanh Cong Trong Su Nghiep Nguoi Lai Do Cua FPT Bac Giang.");
			printf("\n Cam On Co Mot Giang Vien Cua Pho Thong Cao Dang FPT Bac Giang.");	
			printf("\n Loi Nhan Gui Tu Nguoi Hoc Tro Ma Thay Luon Yeu Quy .");
			} else {
				if (strcmp ( n , "Vu_Thi_Dinh") == 0) {
			printf("\n Hom Nay 20 Thang 11 Mac Du Con Khung Ve Duoc Nhung Van Luon Nho Toi Co .");
			printf("\n Danh Phai Gui Qua Nhung Cau Chu Nay Thui.");
			printf("\n Con Chuc Co Dinh Luon Luon Vui Ve Moi Ngay.");
			printf("\n Chuc Co Luon Xinh Dep.");
			printf("\n Mai La Phu Ba Trong Tim Nguoi Hoc Tro .");
			printf("\n Gui Co Nhung Loi Tho Cua Tac Gia Thao Nguyen.");
			printf("\n Mot Doi Nguoi - Mot Dong Song.");
			printf("\n May Ai Lam Ke Dung Trong Ben Bo.");
			printf("\n 5 Bai Tho Ngan Ma Sau Nang Tinh Co Tro Anh 3.");
			printf("\n Muon Qua Song Phai Luy Do.");
			printf("\n Duong Doi Muon Buoc Cay Nho Nho Nguoi Dua.");
			printf("\n Thang Nam Dau Dai Nang Mua.");
			printf("\n Con Do Tri Thuc Co Dua Bao Nguoi.");
			printf("\n Qua Song Gui Lai Nu Cuoi. ");
			printf("\n Tinh Yeu Xin Tang Nguoi Co Kinh Thuong.");
			printf("\n Con Do Moc - Mai Dau Suong.");
			printf("\n Mai Theo Ta Khap Muon Phuong Van Ngay.");
			printf("\n Khuc Song Ay Van Con Day.");
			printf("\n Co Dua Tiep Nhung Do Day Qua Song.");
		    printf("\n Luon Thanh Cong Trong Su Nghiep Nguoi Lai Do Cua FPT Ha Noi.");
			printf("\n Cam On Co Mot Giang Vien Cua Pho Thong Cao Dang FPT Ha Noi.");	
			printf("\n Loi Nhan Gui Tu Nguoi Hoc Tro Co Luon Yeu Quy .");
			} else {
					if (strcmp ( n , "Co_Mai_Nhi") == 0) {
		printf("\n Hom Nay 20 Thang 11 Khung Gap Duoc Co Nhung .");
		printf("\n Thoi Gui Co Nhung Dong Tri An Nay Vay.");
		printf("\n Con Chuc Co Nhi Vui Tuoi Moi Ngay.");
		printf("\n Chuc Co Luon Xinh Dep.");
		printf("\n Thanh Cong Trong Su Nghiep Nguoi Lai Do.");
		printf("\n Du It Gap Co Hon Nhung Co Van Trong Tim Con.");
		printf("Tang Co Nhung Dong Tho Cua Tac Gia Nguyen Trung Dung");
		printf("\n Nguoi Mang Anh Sang Soi Doi Tre.");
		printf("\n Lai Chuyen Do Chieu Xang Ben Day.");
		printf("\n Do Den Vinh Quang Noi Dat La.");
		printf("\n Cam On Nguoi Da Lai Do Hay.");
		printf("\n On Nay Tro Mai Ghi Trong Da.");
		printf("\n Nguoi Da Giup Con Vuot Qua Dang Cay.");
		printf("\n Cam On Co Mot Giang Vien Cua App KynaEnglish.");
		printf("\n Loi Nhan Tu Nguoi Hoc Tro Co Luon Yeu Quy.");
		printf("\n Mai Yeu  Co Mai Nhi .");
		} else {
			if (strcmp ( n , "Co_Huyen_Dieu") == 0) {
			printf("\n Hom Nay 20 Thang 11  .");
			printf("\n Con Chuc Dieu Luon Luon Vui Ve Moi Ngay.");
			printf("\n Chuc Co Luon Xinh Dep.");
			printf("\n Gui Co Nhung Loi Tho Cua Tac Gia Thao Nguyen.");
			printf("\n Mot Doi Nguoi - Mot Dong Song.");
			printf("\n May Ai Lam Ke Dung Trong Ben Bo.");
			printf("\n 5 Bai Tho Ngan Ma Sau Nang Tinh Co Tro Anh 3.");
			printf("\n Muon Qua Song Phai Luy Do.");
			printf("\n Duong Doi Muon Buoc Cay Nho Nho Nguoi Dua.");
			printf("\n Thang Nam Dau Dai Nang Mua.");
			printf("\n Con Do Tri Thuc Co Dua Bao Nguoi.");
			printf("\n Qua Song Gui Lai Nu Cuoi. ");
			printf("\n Tinh Yeu Xin Tang Nguoi Co Kinh Thuong.");
			printf("\n Con Do Moc - Mai Dau Suong.");
			printf("\n Mai Theo Ta Khap Muon Phuong Van Ngay.");
			printf("\n Khuc Song Ay Van Con Day.");
			printf("\n Co Dua Tiep Nhung Do Day Qua Song.");
		    printf("\n Chuc Co Luon Thanh Cong Trong Su Nghiep Nguoi Lai Do Cua FPT Ha Noi.");
			printf("\n Cam On Co Mot Giang Vien Cua Pho Thong Cao Dang FPT Ha Noi.");	
			} else {
				if (strcmp( n , "Co_Ngoc_Ngan") == 0 ) {
					printf("\n Hom Nay 20 Thang 11 Nhung Con Khung Ve Duoc.");
					printf("\n Danh Nhan Gui Toi Nguoi Co Con Nho Nhat");
					printf("\n Con Chuc Co Ngan Luon Luon Vui Ve.");
					printf("\n Luon Xinh Dep.");
					printf("\n Luon Thanh Cong Trong Su Nghiep Nguoi Lai Do.");
					printf("\n Cam Co Vi Da Da Giup Con Tu Tin Hon Trong Giao Tiep.");
					printf("\n Cam On Co Mot Nguoi Lai Do Cua FPT Bac Giang.");
					printf("\n Loi Nhan Tu Hoc Tro Yeu Quy Cua Co.");
				} else {
					if (strcmp ( n , "Nguyen_Thi_Thuy") == 0) {
		printf("\n Hom Nay 20 Thang 11 Khung Gap Duoc Co Nhung .");
		printf("\n Thoi Gui Co Nhung Dong Tri An Nay Vay.");
		printf("\n Con Chuc Co Thuy Vui Tuoi Moi Ngay.");
		printf("\n Chuc Co Luon Xinh Dep.");
		printf("\n Thanh Cong Trong Su Nghiep Nguoi Lai Do.");
		printf("\n Du It Gap Co Hon Nhung Co Van Trong Tim Con.");
		printf("Tang Co Nhung Dong Tho Cua Tac Gia Nguyen Trung Dung");
		printf("\n Nguoi Mang Anh Sang Soi Doi Tre.");
		printf("\n Lai Chuyen Do Chieu Xang Ben Day.");
		printf("\n Do Den Vinh Quang Noi Dat La.");
		printf("\n Cam On Nguoi Da Lai Do Hay.");
		printf("\n On Nay Tro Mai Ghi Trong Da.");
		printf("\n Nguoi Da Giup Con Vuot Qua Dang Cay.");
		printf("\n Cam On Co Mot Giang Vien Cua FPT Bac Giang.");
		printf("\n Loi Nhan Tu Nguoi Hoc Tro Co Luon Yeu Quy.");
		printf("\n Mai Yeu  Co Mai Nhi .");
		} else {
			if (strcmp ( n , "Bui_Thi_Trang") == 0) {
		printf("\n Hom Nay 20 Thang 11 .");
		printf("\n Thoi Gui Co Trang Dong Tri An Nay Vay.");
		printf("\n Con Chuc Co Trang Vui Tuoi Moi Ngay.");
		printf("\n Chuc Co Luon Xinh Dep.");
		printf("\n Thanh Cong Trong Su Nghiep Nguoi Lai Do.");
		printf("\n Cam On Co Vi Da Luon Chi Day Con Nhung Dieu Moi Me.");
		printf("\n Tang Co Nhung Dong Tho Cua Tac Gia Nguyen Trung Dung");
		printf("\n Nguoi Mang Anh Sang Soi Doi Tre.");
		printf("\n Lai Chuyen Do Chieu Xang Ben Day.");
		printf("\n Do Den Vinh Quang Noi Dat La.");
		printf("\n Cam On Nguoi Da Lai Do Hay.");
		printf("\n On Nay Tro Mai Ghi Trong Da.");
		printf("\n Nguoi Da Giup Con Vuot Qua Dang Cay.");
		printf("\n Cam On Co Mot Giang Vien Cua Pho Thong Cao Dang FPT Mai Trong Tim Toi.");
		printf("\n Loi Nhan Tu Nguoi Hoc Tro Co Luon Yeu Quy.");
		} else {
			if (strcmp ( n , "Co_Hien") == 0) {
			printf("\n Hom Nay 20 Thang 11 Mac Du Con Khung Ve Duoc Nhung Van Luon Nho Toi Co .");
			printf("\n Danh Phai Gui Qua Nhung Cau Chu Nay Thui.");
			printf("\n Con Chuc Co Hien Luon Luon Vui Ve Moi Ngay.");
			printf("\n Chuc Co Luon Xinh Dep.");
			printf("\n Mai La Co Giao Dac Biet Trong Tim Hoc Tro .");
			printf("\n Gui Co Nhung Loi Tho Cua Tac Gia Thao Nguyen.");
			printf("\n Mot Doi Nguoi - Mot Dong Song.");
			printf("\n May Ai Lam Ke Dung Trong Ben Bo.");
			printf("\n 5 Bai Tho Ngan Ma Sau Nang Tinh Co Tro Anh 3.");
			printf("\n Muon Qua Song Phai Luy Do.");
			printf("\n Duong Doi Muon Buoc Cay Nho Nho Nguoi Dua.");
			printf("\n Thang Nam Dau Dai Nang Mua.");
			printf("\n Con Do Tri Thuc Co Dua Bao Nguoi.");
			printf("\n Qua Song Gui Lai Nu Cuoi. ");
			printf("\n Tinh Yeu Xin Tang Nguoi Co Kinh Thuong.");
			printf("\n Con Do Moc - Mai Dau Suong.");
			printf("\n Mai Theo Ta Khap Muon Phuong Van Ngay.");
			printf("\n Khuc Song Ay Van Con Day.");
			printf("\n Co Dua Tiep Nhung Do Day Qua Song.");
		    printf("\n Luon Thanh Cong Trong Su Nghiep Nguoi Lai Do Cua FPT Ha Noi.");
			printf("\n Cam On Co Mot Giang Vien Cua Pho Thong Cao Dang FPT Ha Noi.");	
			printf("\n Loi Nhan Gui Tu Nguoi Hoc Tro Co Luon Yeu Quy .");
			} else { 
				if (strcmp ( n , "Co_Linh") == 0) {
		printf("\n Hom Nay 20 Thang 11 Nhung Con Khung Ve Duoc.");
		printf("\n Thoi Gui Co Nhung Dong Tri An Nay Vay.");
		printf("\n Con Chuc Co Linh Vui Tuoi Moi Ngay.");
		printf("\n Chuc Co Luon Xinh Dep.");
		printf("\n Thanh Cong Trong Su Nghiep Nguoi Lai Do.");
		printf("\n Nho Toi Co Vi Nhung Buc Tranh Dep Ne.");
		printf("\n Tang Co Nhung Dong Tho Cua Tac Gia Nguyen Trung Dung");
		printf("\n Nguoi Mang Anh Sang Soi Doi Tre.");
		printf("\n Lai Chuyen Do Chieu Xang Ben Day.");
		printf("\n Do Den Vinh Quang Noi Dat La.");
		printf("\n Cam On Nguoi Da Lai Do Hay.");
		printf("\n On Nay Tro Mai Ghi Trong Da.");
		printf("\n Nguoi Da Giup Con Vuot Qua Dang Cay.");
		printf("\n Cam On Co Mot Giang Vien Cua Pho Thong Cao Dang FPT Mai Trong Tim Toi.");
		printf("\n Loi Nhan Tu Nguoi Hoc Tro Co Luon Yeu Quy.");
		} else {
			if (strcmp (n , "Vu_Thi_Thuy") == 0) {
				printf("\n Hom Nay 20 Thang 11 Mac Du Khung Ve Duoc .");
				printf("\n Thoi Danh Gui Co Nhung Loi Tri An Nay Vay.");
				printf("\n Con Chuc Co Thuy Luon Vui Tuoi Moi Ngay");
				printf("\n Luon Xinh Dep.");
				printf("\n Luon Thanh Cong Trong Su Nghiep Nguoi Lai Do.");
				printf("\n Cam On Co Mot Nguoi Giao Vien Chu Nhiem Trong 3 Ky Vua Qua.");
				printf("\n Du It Gap Co Hon Nhung Co Van Mai Trong Tim Con.");
				printf("\n Cam On Mot Giang Vien Den Tu Pho Thong Cao Dang FPT Bac Giang.");
				printf("\n Loi Nhan Gui Tu Hoc Tro Yeu Quy Cua Co.");
				} else {
					if (strcmp ( n , "Co_Thu_Phuong") == 0) {
		printf("\n Hom Nay 20 Thang 11 .");
		printf("\n Thoi Gui Co Nhung Dong Tri An Nay Vay.");
		printf("\n Con Chuc Co Phuong Vui Tuoi Moi Ngay.");
		printf("\n Chuc Co Luon Xinh Dep Co Mot Suc Khoe Doi Dao.");
		printf("\n Thanh Cong Trong Su Nghiep Nguoi Lai Do.");
		printf("\n Cam On Co Vi Da Lam Giao Vien Chu Nhiem Cua Lop SD1901.");
		printf("\n Tang Co Nhung Dong Tho Cua Tac Gia Nguyen Trung Dung");
		printf("\n Nguoi Mang Anh Sang Soi Doi Tre.");
		printf("\n Lai Chuyen Do Chieu Xang Ben Day.");
		printf("\n Do Den Vinh Quang Noi Dat La.");
		printf("\n Cam On Nguoi Da Lai Do Hay.");
		printf("\n On Nay Tro Mai Ghi Trong Da.");
		printf("\n Nguoi Da Giup Con Vuot Qua Dang Cay.");
		printf("\n Cam On Co Mot Giang Vien Cua Pho Thong Cao Dang FPT Mai Trong Tim Toi.");
		printf("\n Loi Nhan Tu Nguoi Hoc Tro Co Luon Yeu Quy.");
		} else {
				if (strcmp ( n , "Nguyen_Thanh_Trung") == 0) {
			printf("\n Hom Nay 20 Thang 11 Mac Du Khung Duoc Hoc Thay Mon Nay.");
			printf("\n Con Chuc Thay Trung Luon Luon Vui Ve Moi Ngay.");
			printf("\n Cam On Nguoi Duoc Menh Danh La Sat Than Cua Fpoly Da Day Con Hai Mon.");
			printf("\n Mai La Nguoi Thay Dep Nhat Trong Tim Nguoi Hoc Tro .");
			printf("\n Gui Thay Nhung Loi Tho Cua Tac Gia Pham Minh Dung .");
			printf("\n Van Theo Toi Nhung Loi Nhac Nho .");
			printf("\n Moi Khi Toi Tim Duoc Vinh Quang  .");
			printf("\n Qua Buon Vui Qua Nhung Thang Tram  .");
			printf("\n Cau Tra Loi Sang Len Lap Lanh .");
			printf("\n Voi Toi Thay Ky Thac .");
			printf("\n Thay Gui Toi Khat Vong Nguoi Cha .");
			printf("\n Duong Van Dai Va Xa .");
			printf("\n Thay Giao Cu Don Toi Tung Buoc .");
			printf("\n Tung Buoc Mot Toi Buoc .");
			printf("\n Voi Ki Niem Thay Toi .");
		    printf("\n Luon Thanh Cong Trong Su Nghiep Nguoi Lai Do Cua FPT Ha Noi.");
			printf("\n Cam On Co Mot Giang Vien Cua Pho Thong Cao Dang FPT Ha Noi.");	
			printf("\n Loi Nhan Gui Tu Nguoi Hoc Tro Ma Thay Luon Yeu Quy .");
			} else {
				if (strcmp (n , "Nguyen_Thu_Uyen") == 0) {
					printf("\n Hom Nay 20 Thang 11 Mac Du Khung Ve Duoc .");
				printf("\n Thoi Danh Gui Co Nhung Loi Tri An Nay Vay.");
				printf("\n Con Chuc Co Uyen Luon Vui Tuoi Moi Ngay");
				printf("\n Luon Xinh Dep Suc Khoe Doi Dao.");
				printf("\n Chuc Co Luon Thanh Cong Trong Su Nghiep Nguoi Lai Do.");
				printf("\n Cam On Co Vi Nhung Trang Su Van Con Dong Trong Tam Chi Nguoi Hoc Tro Nay.");
				printf("\n Mac Du Con It Gap Co Hon Nhung Co Van Mai Trong Tim Con.");
				printf("\n Cam On Co Mot Nguoi Giang Vien Den Tu Pho Thong Cao Dang FPT Bac Giang.");
				printf("\n Cam On  Co Da Theo Con Trong 3 Ky Qua Voi Mon Su.");
			    printf("\n Loi Nhan Gui Tu Hoc Tro Yeu Quy Cua Co Uyen.");
			    } else { 
			    if (strcmp ( n , "Nguyen_Dung_Son") == 0) {
			    	printf("\n Hom Nay 20 Thang 11 Mac Du Khung Ve Duoc.");
			    	printf("\n Thoi Danh Gui Toi Thay Nhung Dong Tri An Nay .");
			    	printf("\n Con Chuc Thay Luon Luon Vui Tuoi.");
			    	printf("\n Chuc Thay Co Mot Suc Khoe Doi Dao.");
			    	printf("\n Chuc Thay Luon Thanh Cong Trong Su Nghiep Nha Giao.");
			    	printf("\n Con Cam On Thay Vi Da Cho Con Mot Moi Truong Hoc That Tot De Con Thoa Suc Hoc Hoi Va Sang Tao Trong 3 Ky Vua Qua.");
			    	printf("\n Cam On Thay Mot Giang Vien Toi Tu Pho Thong Cao Dang FPT Bac Giang.");
			    	printf("\n Loi Nhan Gui Tu Nguoi Hoc Tro Yeu Quy Cua Thay.");
				printf("\n Cac Thay Co Cua FPT Bac Giang Mai Dinh.");
				} else {
					}
}				
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
