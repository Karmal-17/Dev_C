#include <stdio.h>
int main(){
	// in ra cac so tu 1 den 5
	int i = 1;
	// Ban dau gia tri khoi tao cua i = 1
	while (i <= 5){
		// vong lap while se thuc hien cho den khi dieu kien i <= 5 khong con dung
		printf("%d\n",i);
		// moi vong lap thi chuong trinh se in ra 1 gia tri cua i
		i++;
		// moi vong lap chuong chinh se cho i tang len 1 gia tri
	}
	printf("\n vi du so 2: tinh tong tu 1 den n");
	int n, tong = 0, m =1;
	printf("\n Nhap Vao So Nguyen Duong n: ");
	scanf("%d",&n);
	
	while (m <= n){
		tong += m; // tong = tong + m
		m ++;
	
}
printf("Tong cac so tu 1 den %d la: %d\n",n, tong);
return 0;
}
