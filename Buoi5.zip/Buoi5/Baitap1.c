//tinh tich cac so chan tu 1 den n bang while
#include <stdio.h>
int main(){
	int n, tich = 1, i = 2;
	printf("Nhap gia tri so chan: ");
	scanf("%d",&n);
	printf("ban vua nhap la: %d\n",n);
	if (n % 2 != 0){
		printf("So %d Khong Phai La So Chan. Vui Long Nhap Lai.\n",n);
		return 1;
		}
	while (i <= n ){
		tich *= i;
		i += 2;
		}
		printf("Tich Cac so chan tu 1 den %d la : %d\n",n, tich);
		return 0;
		}
	
