#include <stdio.h>

int main(){
	int Giovao, Giora, Sogio;
	float tongtien = 0;
	printf("Nhap Giodau va gioketthuc trong khoang (12h den 23h): ");
	scanf("%d %d",&Giovao,&Giora);
	printf("\n Ban Vua Nhap Gio Bat Dau La: %d",Giovao);
	printf("\n Ban Vua Nhap Gio Ket Thuc La: %d",Giora);
	if(Giovao < 12 || Giovao >= 23 || Giora <= 12 || Giora > 23 || Giora <= Giovao ){
		printf("\n  Gio Ban Vua Nhap Khong Hop Le. Vui Long Nhap Lai! ");
		return 1;
		}
		Sogio = Giora - Giovao;
		if(Sogio <= 3 ){
			tongtien = Sogio * 150000;
			} else {
				tongtien = 3 * 150000;
				tongtien += (Sogio - 3 ) * 150000 *0.7;
				}
			 if (Giovao >= 14 && Giovao <= 17) {
        tongtien *= 0.9;
        }
        printf("\n So Tien Ban Can Phai Tra La: %f dong",tongtien);
        return 0;
}
