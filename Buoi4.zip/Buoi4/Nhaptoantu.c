#include <stdio.h>

int main(){
// Nhap vao toan tu: + - * / va in ra ket qua tuong ung voi a va b
    int a = 3, b = 10;
    char toantu;
    printf("Nhap phep toan: ");
    scanf("%s", &toantu);
    printf("Ban vua nhap\n", toantu);
    switch (toantu){
    	case '+':
    		printf("a + b = %d", a + b);
    		break;
    	case '-':
    		printf("a - b = %d", a - b);
    		break;
    	case '*':
    		printf("a * b = %d", a * b);
    		break;
    	case '/':
    		printf("a / b = %f", a / b);
    		break;
    	default:
    		printf("Gia Tri Nhap Khong Dung:) ");
	}
	return 0;
}
