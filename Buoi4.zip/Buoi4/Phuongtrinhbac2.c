#include <iostream>
#include <cmath> // Thu vi?n d? d�ng h�m sqrt
using namespace std;

int main() {
    // Khai b�o c�c h? s? c?a phuong tr�nh
    double a, b, c;
    cout << "Nhap he so a, b, c cua phuong trinh ax^2 + bx + c = 0: ";
    cin >> a >> b >> c;

    // Ki?m tra n?u a = 0
    if (a == 0) {
        if (b == 0) {
            if (c == 0) {
                cout << "Phuong trinh co vo so nghiem." << endl;
            } else {
                cout << "Phuong trinh vo nghiem." << endl;
            }
        } else {
            double x = -c / b;
            cout << "Phuong trinh co mot nghiem x = " << x << endl;
        }
    } else {
        // T�nh delta
        double delta = b * b - 4 * a * c;

        if (delta < 0) {
            cout << "Phuong trinh vo nghiem." << endl;
        } else if (delta == 0) {
            double x = -b / (2 * a);
            cout << "Phuong trinh co nghiem kep x = " << x << endl;
        } else {
            double x1 = (-b + sqrt(delta)) / (2 * a);
            double x2 = (-b - sqrt(delta)) / (2 * a);
            cout << "Phuong trinh co hai nghiem phan biet:" << endl;
            cout << "x1 = " << x1 << endl;
            cout << "x2 = " << x2 << endl;
        }
    }

    return 0;
}

