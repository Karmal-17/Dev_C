#include <stdio.h>
#include <math.h> // Include for sqrt function

int main() { // Corrected return type
    float a, b, c;
    float delta, x1, x2;

    // Input coefficients
    printf("Nhap he so a, b, c: ");
    scanf("%f %f %f", &a, &b, &c);

    printf("Ban Vua nhap: a = %f\n",a);
    printf("Ban Vua nhap: b = %f\n",b);
    printf("Ban Vua nhap: c = %f\n",c);

    if (a == 0) {
        if (b == 0) {
            if (c == 0) {
                printf("\nPhuong trinh co vo so nghiem.");
            } else {
                printf("\nPhuong trinh vo nghiem.");
            }
        } else {
            float x = -c / b;
            printf("\nPhuong trinh co nghiem duy nhat: x = %f\n", x);
        }
    } else {
        float delta = b * b - 4 * a * c;
        if (delta > 0) {
            float x1 = (-b + sqrt(delta)) / (2 * a);
            float x2 = (-b - sqrt(delta)) / (2 * a);
            printf("\nPhuong trinh co 2 nghiem phan biet:\n");
            printf("x1 = %f\n", x1);
            printf("x2 = %f\n", x2);
        } else if (delta == 0) {
            float x1 = -b / (2 * a);
            printf("\nPhuong trinh co nghiem kep:\n");
            printf("x1 = x2 = %f\n", x1);
        } else {
            printf("\nPhuong trinh vo nghiem (delta < 0).");
        }
    }

    return 0; // Return 0 for successful execution
}

