#include <stdio.h>
 
int main(){
	char diem;
	printf("Nhap diem cua bn vao day: ");
	scanf("%c", &diem);
	printf("Ban vua nhap: %c", diem);
	switch (diem){
		case 'A':
		    printf("\n Diem Xuat sac");
		break;
		case 'B':
			printf("\n Diem Gioi");
		break;
		case 'C':
			printf("\n Diem TB");
		break;
	default:
		printf("\n Bi Dup!");
    }
}
