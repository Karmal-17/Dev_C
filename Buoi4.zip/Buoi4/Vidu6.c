#include <stdio.h>
float main(){
	float a, b;
	float x;
	printf("Nhap He So Cua Ban La: ");
	scanf("%f %f", &a, &b);
	printf("Ban Vua Nhap: a = %f\n", a);
	printf("Ban Vua Nhap: b = %f\n", b);
	
	if (a != 0) {
		float x = -b / a;
		printf("\n Phuong Trinh Co Nghiem Duy Nhat.");
		printf("x = %f\n",x);
	} else {
		if (b == 0){
			printf("Phuong Trinh Co Vo So Nghiem.");
		} else{
			printf("Phuong Trinh Vo Nghiem.");
		}
	}
	return 0;
}
