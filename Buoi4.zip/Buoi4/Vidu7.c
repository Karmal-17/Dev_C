#include <stdio.h>
#include <math.h>
float main(){
	float a, b, c;
	float delta, x1, x2;
	printf("Nhap So a b c Vao Day Ne: ");
	scanf("%f %f %f",&a, &b, &c);
	printf("Ban Vua Nhap So a: %f\n",a);
	printf("Ban Vua Nhap So b: %f\n",b);
	printf("Ban Vua Nhap So c: %f\n",c);
	
	if (a == 0) {
		if (b != 0) {
			float x = - c / b;
			printf("\n Phuong Trinh Co Nghiem Duy Nhat.");
			printf("x = %f\n ",x);
			
		} else  {
			if (b == 0) {
				printf("\n Phuong Trinh Vo Nghiem.");
				
			} else { 
			printf("\n Phuong Trinh Co Vo So Nghiem.");
			}
		}
	} else {
		if (a != 0) {
			float delta = b * b - 4 * a * c;
			if (delta > 0 ) {
				float x1 = (- b + sqrt(delta)) / (2 * a);
				float x2 = (-b - sqrt(delta)) / (2 * a);
				
				printf("\n Phuong Trinh Co Hai Nghiem.");
				printf("x1 = %f\n",x1);
				printf("x2 = %f\n",x2);
				
		} else {
			if(delta == 0){
				x1 = x2 = - b / (2 * a);
				printf("\n Phuong Trinh Co Nghiem Kep.");
				printf("x1 = x2 = %f\n",x1 );
			}
		} else {
			printf("Phuong Trinh Vo Nghiem! (DELTA < 0)");
		}
		}
		}
		return 0;
}

