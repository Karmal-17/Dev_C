#include <stdio.h>
int main(){
	int n=3;
	printf("Nhap n = ");
	scanf("%d", &n);
	printf("/n Ban vua nhap la: %d", n);
	
	switch (n){
		case 1:
			printf("\n so mot");
			
		case 2:
			printf("\n so hai");
			
		case 3:
			printf("\n so ba");
			
		case 4:
			printf("\n so bon");
			
		case 5:
			printf("\n so nam");
			
		default:
			printf("\N DEFAULT");
	
	}
	return 0;
}

