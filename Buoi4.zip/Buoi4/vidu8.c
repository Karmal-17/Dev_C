#include <stdio.h>
#include <math.h>

int main() { // �?i ki?u tr? v? th�nh int
    float a, b, c;
    float delta, x1, x2;

    printf("Nhap so a, b, c vao day ne: ");
    scanf("%f %f %f", &a, &b, &c);
    printf("Ban vua nhap: a = %f\n", a);
    printf("Ban vua nhap: b = %f\n", b);
    printf("Ban vua nhap: c = %f\n", c);

    if (a == 0) { // Phuong tr�nh b?c nh?t ho?c v� nghi?m/v� s? nghi?m
        if (b != 0) {
            float x = -c / b;
            printf("\nPhuong trinh co nghiem duy nhat:\n");
            printf("x = %f\n", x);
        } else {
            if (c == 0) {
                printf("\nPhuong trinh co vo so nghiem.\n");
            } else {
                printf("\nPhuong trinh vo nghiem.\n");
            }
        }
    } else { // Phuong tr�nh b?c hai
        delta = b * b - 4 * a * c;
        if (delta > 0) {
            x1 = (-b + sqrt(delta)) / (2 * a);
            x2 = (-b - sqrt(delta)) / (2 * a);
            printf("\nPhuong trinh co hai nghiem phan biet:\n");
            printf("x1 = %f\n", x1);
            printf("x2 = %f\n", x2);
        } else if (delta == 0) {
            x1 = -b / (2 * a);
            printf("\nPhuong trinh co nghiem kep:\n");
            printf("x1 = x2 = %f\n", x1);
        } else {
            printf("\nPhuong trinh vo nghiem (delta < 0).\n");
        }
    }

    return 0; // Tr? v? 0 d? b�o chuong tr�nh ch?y th�nh c�ng
}

