#include <stdio.h>
int main(){
	int n;
	printf("Nhap n = ");
	scanf("%d", &n);
	printf("/n Ban vua nhap la: %d", n);
	
	switch (n){
		case 1:
			printf("\n so mot");
			break;
		case 2:
			printf("\n so hai");
			break;
		case 3:
			printf("\n so ba");
			break;
		case 4:
			printf("\n so bon");
			break;
		case 5:
			printf("\n so nam");
			break;
		default:
			printf("\N DEFAULT");
	
	}
	return 0;
}
	
