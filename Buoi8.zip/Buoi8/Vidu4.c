#include <stdio.h>
#include <math.h> // Thu vi?n h? tr? pow, sqrt

// H�m hi?n th? menu ch�nh
void hienThiMenuChinh() {
    printf("===== MENU CHINH =====\n");
    printf("1. Toan co ban\n");
    printf("2. Toan nang cao\n");
    printf("0. Thoat\n");
    printf("======================\n");
    printf("Nhap lua chon cua ban: ");
}

// H�m hi?n th? menu to�n co b?n
void hienThiMenuToanCoBan() {
    printf("\n===== TOAN CO BAN =====\n");
    printf("1. Cong (+)\n");
    printf("2. Tru (-)\n");
    printf("3. Nhan (*)\n");
    printf("4. Chia (/)\n");
    printf("0. Quay lai menu chinh\n");
    printf("=======================\n");
    printf("Nhap lua chon cua ban: ");
}

// H�m hi?n th? menu to�n n�ng cao
void hienThiMenuToanNangCao() {
    printf("\n===== TOAN NANG CAO =====\n");
    printf("1. Tinh luy thua (x^y)\n");
    printf("2. Can bac hai (sqrt(x))\n");
    printf("0. Quay lai menu chinh\n");
    printf("=========================\n");
    printf("Nhap lua chon cua ban: ");
}

// H�m x? l� to�n co b?n
void xuLyToanCoBan() {
    int luaChonCon;
    double so1, so2, ketQua;

    do {
        system("cls"); // X�a m�n h�nh
        hienThiMenuToanCoBan();
        scanf("%d", &luaChonCon);

        switch (luaChonCon) {
            case 1: // C?ng
                printf("\nNhap so thu nhat: ");
                scanf("%lf", &so1);
                printf("Nhap so thu hai: ");
                scanf("%lf", &so2);
                ketQua = so1 + so2;
                printf("Ket qua: %.2lf + %.2lf = %.2lf\n", so1, so2, ketQua);
                break;

            case 2: // Tr?
                printf("\nNhap so thu nhat: ");
                scanf("%lf", &so1);
                printf("Nhap so thu hai: ");
                scanf("%lf", &so2);
                ketQua = so1 - so2;
                printf("Ket qua: %.2lf - %.2lf = %.2lf\n", so1, so2, ketQua);
                break;

            case 3: // Nh�n
                printf("\nNhap so thu nhat: ");
                scanf("%lf", &so1);
                printf("Nhap so thu hai: ");
                scanf("%lf", &so2);
                ketQua = so1 * so2;
                printf("Ket qua: %.2lf * %.2lf = %.2lf\n", so1, so2, ketQua);
                break;

            case 4: // Chia
                printf("\nNhap so thu nhat: ");
                scanf("%lf", &so1);
                printf("Nhap so thu hai: ");
                scanf("%lf", &so2);
                if (so2 == 0) {
                    printf("Loi: Khong the chia cho 0!\n");
                } else {
                    ketQua = so1 / so2;
                    printf("Ket qua: %.2lf / %.2lf = %.2lf\n", so1, so2, ketQua);
                }
                break;

            case 0:
                printf("Quay lai menu chinh...\n");
                break;

            default:
                printf("Lua chon khong hop le! Vui long chon lai.\n");
        }

        if (luaChonCon != 0) {
            printf("\nNhan phim bat ky de tiep tuc...\n");
            getchar(); // B? qua k� t? th?a
            getchar(); // D?ng m�n h�nh
        }
    } while (luaChonCon != 0);
}

// H�m x? l� to�n n�ng cao
void xuLyToanNangCao() {
    int luaChonCon;
    double so1, so2, ketQua;

    do {
        system("cls"); // X�a m�n h�nh
        hienThiMenuToanNangCao();
        scanf("%d", &luaChonCon);

        switch (luaChonCon) {
            case 1: // Luy th?a
                printf("\nNhap co so (x): ");
                scanf("%lf", &so1);
                printf("Nhap so mu (y): ");
                scanf("%lf", &so2);
                ketQua = pow(so1, so2);
                printf("Ket qua: %.2lf^%.2lf = %.2lf\n", so1, so2, ketQua);
                break;

            case 2: // Can b?c hai
                printf("\nNhap so can tinh can (x): ");
                scanf("%lf", &so1);
                if (so1 < 0) {
                    printf("Loi: Khong the tinh can bac hai cua so am!\n");
                } else {
                    ketQua = sqrt(so1);
                    printf("Ket qua: sqrt(%.2lf) = %.2lf\n", so1, ketQua);
                }
                break;

            case 0:
                printf("Quay lai menu chinh...\n");
                break;

            default:
                printf("Lua chon khong hop le! Vui long chon lai.\n");
        }

        if (luaChonCon != 0) {
            printf("\nNhan phim bat ky de tiep tuc...\n");
            getchar(); // B? qua k� t? th?a
            getchar(); // D?ng m�n h�nh
        }
    } while (luaChonCon != 0);
}

// H�m x? l� menu ch�nh
void xuLyMenuChinh() {
    int luaChonChinh;

    do {
        system("cls"); // X�a m�n h�nh
        hienThiMenuChinh();
        scanf("%d", &luaChonChinh);

        switch (luaChonChinh) {
            case 1:
                xuLyToanCoBan();
                break;
            case 2:
                xuLyToanNangCao();
                break;
            case 0:
                printf("Dang thoat chuong trinh...\n");
                break;
            default:
                printf("Lua chon khong hop le! Vui long chon lai.\n");
        }

        if (luaChonChinh != 0) {
            printf("\nNhan phim bat ky de quay lai menu chinh...\n");
            getchar(); // B? qua k� t? th?a
            getchar(); // D?ng m�n h�nh
        }
    } while (luaChonChinh != 0);
}

int main() {
    xuLyMenuChinh();
    return 0;
}

