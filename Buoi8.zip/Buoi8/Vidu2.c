#include <stdio.h>
#include <math.h>
#include <stdlib.h>
void HienThiMeNu(){

	printf("Chon Phep Toan Cua Ban Nhe: ");
	printf("\n 1.Tinh Luy Thua.");
	printf("\n 2.Tinh Can Bac 2.");
	printf("\n 3.Tinh Gia Tri Tuyet Doi.");
	printf("\n 4.Thoat Chuong Trinh.");
	printf("\n Moi Ban Cho So: ");
}
void SuLy(int LuaChon){
	switch (LuaChon){
		case 1:{
			
			int a,b;
			printf("\n Moi Ban Nhap So Co So: ");
			scanf("\n %d",&a);
			printf("\n Moi Ban Nhap So+ Mu: ");
			scanf("\n %d",&b);
			printf("\n Ket Qua Cua Ban La: %.2lf\n",(double)pow(a,b));
			break;
			}
		case 2:{

			int c;
			printf("\n Nhap So Ban Muon: ");
			scanf("\n %d",&c);
			if (c < 0) {
                printf("\nKhong The Tinh Can Bac 2 Cua So Am.\n");
            } else {
                printf("\nKet Qua Cua Ban La: %.2lf\n", (double)sqrt(c));
            }
			
			break;
		}
		case 3:{
		
			int d;
			printf("\n Nhap So Ban Muon: ");
			scanf("%d",&d);
			printf("\nGia Tri Tuyet Doi Cua %d La: %d\n", d, abs(d));
			break;
		}
		case 4:{
		
			printf("\n Thoat Truong Trinh Tinh.");
			break;
		}
		default:
			printf("\n Lua chon khong hop le, vui long thu lai.\n");
			
}
}
int main(){
	int LuaChon;
	do {
	HienThiMeNu();
	scanf("%d", &LuaChon);
	SuLy(LuaChon);	
	} while (LuaChon != 4);
	return 0;
}
