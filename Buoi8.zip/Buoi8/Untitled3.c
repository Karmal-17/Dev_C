#include <stdio.h>
#include <math.h>
#include <stdlib.h>

// H�m hi?n th? menu
void HienThiMeNu() {
    printf("Chon Phep Toan Cua Ban Nhe:\n");
    printf("1. Tinh Luy Thua\n");
    printf("2. Tinh Can Bac 2\n");
    printf("3. Tinh Gia Tri Tuyet Doi\n");
    printf("4. Thoat Chuong Trinh\n");
    printf("Moi Ban Chon So: ");
}

// H�m x? l� l?a ch?n
void SuLy(int Luachon) {
    switch (Luachon) {
        case 1: { // T�nh luy th?a
            int a, b;
            printf("\nMoi Ban Nhap Co So: ");
            scanf("%d", &a);
            printf("\nMoi Ban Nhap So Mu: ");
            scanf("%d", &b);
            printf("\nKet Qua Cua Ban La: %.2lf\n", pow(a, b));
            break;
        }
        case 2: { // T�nh can b?c 2
            int c;
            printf("\nNhap So Ban Muon: ");
            scanf("%d", &c);
            if (c < 0) {
                printf("\nKhong The Tinh Can Bac 2 Cua So Am.\n");
            } else {
                printf("\nKet Qua Cua Ban La: %.2lf\n", sqrt(c));
            }
            break;
        }
        case 3: { // T�nh gi� tr? tuy?t d?i
            int d;
            printf("\nNhap So Ban Muon: ");
            scanf("%d", &d);
            printf("\nGia Tri Tuyet Doi Cua %d La: %d\n", d, abs(d));
            break;
        }
        case 4: // Tho�t chuong tr�nh
            printf("\nThoat Chuong Trinh.\n");
            break;
        default: // L?a ch?n kh�ng h?p l?
            printf("\nLua Chon Khong Hop Le, Vui Long Thu Lai.\n");
            break;
    }
}

// H�m main
int main() {
    int LuaChon;
    do {
        HienThiMeNu();
        scanf("%d", &LuaChon);
        SuLy(LuaChon);
    } while (LuaChon != 4);

    return 0;
}

