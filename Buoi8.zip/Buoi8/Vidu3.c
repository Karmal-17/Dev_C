#include <stdio.h>

int main() {
    int mainOption = 1;
    int subOption = 2;

    switch (mainOption) {
        case 1:
            printf("Main Option 1\n");

            // Switch-case b�n trong
            switch (subOption) {
                case 1:
                    printf("Sub Option 1\n");
                    break;
                case 2:
                    printf("Sub Option 2\n");
                    break;
                default:
                    printf("Invalid Sub Option\n");
                    break;
            }
            break;

        case 2:
            printf("Main Option 2\n");
            break;

        default:
            printf("Invalid Main Option\n");
            break;
    }

    return 0;
}

