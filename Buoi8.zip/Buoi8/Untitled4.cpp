#include <iostream>
#include <cmath>    // Thu vi?n h? tr? to�n h?c n�ng cao (pow, sqrt)
#include <cstdlib>  // Thu vi?n h? tr? system("cls") tr�n Windows
using namespace std;

// H�m hi?n th? menu ch�nh
void hienThiMenuChinh() {
    cout << "===== MENU CHINH =====" << endl;
    cout << "1. Toan co ban" << endl;
    cout << "2. Toan nang cao" << endl;
    cout << "0. Thoat" << endl;
    cout << "======================" << endl;
    cout << "Nhap lua chon cua ban: ";
}

// H�m hi?n th? menu to�n co b?n
void hienThiMenuToanCoBan() {
    cout << "\n===== TOAN CO BAN =====" << endl;
    cout << "1. Cong (+)" << endl;
    cout << "2. Tru (-)" << endl;
    cout << "3. Nhan (*)" << endl;
    cout << "4. Chia (/)" << endl;
    cout << "0. Quay lai menu chinh" << endl;
    cout << "=======================" << endl;
    cout << "Nhap lua chon cua ban: ";
}

// H�m hi?n th? menu to�n n�ng cao
void hienThiMenuToanNangCao() {
    cout << "\n===== TOAN NANG CAO =====" << endl;
    cout << "1. Tinh luy thua (x^y)" << endl;
    cout << "2. Can bac hai (sqrt(x))" << endl;
    cout << "0. Quay lai menu chinh" << endl;
    cout << "=========================" << endl;
    cout << "Nhap lua chon cua ban: ";
}

int main() {
    int luaChonChinh, luaChonCon; // Bi?n d? luu l?a ch?n
    double so1, so2, ketQua;      // Bi?n luu c�c gi� tr? t�nh to�n

    do {
        system("cls"); // X�a m�n h�nh (Windows)
        hienThiMenuChinh();
        cin >> luaChonChinh;

        switch (luaChonChinh) {
            case 1: // To�n co b?n
                do {
                    system("cls");
                    hienThiMenuToanCoBan();
                    cin >> luaChonCon;

                    switch (luaChonCon) {
                        case 1: // C?ng
                            cout << "\nNhap so thu nhat: ";
                            cin >> so1;
                            cout << "Nhap so thu hai: ";
                            cin >> so2;
                            ketQua = so1 + so2;
                            cout << "Ket qua: " << so1 << " + " << so2 << " = " << ketQua << endl;
                            break;

                        case 2: // Tr?
                            cout << "\nNhap so thu nhat: ";
                            cin >> so1;
                            cout << "Nhap so thu hai: ";
                            cin >> so2;
                            ketQua = so1 - so2;
                            cout << "Ket qua: " << so1 << " - " << so2 << " = " << ketQua << endl;
                            break;

                        case 3: // Nh�n
                            cout << "\nNhap so thu nhat: ";
                            cin >> so1;
                            cout << "Nhap so thu hai: ";
                            cin >> so2;
                            ketQua = so1 * so2;
                            cout << "Ket qua: " << so1 << " * " << so2 << " = " << ketQua << endl;
                            break;

                        case 4: // Chia
                            cout << "\nNhap so thu nhat: ";
                            cin >> so1;
                            cout << "Nhap so thu hai: ";
                            cin >> so2;
                            if (so2 == 0) {
                                cout << "Loi: Khong the chia cho 0!" << endl;
                            } else {
                                ketQua = so1 / so2;
                                cout << "Ket qua: " << so1 << " / " << so2 << " = " << ketQua << endl;
                            }
                            break;

                        case 0:
                            cout << "Quay lai menu chinh...\n";
                            break;

                        default:
                            cout << "Lua chon khong hop le! Vui long chon lai.\n";
                    }

                    if (luaChonCon != 0) {
                        cout << "\nNhan phim bat ky de tiep tuc...";
                        cin.ignore();
                        cin.get();
                    }
                } while (luaChonCon != 0);
                break;

            case 2: // To�n n�ng cao
                do {
                    system("cls");
                    hienThiMenuToanNangCao();
                    cin >> luaChonCon;

                    switch (luaChonCon) {
                        case 1: // Luy th?a
                            cout << "\nNhap co so (x): ";
                            cin >> so1;
                            cout << "Nhap so mu (y): ";
                            cin >> so2;
                            ketQua = pow(so1, so2);
                            cout << "Ket qua: " << so1 << "^" << so2 << " = " << ketQua << endl;
                            break;

                        case 2: // Can b?c hai
                            cout << "\nNhap so can tinh can (x): ";
                            cin >> so1;
                            if (so1 < 0) {
                                cout << "Loi: Khong the tinh can bac hai cua so am!" << endl;
                            } else {
                                ketQua = sqrt(so1);
                                cout << "Ket qua: sqrt(" << so1 << ") = " << ketQua << endl;
                            }
                            break;

                        case 0:
                            cout << "Quay lai menu chinh...\n";
                            break;

                        default:
                            cout << "Lua chon khong hop le! Vui long chon lai.\n";
                    }

                    if (luaChonCon != 0) {
                        cout << "\nNhan phim bat ky de tiep tuc...";
                        cin.ignore();
                        cin.get();
                    }
                } while (luaChonCon != 0);
                break;

            case 0: // Tho�t
                cout << "Dang thoat chuong trinh...\n";
                break;

            default:
                cout << "Lua chon khong hop le! Vui long chon lai.\n";
        }

        if (luaChonChinh != 0) {
            cout << "\nNhan phim bat ky de quay lai menu chinh...";
            cin.ignore();
            cin.get();
        }
    } while (luaChonChinh != 0);

    return 0;
}

