#include <stdio.h>
#include <math.h>
#include <stdlib.h>

void HienThiMenu(){
	printf("\n-----------MENU CHINH---------------");
	printf("\n+ 1. Cac Phep Toan Co Ban.         +");
	printf("\n+ 2. Cac Phep Toan Nang Cao.       +");
	printf("\n+ 3. Nhung Giang Vien Van Hoa.     +");
	printf("\n+ 4. Nhung Giang Vien Chuyen Nganh.+");
	printf("\n+ 5. Ket Thuc Chuong Trinh.        +");
	printf("\n------------------------------------");
	printf("\n Vui Long Lua Chon Ban Muon:  ");
}


void HienThiMenu1(){
	printf("\n----------MENU CAC PHEP TOAN CO BAN----------");
	printf("\n+ 1.Phep Toan Cong.                          ");
	printf("\n+ 2.Phep Toan Tru.                           ");
	printf("\n+ 3.Phep Toan Nhan.                          ");
	printf("\n+ 4.Phep Toan Chia.                          ");
	printf("\n+ 0.Thoat Khoi Chuong Trinh Phep Tinh Co Ban.");
	printf("\n---------------------------------------------");
	printf("\n Vui Long Lua Chon Ban Muon: ");
	}
void SuLy(){
	int LuaChon1;
	double a, b,ketqua;
	do {
	system("cls");
	HienThiMenu1();
	scanf("%d", &LuaChon1);	
	
	switch(LuaChon1){
		    case 1:{
		    printf("\n Day La Phep Tinh Tong Nhe.");
			printf("\n Moi Ban Nhap So Thu Nhat: ");
			scanf("%lf",&a);
			printf("\n Moi Ban Nhap So Thu Hai: ");
			scanf("%lf",&b);
			double Ketqua = a + b ;
			printf("\n Ket Qua Cua %.2lf Va %.2lf La: %.2lf.",a,b,Ketqua);
			
			break;
		    }
		    case 2:{
		    printf("\n Day La Phep Tinh Tru Nhe.");
		    printf("\n Moi Ban Nhap So Thu Nhat: ");
			scanf("%lf",&a);
			printf("\n Moi Ban Nhap So Thu Hai: ");
			scanf("%lf",&b);
			double Ketqua = a - b;
			printf("\n Ket Qua Cua %lf Va %lf La: %.2lf.",a,b,Ketqua);
				break;
			}
			case 3:{
			printf("\n Day La Phep Tinh Nhan Nhe.");
			printf("\n Moi Ban Nhap So Thu Nhat: ");
			scanf("%lf",&a);
			printf("\n Moi Ban Nhap So Thu Hai: ");
			scanf("%lf",&b);
			double Ketqua = a * b;
			printf("\n Ket Qua Cua %.2lf Va %.2lf La: %.2lf.",a,b,Ketqua);	
				break;
			}
			case 4: {
			printf("\n Day La Phep Tinh Chia Nhe.");
			printf("\n Moi Ban Nhap So Thu Nhat: ");
			scanf("%lf",&a);
			printf("\n Moi Ban Nhap So Thu Hai: ");
			scanf("%lf",&b);
			if (b != 0){
				double Ketqua = a / b ;
				printf("\n Ket Qua Cua %.2lf Va %.2lf La: %.2lf.",a,b,Ketqua);
				
			} else {
				printf("\n Phep Tinh Bi Loi Khi b = 0 !");
			}
				break;
			}
			case 0:{
				printf("\n Cam On Ban Da Tinh.");
				printf("\n Dang Quay Lai Menu Chinh");
				
				break;
			}
			default:
				printf("\n Nhap Sai So Rui! Xin Vui Long Nhap Lai.");
		}
		if (LuaChon1 != 0){
			printf("\n Nhan Phim Bat Ki De Tiep Tuc Nhe ....");
			getchar();
			getchar();
		}
	}
	while (LuaChon1 != 0);
}
	
	
void HienThiMenu2(){
	printf("\n-----------MENU CAC PHEP TOAN NANG CAO-----------");
	printf("\n+ 1.Phep Toan Luy Thua.                         +");
	printf("\n+ 2.Phep Toan Tinh Can Bac Hai.                 +");
	printf("\n+ 3.Phep Toan Tinh Can Bac Ba.                  +");
	printf("\n+ 4.Phep Toan Tinh Gia Tri Tuyet Doi.           +");
	printf("\n+ 5.Phep Toan Lam Tron .                        +");
	printf("\n+ 6.Phep Toan Tinh Phuong Trinh Bac Hai.        +");
	printf("\n+ 7.Phep Toan Tinh Phuong Trinh Bac Nhat.       +");
	printf("\n+ 0.Thoat Khoi Chuong Trinh Phep Tinh Nang Cao. +");
	printf("\n-------------------------------------------------");
	printf("\n Vui Long Lua Chon Ban Muon: ");
	}
void SuLy2(){
	int LuaChon2;
	double a,b,c,Ketqua;
	do{ 
		system("cls");
		HienThiMenu2();
		scanf("%d",&LuaChon2);
		switch (LuaChon2){
			case 1 : {
				printf("\n Day La Phep Tinh Luy Thua.");
				printf("\n Moi Ban Nhap Phan Co So: ");
				scanf("%lf",&a);
				printf("\n Moi Ban Nhap Phan So Mu: ");
				scanf("%lf",&b);
				printf("\n Ket Qua Cua Phep Toan Luy Thua La: %.2lf",pow(a,b));
				
				break;
			}
			case 2 : {
				printf("\n Day La Phep Tinh Can Bac Hai Nhe.");
				printf("\n Moi Ban Nhap So : ");
				scanf("%lf",&a);
				if (a > 0){
					printf("\n Ket Qua Can Bac Hai Cua %lf La: %.2lf .",a,sqrt(a));
				} else {
					printf("\n Khong The Thuc Hien Phep Toan Vi %lf Be Hon 0!",a);
				}				
				break;
			}
			case 3: {
				printf("\n Day La Phep Tinh Can Bac Ba Nhe.");
			    printf("\n Moi Ban Nhap So : ");
				scanf("%lf",&a);
				if (a < 0){
					printf("\n Khong The Thuc Hien Duoc Vi %lf Be Hon 0!",a);
				} else {
					printf("\n Ket Qua Can Bac Ba Cua %lf La: %.2lf",a,cbrt(a));
				}	
				break;
			}
			case 4: {
				printf("\n Day La Phep Tinh Gia Tri Tuyet Doi Nhe.");
			    printf("\n Moi Ban Nhap So : ");
				scanf("%lf",&a);
				printf("\n Gia Tri Tuyet Doi Cua %lf La: %.2lf",a,fabs(a));
// sai code				printf("\n Gia Tri Tuyet Doi Cua %lf La: %.2lf",a,(double)abs(a));
				break;
			}
			case 5: {
				printf("\n Day La Phep Toan Lam Tron So Nhe.");
				printf("\n Nhap So Ban Muon: ");
				scanf("%lf",&a);
				printf("\n Gia Tri Lam Tron Cua So %lf La: %.0lf",a,round(a));
				break;
			}
			case 6: {
				printf("\n Day La Phep Toan Tinh Can Bac Hai Nhe.");
				printf("\n Moi Ban Nhap So a: ");
				scanf("%lf",&a);
				printf("\n Moi Ban Nhap So b: ");
				scanf("%lf",&b);
				printf("\n Moi Ban Nhap So c: ");
				scanf("%lf",&c);
				double x = - c / a ;
				if (a == 0){
					if (b == 0){
						if (c == 0){
							printf("\n %.2lf * x^2 + %.2lf * x + %.2lf = 0",a,b,c);
							printf("\n Phuong Trinh Co Vo So Nghiem.");
						} else {
							printf("\n %.2lf * x^2 + %.2lf * x + %.2lf = 0",a,b,c);
							printf("\n Phuong Trinh Vo Nghiem.");
						}
						
					} else {
						printf("\n %.2lf * x^2 + %.2lf * x + %.2lf = 0",a,b,c);
						printf("\n Phuong Trinh Co Nghiem Duy Nhat.");
						printf("%.2lf",x);
					}
				} else {
					double delta =  b * b - 4 * a * c ;
					if (delta > 0 ) {
						printf("\n %.2lf * x^2 + %.2lf * x + %.2lf = 0",a,b,c);
						printf("\n Phuong Trinh Co Hai Nghiem Phan Biet.");
						double x1 = (- b + sqrt(delta)) / (2 * a);
						double x2 = (- b - sqrt(delta)) / (2 * a);
						printf("%.2lf",x1);
						printf("%.2lf",x2);
					} else {
						if (delta == 0){
							printf("\n %.2lf * x^2 + %.2lf * x + %.2lf = 0",a,b,c);
							printf("\n Phuong Trinh Co Nghiem Kep.");
							double x1 = - b / (2 * a);
							printf("%.2lf",x1);
						} else {
						printf("\n %.2lf * x^2 + %.2lf * x + %.2lf = 0",a,b,c);
						printf("\n Phuong Trinh Vo Nghiem.");
					    }
					} 
				}
				break;
			}
			case 7: {
				printf("\n Day La Phep Tinh Can Bac Nhat Nhe.");
				printf("\n Moi Ban Nhap So a: ");
				scanf("%lf",&a);
				printf("\n Moi Ban Nhap So b: ");
				scanf("%lf",&b);
				if (a != 0){
					double x = - b / a ;
					printf("\n Phuong Trinh Co Nghiem Duy Nhat.");
					printf("%.2lf",x);
				} else {
					if (a == 0) {
						if (b == 0){
							printf("\n PhuongTrinh Co Vo So Nghiem.");
						} else {
							printf("\n Phuong Trinh Vo Nghiem.");
						}
					}
				}
				break;
			}
			case 0: {
			printf("\n Dang Thoat Khoi Chuong Trinh Cac Phep Toan Nang Cao.");
			printf("\n Cam On Ban Da Tinh.");	
				break;
			}
			default : 
			printf("\n Ban Nhap Sai So Rui ! Vui Long Nhap Lai.");
		}
// Sau Switch Moi Duoc Dung if Kieu N�y Nhe 
		if (LuaChon2 != 0){
			printf("\n Vui Long Nhan Bat Ki Phim Nao......");
			getchar(); // Loai Bo Cac Ki Tu Thua
			getchar(); // Loai Bo Phim
		} 
	}
// Het Do Moi Duoc Dung While
	 while (LuaChon2 != 0);
} 


void HienThiMenu3(){
	printf("\n--------MENU CAC GIANG VIEN VAN HOA---------");
	printf("\n+ 1.Nguyen Thi Thanh.                      +");
	printf("\n+ 2.Nguyen Phuong Thao.                    +");
	printf("\n+ 3.Nguyen Thi Thuy.                       +");
	printf("\n+ 4.Nguyen Thu Uyen.                       +");
	printf("\n+ 5.Do Nhat Minh.                          +");
	printf("\n+ 6.Ngo Thi Ngan.                          +");
	printf("\n+ 7.Vu Thi Thuy.                           +");
	printf("\n+ 8.Vu Thi Dinh.                           +");
	printf("\n+ 9.Ngo Thi Thu Hien.                      +");
	printf("\n+ 0.Thoat Khoi Menu Cac Giang Vien Van Hoa.+");
	printf("\n--------------------------------------------");
	printf("\n Vui Long Lua Chon Giang Vien Yeu Thich: ");
	}
void SuLy3(){
	int LuaChon3;
	do {
		system("cls");
		HienThiMenu3();
		scanf("%d",&LuaChon3);
		switch (LuaChon3){
		case 1: {
			printf("\n Ho va Ten: Nguyen Thi Thanh.");
			printf("\n Giang Vien Day Ngu Van Cua PTCD FPT BACGIANG.");
			printf("\n Rat Vui Tinh.");
			break;
		}
		case 2: {
			printf("\n Ho va Ten: Nguyen Phuong Thao.");
			printf("\n Giang Vien Day Mon Toan Cua PTCD FPT BAC GIANG.");
			printf("\n Biet Danh: Phu Ba An Danh.");
			printf("\n Rat Vui Tinh");
			break;
		}
		case 3: {
			printf("\n Ho va Ten: Nguyen Thi Thuy.");
			printf("\n Giang Vien Day Mon Vat Ly Cua PTCD FPT BAC GIANG.");
			printf("\n Xinh Va Rat Vui Tinh.");
			break;
		}
		case 4: {
			printf("\n Ho va Ten: Nguyen Thu Uyen");
			printf("\n Giang Vien Day Mon Lich Su Cua PTCD FPT BAC GIANG");
			printf("\n Xinh Va Rat Vui Tinh.");
			break;
		}
		case 5: {
			printf("\n Ho va Ten: Do Nhat Minh.");
			printf("\n Giang Vien Day Mon Toan Cua PTCD FPT BAC GIANG.");
			printf("\n Rat Dep Troai Va Vui Tinh.");
			break;
		}
		case 6: {
			printf("\n Ho va Ten: Ngo Thi Ngan.");
			printf("\n Giang Vien Mon Ky Nang Mem Cua PTCD FPT BAC GIANG.");
			printf("\n Xinh Va Rat Vui Tinh.");
			break;
		}
		case 7: {
			printf("\n Ho va Ten: Vu Thi Thuy.");
			printf("\n Giang Vien Chu Nhiem K19 Cu aPTCD FPT BAC GIANG.");
			printf("\n Xinh Va Rat Vui Tinh.");
			break;
		}
		case 8: {
			printf("\n Ho va Ten: Vu Thi Dinh.");
			printf("\n Giang Vien Day Mon Tieng Anh Cua PTCD FPT HA NOI.");
			printf("\n Xinh Va Rat Vui Tinh.");
			break;
		}
		case 9: {
			printf("\n Ho va Ten: Ngo Thi Thu Huyen.");
			printf("\n Giang Vien Day Mon Php Luat Cua PTCD FPT HA NOI.");
			printf("\n Xinh Va Rat Vui Tinh.");
			break;
		}
		case 0: {
			printf("\n Thoat Khoi Chuong Trinh Menu Cac Giang Vien Day Mon Van Hoa.");
			break;
		}
		default :
		printf("\n Ban Da Nhap Sai So Rui ! Vui Long Nhap Lai Nhe.");
	    }
	    if (LuaChon3 != 0){
	    	printf("\n Nham Vao Phim Bat Ky De Tiep Tuc.");
	    	getchar();
	    	getchar();
		}
	}
	while (LuaChon3 != 0);
}	


void HienThiMenu4(){
	printf("\n---------MENU CAC GIANG VIEN CHUYEN NGANH---------");
	printf("\n+ 1.Nguyen Thanh Trung.                          +");
	printf("\n+ 2.Le Thi Huyen Dieu.                           +");
	printf("\n+ 0.Thoat Khoi Menu Cac Giang Vien Chuyen Nganh. +");
	printf("\n--------------------------------------------------");
	printf("\n Vui Long Lua Chon Giang Vien Yeu Thich: ");
	}
void SyLy4(){
	int LuaChon4;
	do {
		system("cls");
		HienThiMenu4();
		scanf("%d",&LuaChon4);
		switch (LuaChon4){
			case 1: {
				printf("\n Ho va Ten: Nguyen Thanh Trung.");
				printf("\nGiang Vien Mon Tin Va Nhap Mon Cong Nghe Thong Tin.");
				printf("\n Rat Vui Tinh.");
				break;
			}
			case 2: {
				printf("\n Ho va Ten: Le Thi Huyen Dieu.");
				printf("\n Giang Vien Mon Co So Du Lieu Va Nhap Mon Lap Trinh.");
				printf("\n Xinh Va Rat Vui Tinh");
				break;
			}
			case 0: {
				printf("Thaot Chuong Trinh Cac Thay Co Mon Chuyen Nghanh.");
				break;
			} 
			default :
				printf("\n Ban Da Chon Sai So rui ! Vui Long Chon Lai.");
		}
		if (LuaChon4 != 0){
			printf("\n Vui Long Nhan Bat Cu Phim Nao .........");
			getchar();
			getchar();
		}
	} 
	while (LuaChon4 != 0);
}	
	
	

int main() {
    int LuaChon;
    do {
        system("cls");
        HienThiMenu();
        scanf("%d", &LuaChon);
        switch (LuaChon) {
            case 1:
                SuLy();
                break;
            case 2:
                SuLy2();
                break;
            case 3:
                SuLy3();
                break;
            case 4:
                SyLy4();
                break;
            case 5:
                printf("\n Cam on ban da su dung chuong trinh!");
                break;
            default:
                printf("\n Lua chon khong hop le! Vui long chon lai.");
        }
        if (LuaChon != 5) {
            printf("\n Nhan phim bat ky de quay lai menu chinh...");
            getchar();
            getchar();
        }
    } while (LuaChon != 5);
    return 0;
}


