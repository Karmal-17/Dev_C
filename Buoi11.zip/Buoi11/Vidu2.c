#include <stdio.h>
#include <string.h>
void TimKiemKyTu (char a[],char n){
	int i;
	int TimKiem = 0;
	for (i = 0;a[i] != '\0';i++){
		if (a[i] == n){
			printf("\n Ky Tu Ban Tim La: %c O Vi Tri Thu %d.",n,i+1);
			TimKiem = 1;
		}
	}
	if (! TimKiem){
		printf("\n Trong Mang Khong Co Ky Tu Nao Nhu Ban Vua Nhap!");
	}
}
int main(){
	char a[100];
	char n;
	printf("\n Nhap Chuoi Ky Tu Ban Muon: ");
	gets(a);
//	fgets(a, sizeof(a), stdin);
//	a[strcspn(a, "\n")] = '\0';
	printf("\n Nhap Chuoi Ky Tu Can Tim: ");
	scanf("%c",&n);
	TimKiemKyTu(a,n);
	return 0;
}
