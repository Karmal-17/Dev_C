#include <stdio.h>
#include <stdio.h>

int main(){
// Nhap Chuoi Voi Scanf()
    char c[100],d[100];
    printf("\n Nhap Chuoi Ky Tu 1: ");
    scanf("%s",&c);
    printf("\n Chuoi Ky Tu 1 Vua Nhap La: %s\n",c);

    // Nha Chuoi Voi Ham Gets()
    printf("\n Nhap Chuoi Ky Tu 2: ");
    gets(d);
    printf("\n Chuoi Ky Tu 2 Vua Nhap La: %s\n",d);
    return 0;
}

