#include <stdio.h>
#include <stdlib.h>

void HienThiCon2() {
    printf("\n==== Ban Muon Thuc Hien Phep Tinh Tru Nao ====\n");
    printf("1. Phep Toan Tru Hai So.\n");
    printf("2. Phep Toan Tru Ba So.\n");
    printf("3. Phep Toan Tru Nhieu So.\n");
    printf("0. Thoat Chuong Trinh.\n");
    printf("=============================================\n");
}

void SuLyCon2() {
    int LuaChon2;
    do {
        system("cls"); // Ch? ho?t d?ng tr�n Windows
        HienThiCon2();
        printf("\nVui Long Chon So: ");
        scanf("%d", &LuaChon2);

        switch (LuaChon2) {
            case 1: {
                printf("\nDay La Phep Toan Tru Hai So.\n");
                int a, b, Hieu;
                printf("Nhap So Thu Nhat: ");
                scanf("%d", &a);
                printf("Nhap So Thu Hai: ");
                scanf("%d", &b);
                Hieu = a - b;
                printf("\nKet Qua Cua Hai So %d - %d = %d\n", a, b, Hieu);
                break;
            }
            case 2: {
                printf("\nDay La Phep Toan Tru Ba So.\n");
                int a, b, c, Hieu;
                printf("Nhap So Thu Nhat: ");
                scanf("%d", &a);
                printf("Nhap So Thu Hai: ");
                scanf("%d", &b);
                printf("Nhap So Thu Ba: ");
                scanf("%d", &c);
                Hieu = a - b - c;
                printf("\nKet Qua Cua Ba So %d - %d - %d = %d\n", a, b, c, Hieu);
                break;
            }
            case 3: {
                printf("\nDay La Phep Toan Tru Nhieu So.\n");
                int n;
                printf("Nhap So Luong Phan Tu: ");
                scanf("%d", &n);

                if (n <= 0) {
                    printf("\nSo Luong Phan Tu Phai Lon Hon 0.\n");
                    break;
                }

                int a[n],i;
                printf("Nhap Cac Phan Tu:\n");
                for ( i = 0; i < n; i++) {
                    printf("a[%d] = ", i + 1);
                    scanf("%d", &a[i]);
                }

                int hieu = a[0];
                for ( i = 1; i < n; i++) {
                    hieu -= a[i];
                }

                printf("\nKet Qua Phep Tinh Hieu %d So La: %d\n", n, hieu);
                break;
            }
            case 0: {
                printf("\nDang Thoat Chuong Trinh.\n");
                printf("\nCam On Ban Da Su Dung Chuong Trinh.\n");
                break;
            }
            default:
                printf("\nChon Sai So! Vui Long Chon Lai.\n");
        }

        if (LuaChon2 != 0) {
            printf("\nNhan Phim Bat Ky De Tiep Tuc...");
            getchar();
            getchar();
        }
    } while (LuaChon2 != 0);
}

int main() {
    SuLyCon2();
    return 0;
}

