#include <stdio.h>
#include <math.h>
#include <stdlib.h>

void HienThiCon2(){
	printf("\n ====Ban Muon Thuc Hien Phep Tinh Tru Nao===\n");
	printf("\n 1.Phep Toan Tru Hai So.");
	printf("\n 2.Phep Toan Tru Ba So.");
	printf("\n 3.Phep Toan Tru Nhieu So.");
	printf("\n 0.Thoat Chuong Trinh.");
	printf("\n =======================================\n");
}

void SuLyCon2(){
	int LuaChon2;
	do {
		system("cls");
		HienThiCon2();
		printf("\n Vui Long Chon So: ");
		scanf("%d",&LuaChon2);
		switch (LuaChon2){
			case 1 : {
				printf("\n Day La Phep Toan Tru Hai So.");
				int a,b,Hieu;
			    printf("\n Nhap So Thu Nhat:  ");
			    scanf("%d",&a);
			    printf("\n Nhap So Thu Hai:  ");
			    scanf("%d",&b);
			    Hieu = a - b;
			    printf("\n Ket Qua Cua Hai So %d Va %d La: %d",a,b,Hieu);
				break;
			}
			case 2: {
				printf("\n Day La Phep Toan Tru Ba So.");
				int a,b,c;
				int Hieu;
				printf("\n Nhap So Thu Nhat:  ");
			    scanf("%d",&a);
			    printf("\n Nhap So Thu Hai:  ");
			    scanf("%d",&b);
			    printf("\n Nhap So Thu Ba:  ");
			    scanf("%d",&c);
			    Hieu = a - b - c;
			    printf("\n Ket Qua Cua Ba So %d Va %d Va %d La: %d",a,b,c,Hieu);
				break;
			}
			case 3: {
				printf("\n Day La Phep Toan Tru Nhieu So.");
				int n,i;
				int a[n];
				for (i = 0;i < n;i ++){
					printf("\n Nhap So a[%d] = ",i+1);
					scanf("%d",&a[i]);
				}
				int hieu;
				for (i = 0 ; i < n ; i++){
					hieu -= a[i];
				}
				printf("Ket Qua Cua Phep Tinh Hieu %d So La: %d",n,hieu);
				break;
			}
			case 0:{
				printf("\n Dang Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Tinh.");
				break;
			}
			default :
				printf("\n Chon Sai So Rui! Vui Long Chon Lai So.");
		}
		if (LuaChon2 != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc......");
			getchar();
			getchar();
		}
	} while (LuaChon2 != 0);
}
int main(){
	int LuaChon;
	SuLyCon2();
	return 0;
}
