#include <stdio.h>
#include <math.h>
#include <stdlib.h>
void HienThiMeNuChinh(){
	printf("\n ========Menu Hai Mon=======\n");
	printf("\n 1.Menu Mon Toan.");
	printf("\n 2.Menu Mon Vat Ly");
	printf("\n 0.Thoat Chuong Trinh.");
	printf("\n ===========================\n");
}
void HienThiMeNuVatLy(){
	printf("\n =========Menu Mon Vat Ly=======\n");
	printf("\n 1.Phep Toan Tinh Van Toc.");
	printf("\n 2.Phep Toan Tinh Quang Duong.");
	printf("\n 3.Phep Toan Tinh Thoi Gian.");
	printf("\n 0.Thoat Chuong Trinh.");
	printf("\n ===============================\n");
}
void HienThiMeNuToan(){
	printf("\n =========Menu Toan=========\n");
	printf("\n 1.Nhung Phep Toan Co ban.");
	printf("\n 2.Nhung Phep Toan Nang Cao");
	printf("\n 0.Thoat Truong Trinh");
	printf("\n ============================\n");
}

void HienThiMeNu1(){
	printf("\n =======Menu Toan Co Ban======= \n");
	printf("\n 1.Phep Tinh Cong.");
	printf("\n 2.Phep Toan Tru.");
	printf("\n 3.Phep Tinh Nhan.");
	printf("\n 4.Phep Tinh Chia.");
	printf("\n 0.Thoat Chuong Trinh");
	printF("\n =============================== \n ");
}

void SuLyCon1(){
	int LuaChon1;
	do {
		system("cls");
		HienThiMenuCon1();
		printf("\n Nhap Lua Chon: ");
		scanf("%d",&LuaChon1);
		
		switch (LuaChon1){
			case 1: {
				printf("\n Day La Phep Toan Cong Toan Hai So.");
			    int a,b,c = 0;
			    printf("\n Nhap So Thu Nhat: ");
			    scanf("%d",&a);
			    printf("\n Nhap So Thu Hai: ");
			    scanf("%d",&b);
			    c = a + b;
			    printf("\n Ket Qua Cua %d Va %d La: %d",a,b,c);
				break;
			}
			case 2: {
				printf("\n Day La Phep Toan Cong Toan Ba So.");
			    int a,b,c;
			    int tong = 0;
			    printf("\n Nhap So Thu Nhat: ");
			    scanf("%d",&a);
			    printf("\n Nhap So Thu Hai: ");
			    scanf("%d",&b);
			    printf("\n Nhap So Thu Ba: ");
			    scanf("%d",&c);
			    tong = a + b +c;
			    printf("\n Ket Qua Cua Ba So %d Va %d Va %d La: %d",a,b,c,tong);
				break;
			}
			case 3 : {
				printf("\n Day La Phep Toan Cong Nhieu So.");
				int n;
				int i,a[n];
				int Tong = 0;
				for(i = 0;i < n;i++){
					printf("\n Nhap So a[%d] = ",i+1);
					scanf("%d",&a[i]);
				}
				for (i = 0 ;i < n;i++){
					Tong += a[i];
				}
				printf("\n Ket Qua Cua %d So La: %d",n,Tong);
				break;
			}
			case 0: {
				printf("\n Chuong Trinh Dang Thoat.");
				printf("\n Cam On Ban Da Tinh.");
				break;
			}
			default :
				printf("\n Nhap Sai So Rui! Vui Long Nhap Lai Nhe.");
		}
		if (LuaChon1 != 0){
			printf("\n Nhat Bat Cu Phim Nao Tren Ban Phim De Tiep Tuc.....");
			getchar();
			getchar();
		}
	} while (LuaChon1 != 0);
}

void HienThiCon2(){
	printf("\n ====Ban Muon Thuc Hien Phep Tinh Tru Nao===\n");
	printf("\n 1.Phep Toan Tru Hai So.");
	printf("\n 2.Phep Toan Tru Ba So.");
	printf("\n 3.Phep Toan Tru Nhieu So.");
	printf("\n 0.Thoat Chuong Trinh.");
	printf("\n =======================================\n");
}

void Suly2(){
	int LuaChon2;
	do {
		system("cls");
		HienThiCon2();
		scanf("%d",&LuaChon2);
		switch (LuaChon2){
			case 1 : {
				printf("\n Day La Phep Toan Tru Hai So.");
				int a,b,Hieu;
			    printf("\n Nhap So Thu Nhat:  ");
			    scanf("%d",&a);
			    printf("\n Nhap So Thu Hai:  ");
			    scanf("%d",&b);
			    Hieu = a - b;
			    printf("\n Ket Qua Cua Hai So %d Va %d La: %d",a,b,c);
				break;
			}
			case 2: {
				printf("\n Day La Phep Toan Tru Ba So.");
				int a,b,Hieu;
				printf("\n Nhap So Thu Nhat:  ");
			    scanf("%d",&a);
			    printf("\n Nhap So Thu Hai:  ");
			    scanf("%d",&b);
			    printf("\n Nhap So Thu Ba:  ");
			    scanf("%d",&c);
			    Hieu = a - b - c;
			    prinf("\n Ket Qua Cua Ba So %d Va %d Va %d La: %d",a,b,c,Hieu);
				break;
			}
			case 3: {
				printf("\n Day La Phep Toan Tru Nhieu So.");
				int n,i;
				int a[n];
				for (i = 0;i < n;i ++){
					printf("\n Nhap So a[%d] = ",i+1);
					scanf("%d",&a[i]);
				}
				int hieu = 0;
				for (i = 0 ; i < n ; i++){
					hieu -= a[i];
				}
				printf("Ket Qua Cua Phep Tinh Hieu %d So La: %d",n,hieu);
				break;
			}
			case 0:{
				printf("\n Dang Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Tinh.")
				break;
			}
			default :
				printf("\n Chon Sai So Rui! Vui Long Chon Lai So.");
		}
		if (LuaChon2 != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc......");
			getchar();
			getchar();
		}
	} while (LuaChon2 != 0);
}
void HienThiCon3(){
	printf("\n ====Ban Muon Thuc Hien Phep Nhan Nao====\n");
	printf("\n 1.Phep Toan Nhan Hai So.");
	printf("\n 2.Phep Toan Nhan Ba So.");
	printf("\n 3.Phep Toan Nhan Nhieu So.");
	printf("\n 0.Thoat Chuong Trinh.");
	printf("\n ========================================\n");
}

void HienThiCon4(){
	printf("\n ===Ban Muon Thuc Hien Phep Chia Nao====\n");
	printf("\n 1.Phep Toan Chia Hai So.");
	printf("\n 2.Phep Toan Chia Ba So Hai Lan.");
	printf("\n 3.Phep Toan Chia Nhieu So.");
	printf("\n 0.Thoat Chuong Trinh.");
	printf("\n =======================================\n");
}
void HienThiMenu2(){
	printf("\n ===== Banj Muon Thuc Hien Phep Toan Nang Cao Nao===== \n");
	printf("\n 1.Phep Toan Tinh Luy Thua.");
	printf("\n 2.Phep Toan Tinh So Mu.");
	printf("\n 3.Phep Tan Tinh Can Bac Hai.");
	printf("\n 4.Phep Toan Tinh Can Bac Ba.");
	printf("\n 5.Phep Toan Tinh Gia Tri Tuyet Doi.");
	printf("\n 6.Phep Toan Tinh Phuong Trinh Bac Nhat.");
	printf("\n 7.Phep Toan Tinh Phuong Trinh Bac Hai.");
	printf("\n 8.Phep Toan Tinh Phuong Trinh Bac Ba.");
	printf("\n 9.Phep Toan Tinh Phuong Trinh Bac Bon.");
	printf("\n 10.Phep Toan Tinh Phuong Trinh Bac Nam.");
	printf("\n 11.Phep Toan Tinh Trung Binh.");
	printf("\n 0.Thoat Chuong Trinh.");
	printf("\n ===================================================== \n");
}
