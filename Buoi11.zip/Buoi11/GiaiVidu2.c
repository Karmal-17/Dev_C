#include <stdio.h>
#include <string.h>

// H�m t�m t?t c? c�c v? tr� c?a k� t?
void TimKiemKyTu(char a[], char n) {
    int i;
    int TimKiem = 0; // C? hi?u ki?m tra c� t�m th?y k� t? hay kh�ng

    for (i = 0; a[i] != '\0'; i++) {
        if (a[i] == n) { // N?u k� t? tr�ng kh?p
            printf("\nK� t? '%c' du?c t�m th?y t?i v? tr� th? %d.", n, i + 1);
            TimKiem = 1;
        }
    }

    if (!TimKiem) { // N?u kh�ng t�m th?y k� t? n�o
        printf("\nTrong m?ng kh�ng c� k� t? '%c'.", n);
    }
}

int main() {
    char a[100]; // Chu?i k� t?
    char n;      // K� t? c?n t�m

    // Nh?p chu?i
    printf("\nNh?p chu?i k� t? b?n mu?n: ");
    fgets(a, sizeof(a), stdin);
    a[strcspn(a, "\n")] = '\0'; // Lo?i b? k� t? xu?ng d�ng '\n'

    // Nh?p k� t? c?n t�m
    printf("\nNh?p k� t? c?n t�m: ");
    scanf("%c", &n);

    // G?i h�m t�m ki?m
    TimKiemKyTu(a, n);

    return 0;
}

