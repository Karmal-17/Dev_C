#include <stdio.h>
#include <string.h>
int main(){
	char a[] = "Toi Hoc Lap Trinh C";
	char b[] = {'2','4','6','t','e','\0'};
	char c[100];
	char d [6] = {'2', '8', 't', 'e', 'c','\0'};
	printf("%s\n ",a);
	printf("%s\n",b);
	puts (d); // = printf("%d\n",d);
	// Duyet Qua Ky Tu Trong Chuoi
	printf("\n ----------- \n");
	printf("\n So Luong Ky Tu Cua Chuoi A La: %d\n ",strlen(a));
	int i;
	for (i = 0 ; i < strlen(a);i++){
		printf(" a[%d] = %c\n",i,a[i]);
	}
	// In Chuoi Lat Nguoc.
	printf("\n In Nguoc Lai: ");
	for(i = strlen(a) - 1;i >= 0;i--){
		printf("%c",a[i]);
	}
	return 0;
}
