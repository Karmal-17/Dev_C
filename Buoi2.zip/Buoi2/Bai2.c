#include <stdio.h>

int main(){
    //	 So nguyen
	int a = 8; //Gan Gia Tri Bien Tai Thoi Diem Khai Bao
	
	int b;
	b = 5; //Gan Gia Tri Sau Khi Khai Bao Bien
	
    //	 So thuc (So thap phan: su dung dau cham "."
	float c = 'cddc';
//	float d = 5,33; dung dau phay "," se bi bao loi	

    // Kieu ki tu: gia tri phai dat trong cap dau nhay don ' '
	char d = 'B'; // Ket qua: B
	char e = 'ADC'; // Ket qua: C
	printf("%c", d);
//	Tu hai ki tu tro len goi la chuoi ky tu trong C

// Hang so
    const double PI = 3.14;
//    PI = 4.5; // Dong nay se bi loi
    return 0;
}

