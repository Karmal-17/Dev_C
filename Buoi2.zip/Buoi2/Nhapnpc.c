#include <stdio.h>

int main(){
	int n; // Khai bao nhung khong co gia tri cho n
	printf("Nhap npc: ");// In ra thong bao nhap n
	scanf("%d", &n); // Cu phap cua ham scanf()
	
	printf("Gia Tri Ban Vua Nhap La %d", n); // In ra gia tri ban vua nhap
}
