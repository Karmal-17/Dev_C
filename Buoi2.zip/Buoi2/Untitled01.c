#include <stdio.h>

int main(){
    float a, b; // Add a comma between 'a' and 'b'
    printf("Nhap Di Bn: ");
    scanf("%f %f", &a, &b); // Fix spacing

    printf("Bn vua nhap: %f\n", a); // Correct function name to 'printf' and format
    printf("Bn vua nhap: %f\n", b); // Correct newline syntax to '\n'

    if (b != 0) {
        float thuong = a / b; // Casting is not needed as both are floats
        printf("Thuong Cua Bn La: %f\n", thuong); // Add newline at the end
    } else {
        printf("Phep chia bi loi: 0/%f\n", b); // Add variable and newline
    }

    return 0;
}

