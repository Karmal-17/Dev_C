#include <stdio.h>
int main(){
	float a,b;
	printf("Nhap a b");
	scanf("%f %f", &a, &a);
	if (b != 0); {
	    float thuong = (float) a / b;	
		printf("Phep chia: %f\n",);
	} else {
		printf("Loi: chia cho 0\n");
	} 
    return 0;
}
