#include <stdio.h>

int main(){
	int a,d,c;
	printf("Ban so A a d c: ");
//	scanf("%d %d %d", &a, &d, &c);
	scanf("%d, %d, %d", &a, &d, &c);
	printf("a = %d\nd = %d\nc = %d", a, d, c);
}
