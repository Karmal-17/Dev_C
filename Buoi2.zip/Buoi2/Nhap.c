#include <stdio.h>
int main(){
	int a, b;
	printf("Nhap a b: ");
	scanf("%d %d", &a, &b);
	int tong = a * b;
    printf("tong cua %d va %d la: %d\n", a, b, tong);
    return 0;

}

