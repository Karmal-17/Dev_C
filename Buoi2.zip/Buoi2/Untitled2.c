#include <stdio.h>

int main() {
    int a, b;
    printf("Nhap (a and b): ");
    scanf("%d %d", &a, &b);

    if (b != 0) {
        float thuong = (float)a / b;  // Typecast a to float to get a float result
        printf("Thuong: %f\n", thuong);
    } else {
        printf("Loi: Chia cho 0\n");
    }

    return 0;
}

