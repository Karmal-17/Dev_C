#include <stdio.h>

void Hienthimang(int a[],int n){
    int i;
    for (i = 0;i < n;i++){
    	printf("\n Nhap a[%d] = ",i);
    	scanf("%d",&a[i]);
    }
}
void HienThisobe(int a[],int n){
	int i,vitri;
	int sobe = a[0];
	for (i = 0;i < n;i++){
	    if (a[i] < sobe){
	    	vitri = i;
	    	sobe = a[i];
		}	
	}
	printf("\n So Be Nhat O Vi Tri a[%d] La: %d ",vitri,sobe);
}
void Hienthisolon(int a[],int n){
	int i,vitri;
	int solon = a[0];
	for (i = 0;i < n;i++){
		if (a[i] > solon){
			vitri = i;
			solon = a[i];
		}
	}
	printf("\n So Lon Nhat O Vi Tri a[%d] La: %d ",vitri,solon);
}
int main(){
	int n;
	printf("\n Nhap So n: ");
	scanf("%d",&n);
	int a[n];
	Hienthimang(a,n);
	HienThisobe(a,n);
	Hienthisolon(a,n);
	return 0;
}
	
