#include <stdio.h>

void Nhapmang(int a[],int n){
	int i;
	for (i = 0;i <= n - 1;i++){
		printf("\n Nhap Phan Tu Thu %d = ",i);
		scanf("%d",&a[i]);
	}
}

void inmang(int a[], int n){
	printf("\n Mang Ban Vua Nhap la: ");
	int i;
	for (i = 0;i < n ; i++){
		printf("%d ",a[i]);
	}
}

void Nhapmang1(int c[],int n){
	int i;
	for (i = 0;i <= n - 1;i++){
		printf("\n Nhap Phan Tu Thu %d = ",i);
		scanf("%d",&c[i]);
	}
}

void inmang1(int c[], int n){
	printf("\n Mang Ban Vua Nhap la: ");
	int i;
	for (i = 0;i < n ; i++){
		printf("%d ",c[i]);
	}
}
int main(){
	int n;
	printf("\n Nhap n: ");
	scanf("%d",&n);
	int a[n];
	Nhapmang(a,n);
	inmang(a,n);
	
	int m;
	printf("\n Nhap m: ");
	scanf("%d",&m);
	int c[m];
	Nhapmang1(c,n);
	inmang1(c,n);
	return 0;
	
}
