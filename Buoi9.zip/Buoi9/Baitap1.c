#include <stdio.h>

void Hienthimang(int a[], int n){
	int i ;
	for (i = 0 ; i < n;i++){
		printf("Nhap a[%d] la: ",i);
		scanf("%d",&a[i]);
	}
}
void HienThiTong(int a[],int n){
	int i,tong = 0 ;
	for (i = 0; i < n;i++){
		tong += a[i] ;
	}
	printf("Tong cac phan tu trong mang la: %d\n", tong);
}
int main(){
	int n;
	printf("Nhap So n: ");
	scanf("%d",&n);
	int a[n];
	Hienthimang(a,n);
	HienThiTong(a,n);
	return 0;
}
