#include <stdio.h>

// H�m nh?p c�c ph?n t? c?a m?ng
void Hienthimang(int a[], int n) {
    int i;
    for (i = 0; i < n; i++) {
        printf("Nhap a[%d]: ", i);
        scanf("%d", &a[i]);
    }
}

// H�m t�nh t?ng c�c ph?n t? trong m?ng v� in k?t qu?
void HienThiTong(int a[], int n) {
    int i, tong = 0;
    for (i = 0; i < n; i++) {
        tong += a[i]; // C?ng gi� tr? t?ng ph?n t? v�o t?ng
    }
    printf("Tong cac phan tu trong mang la: %d\n", tong);
}

int main() {
    int n;

    // Nh?p s? lu?ng ph?n t? c?a m?ng
    printf("Nhap so n: ");
    scanf("%d", &n);

    int a[n]; // Khai b�o m?ng c� k�ch thu?c n

    // Nh?p m?ng v� t�nh t?ng
    Hienthimang(a, n);
    HienThiTong(a, n);

    return 0;
}

