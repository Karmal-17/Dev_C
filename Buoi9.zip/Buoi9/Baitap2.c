#include <stdio.h>

void Hienthi(int a[],int n){
	int i;
	for (i =0;i < n; i ++){
		printf("\n Nhap a[%d] = ",i);
		scanf("%d",&a[i]);
	}
}
void HienThitb(int a[], int n){
	int i,tong = 0;
	for(i = 0;i < n;i ++){
		tong += a[i];
	}
	float tb = (float)tong / n;
	printf("\n Trung Binh Cua %d so la: %.2f",n,tb);
}

int main(){
	int n;
	printf("\n Nhap So n: ");
	scanf("%d",&n);
	int a[n];
	Hienthi(a,n);
	HienThitb(a,n);
	return 0;
}
