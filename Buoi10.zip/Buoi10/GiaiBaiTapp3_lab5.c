#include <stdio.h>

void HoanViDaoNguoc(int a[], int n) {
    int i;
    // Ho�n v? c�c ph?n t?
    for (i = 0; i < n / 2; i++) {
        int temp = a[i];
        a[i] = a[n - i - 1];
        a[n - i - 1] = temp;
    }
    
    // In m?ng sau khi ho�n v?
    printf("\nM?ng sau khi ho�n v? l�:\n");
    for (i = 0; i < n; i++) {
        printf("a[%d] = %d\n", i, a[i]);
    }
}

int main() {
    int n;

    do {
        printf("\nNh?p s? nguy�n n (n >= 2): ");
        scanf("%d", &n);

        if (n >= 2) {
            int a[n];
            printf("Nh?p c�c ph?n t? c?a m?ng:\n");
            int i;
            for ( i = 0; i < n; i++) {
                printf("a[%d] = ", i);
                scanf("%d", &a[i]);
            }

            // G?i h�m ho�n v?
            HoanViDaoNguoc(a, n);
        } else {
            printf("\nB?n d� nh?p s? nh? hon 2! Vui l�ng nh?p l?i.\n");
        }
    } while (n < 2);

    return 0;
}

