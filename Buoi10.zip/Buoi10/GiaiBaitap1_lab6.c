#include <stdio.h>

int main() {
    int n,i;
    do{
    printf("Nhap so luong phan tu cua mang: ");
    scanf("%d", &n);
    if (n > 0){
    int a[n];
    printf("\n Nhap cac phan tu cua mang:\n");
    for ( i = 0; i < n; i++) {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    int sum = 0, count = 0; // Bi?n luu t?ng v� s? lu?ng s? chia h?t cho 2
    printf("\nCac so chia het cho 2 la: ");
    for (i = 0; i < n; i++) {
        if (a[i] % 2 == 0) { // Ki?m tra n?u ph?n t? chia h?t cho 2
            printf("%d ", a[i]);
            sum += a[i];     // C?ng d?n v�o t?ng
            count++;         // Tang s? lu?ng s? chia h?t cho 2
        }
    }

    // Ki?m tra c� s? n�o chia h?t cho 2 kh�ng
            if (count > 0) {
                float average = (float)sum / count; // T�nh trung b�nh
                printf("\nTrung binh cong cua cac so chia het cho 2: %.2f\n", average);
            } else {
            printf("\nKhong co so nao chia het cho 2 trong mang.\n");
            }
    } else {
    	printf("\n Nhap Sai Rui!Vui Long Nhap Lai.");
	}
    } while (n <= 0);
    return 0;
}

