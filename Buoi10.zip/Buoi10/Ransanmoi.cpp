#include <iostream>
#include <conio.h>
#include <windows.h>
using namespace std;

// K�ch thu?c m�n choi
const int width = 20;
const int height = 20;

// Bi?n to�n c?c
int x, y, fruitX, fruitY, score;
int tailX[100], tailY[100]; // V? tr� du�i r?n
int nTail; // �? d�i du�i r?n
bool gameOver;
enum Direction { STOP = 0, LEFT, RIGHT, UP, DOWN };
Direction dir;

// H�m d?t con tr? t?i v? tr� c? th? (x�a m�n h�nh console)
void gotoxy(int x, int y) {
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

// H�m thi?t l?p tr� choi
void Setup() {
    gameOver = false;
    dir = STOP;
    x = width / 2; // V? tr� ban d?u c?a r?n
    y = height / 2;
    fruitX = rand() % width; // V? tr� ng?u nhi�n c?a m?i
    fruitY = rand() % height;
    score = 0;
}

// H�m hi?n th? m�n choi
void Draw() {
    system("cls"); // X�a m�n h�nh
    for (int i = 0; i < width + 2; i++)
        cout << "#"; // V? vi?n tr�n
    cout << endl;

    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            if (j == 0)
                cout << "#"; // V? vi?n tr�i
            if (i == y && j == x)
                cout << "O"; // �?u r?n
            else if (i == fruitY && j == fruitX)
                cout << "F"; // M?i
            else {
                bool print = false;
                for (int k = 0; k < nTail; k++) {
                    if (tailX[k] == j && tailY[k] == i) {
                        cout << "o"; // �u�i r?n
                        print = true;
                    }
                }
                if (!print)
                    cout << " ";
            }

            if (j == width - 1)
                cout << "#"; // V? vi?n ph?i
        }
        cout << endl;
    }

    for (int i = 0; i < width + 2; i++)
        cout << "#"; // V? vi?n du?i
    cout << endl;

    cout << "Score: " << score << endl;
}

// H�m x? l� nh?p li?u
void Input() {
    if (_kbhit()) {
        switch (_getch()) {
            case 'a':
                dir = LEFT;
                break;
            case 'd':
                dir = RIGHT;
                break;
            case 'w':
                dir = UP;
                break;
            case 's':
                dir = DOWN;
                break;
            case 'x':
                gameOver = true;
                break;
        }
    }
}

// H�m x? l� logic tr� choi
void Logic() {
    int prevX = tailX[0];
    int prevY = tailY[0];
    int prev2X, prev2Y;
    tailX[0] = x;
    tailY[0] = y;

    for (int i = 1; i < nTail; i++) {
        prev2X = tailX[i];
        prev2Y = tailY[i];
        tailX[i] = prevX;
        tailY[i] = prevY;
        prevX = prev2X;
        prevY = prev2Y;
    }

    switch (dir) {
        case LEFT:
            x--;
            break;
        case RIGHT:
            x++;
            break;
        case UP:
            y--;
            break;
        case DOWN:
            y++;
            break;
        default:
            break;
    }

    // Ki?m tra va ch?m v?i tu?ng
    if (x >= width || x < 0 || y >= height || y < 0)
        gameOver = true;

    // Ki?m tra va ch?m v?i du�i
    for (int i = 0; i < nTail; i++)
        if (tailX[i] == x && tailY[i] == y)
            gameOver = true;

    // Ki?m tra an m?i
    if (x == fruitX && y == fruitY) {
        score += 10;
        fruitX = rand() % width;
        fruitY = rand() % height;
        nTail++;
    }
}

// H�m ch�nh
int main() {
    Setup();
    while (!gameOver) {
        Draw();
        Input();
        Logic();
        Sleep(100); // �i?u ch?nh t?c d? di chuy?n c?a r?n
    }

    cout << "Game Over! Your score is: " << score << endl;
    return 0;
}

