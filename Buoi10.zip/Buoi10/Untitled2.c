#include <stdio.h>

// Function to input array elements
void NhapMang(int a[], int n) {
	int i;
    for ( i = 0; i < n; i++) {
        printf("Nhap so a[%d] = ", i);
        scanf("%d", &a[i]);
    }
}

// Function to calculate and display the sum of array elements
void HienThiTong(int a[], int n) {
	int i;
    int tong = 0;
    for (i = 0; i < n; i++) {
        tong += a[i];
    }
    printf("\nTong cac so cua mang la: %d\n", tong);
}

int main() {
    int n;
    printf("Nhap so n: ");
    scanf("%d", &n);
    int a[n];

    // Input the array elements
    NhapMang(a, n);

    // Calculate and display the sum
    HienThiTong(a, n);

    return 0;
}

