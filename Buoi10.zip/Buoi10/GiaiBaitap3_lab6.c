#include <stdio.h>

// H�m nh?p m?ng
void NhapMang(int a[], int n) {
	int i;
    printf("\nNhap cac phan tu cua mang:\n");
    for ( i = 0; i < n; i++) {
        printf("a[%d] = ", i + 1);
        scanf("%d", &a[i]);
    }
}

// H�m hi?n th? m?ng
void XuatMang(int a[], int n) {
    printf("\nCac phan tu cua mang la:\n");
    int i;
    for ( i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
}

// H�m s?p x?p m?ng theo th? t? t? b� d?n l?n
void SapXepTangDan(int a[], int n) {
	int i,j;
    for ( i = 0; i < n - 1; i++) { // V�ng l?p qua c�c ph?n t?
        for ( j = 0; j < n - i - 1; j++) { // V�ng l?p so s�nh t?ng c?p ph?n t?
            if (a[j] > a[j + 1]) { // N?u ph?n t? tru?c l?n hon ph?n t? sau
                // Ho�n d?i gi� tr?
                int temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }
}

int main() {
    int n;
    printf("Nhap so luong phan tu cua mang: ");
    scanf("%d", &n);

    if (n > 0) {
        int a[n];
        NhapMang(a, n);

        printf("\nMang truoc khi sap xep:");
        XuatMang(a, n);

        SapXepTangDan(a, n);

        printf("\nMang sau khi sap xep theo thu tu tang dan:");
        XuatMang(a, n);
    } else {
        printf("\nSo luong phan tu cua mang phai lon hon 0.\n");
    }

    return 0;
}

