#include <stdio.h>

void Nhapmang(int array[],int n){
	int i;
	printf("\n Nhap Cac Phan Tu Cua Mang: \n");
	for(i = 0; i <= n-1;i++){
		printf("Nhap Phan Tu So %d: ",i+1);
		scanf("%d",&array[i]);
	}
}
void Sum(int arr[],int n){
	int i,tong = 0;
	for (i = 0;i < n;i++){
		tong += arr[i];
	}
	printf("\nTong Cac Phan Tu La: %d",tong);
}

void GTLN(int a[],int n){
	int i;
	int solon = a[0];
	int vitri;
	for(i = 0; i < n;i++){
		if(a[i] >= solon){
			solon = a[i];
			vitri = i+1;
		}
	}
	printf("\n Gia Tri Lon Nhat La: %d Dung Thu a[%d] ",solon,vitri);
}
int main(){
	int i,n;
	printf("\n Nhap Cac Phan Tu Cua Mang: ");
	scanf(" %d",&n);
	int a[n];
	Nhapmang(a,n);
	GTLN(a,n);
	if (n > 0){
		printf("\n Cac Phan Tu Cua Mang: ");
		for (i = 0;i <= n-1;i++){
			printf("%d  ",i+1);
		}
		Sum(a,n);
	}
	else {
		printf("\n So Luong Phan Tu Cua Mang Phai Lon Hon Khong!");
	}
}
