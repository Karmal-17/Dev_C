#include <stdio.h>
void NhapMang(int a[],int n){
	int i;
	printf("\n Cac So Nam Trong Mang La. \n");
	for (i = 0 ; i < n; i++){
		printf("\n Nhap a[%d] = ",i+1);
		scanf("%d",&a[i]);
	}
}
void LocSo(int a[],int n){
	int i;
	int Tong = a[0];
	int Dem = 0;
	for (i = 0;i < n; i++){
		if(a[i] % 3 ==0){
			Tong += a[i];
			Dem ++;
		}
	}
	if (Dem > 0){
		float TrungBinh = (float) Tong / Dem;
		printf("\n Trung Binh Cua %d So La: %.2f",Dem,TrungBinh);
	}
	else {
		printf("\n Khong Co Gia Tri Nao Trong Mang Chia Het Cho 3! Vui Long Chay Lai Chuong Trinh.");
	}
}
int main(){
	int n;
	do {
		printf("\n Vui Long Nhap So Nguyen n: ");
		scanf("%d",&n);
		if (n > 0){
			int a[n];
			printf("\n Chay Rui Ne.");
			NhapMang(a,n);
			LocSo(a,n);
		} else {
			printf("\n Nhap Sai Rui! Vui Long Nhap Lai.");
		}
	} while (n <= 0);
	return 0;
}
