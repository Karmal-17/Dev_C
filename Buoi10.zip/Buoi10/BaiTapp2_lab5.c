#include <stdio.h> 

void HienThi(int n){
	if ((n % 4 == 0 && n % 100 != 0) || (n % 400 == 0)) {
        printf("\n Nam %d La Nam Nhuan.\n", n);
    } else {
        printf("\n Nam %d La Nam Khong Nhuan.\n", n);
    }
}
int main(){
	int n;
	do {
	    printf("\n Vui Long Nhap Nam Bn Muon: ");
	    scanf("%d",&n);
	    if (n  < 0){
		    printf("\n Nhap Sai Rui!Vui Long Nhap Lai Nhe.");
	    } else {
	    	HienThi(n);
	    }
	}
	while (n < 0);
	return 0;
}
