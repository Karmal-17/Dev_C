#include <stdio.h>

void HienThiTruocHV(int a[],int n){
	int i;
	printf("\n Truoc Khi Hoan Vi: \n");
	for(i = 0; i < n ; i ++){
		printf("\n Nhap a[%d] = ",i+1);
		scanf("%d",&a[i]);
	}
}
void HienThiSauHV(int a[],int n){
	int i;
	for(i = 0; i < n / 2;i++){
		int Redblue = a[i];
		a[i] = a[n - i - 1];
		a[n - i - 1] = Redblue;
	}
	printf("\nSau Khi Hoan Vi La: \n");
	for (i = 0; i < n; i++){
		printf("\n Nhap a[%d] = %d ",i+1,a[i]);
	}
}
int main(){
	int n;
	do {
	printf("\n Nhap So Nguyen n: ");
	scanf("%d",&n);
	int a[n];
	if (n >= 2){
		printf("\n Day Ne.");
		HienThiTruocHV( a,n);
		HienThiSauHV( a,n);
		} 
		else {
			printf("\n Ban Da Nhap So It Hon 2!Vui Long Nhap Lai Nhe.");
		}
	}
	while (n < 2);
	return 0;
}
