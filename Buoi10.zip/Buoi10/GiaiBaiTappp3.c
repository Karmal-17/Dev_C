#include <stdio.h>

// H�m d? hi?n th? m?ng
void Hienthi(int a[], int n) {
	int i;
    printf("Cac phan tu trong mang: ");
    for ( i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
}

// H�m ho�n v? 2 gi� tr? trong m?ng
void HoanVi(int *x, int *y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}

int main() {
    int n;
    printf("Nhap so luong phan tu cua mang: ");
    scanf("%d", &n);
    
    int a[n];
    printf("Nhap cac phan tu cua mang:\n");
    int i;
    for ( i = 0; i < n; i++) {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }
    
    printf("Mang truoc khi hoan vi:\n");
    Hienthi(a, n);
    
    // Th?c hi?n ho�n v? 2 ph?n t? d?u ti�n n?u c� d? 2 ph?n t?
    if (n >= 2) {
        HoanVi(&a[0], &a[1]);
    }

    printf("Mang sau khi hoan vi phan tu dau tien va thu hai:\n");
    Hienthi(a, n);
    
    return 0;
}

