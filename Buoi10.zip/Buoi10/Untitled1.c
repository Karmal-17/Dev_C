#include <stdio.h>

int main(){
	// cac phan tu cua a co gia tri ngau nhien
	int a[100];
	// Cac phan tu trong b lan luot la: 2, 4, 6, 8, 0
	int b[5] = {2,4,6,8,0};
	int i;
	
	for (i = 0;i < 5 ; i++){
		printf("%d ",b[i]);		
	}
	printf("\n");
	for (i = 5 - 1;i >= 0;i -- ){
		printf("%d ",b[i]);
	}
	printf("\n");
	
	// Thay Doi Phan Tu Cua Mang
	b[0] = 10;
	b[1] = 20;
	b[2] += 4; // b[2] = 6 + 4
	b[3] /= 2;
	b[4] *= 2;
	
	for (i = 0; i < 5 ; i++){
	    printf("%d ",b[i]);
	}
	// Nhap Mang Tu Ban Phim
	int n;
	printf("\n Nhap: ");
	scanf("%d",&n);
	for (i = 0 ; i < n ; i ++){
		printf("\n Nhap a[%d]: ",i);
		scanf("%d",&a[i]);
	}
	printf("Mang Vua Nhap La: ");
	
	for (i = 0;i < n ; i++){
		printf("%d ",a[i]);
	}
	
	// M La So Luong Phan Tu Cua Mang C
	int m;
	printf("\n Nhap m: ");
	scanf("%d",&m);
	int c[m];
	
	for (i = 0;i < m; i ++){
		printf("\n Nhap c[%d] = ",i);
		scanf("%d",&i);
	}
	for (i = 0 ; i < m;i++){
		printf("%d ",i);
	}
	return 0;
}
