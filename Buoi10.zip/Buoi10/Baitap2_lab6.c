#include <stdio.h>

void NhapMang(int a[],int n){
	int i;
	printf("\\n Cac So Trong Mang Ban Vua Nhap La: ");
	for(i = 0;i < n ; i++){
		printf("\n Nhap So a[%d] = ",i+1);
		scanf("%d",&a[i]);
	}
}
void Solon (int a[],int n){
	int i;
	int Solon = a[0];
	int Vitri = 0;
	for (i = 0; i < n; i++){ // Chu Y Vi Tri Cua For Va If
		if (a[i] > Solon){
			Solon = a[i];
			Vitri = i+1;
		}
	}
	printf("\n So Lon Nhat Trong Mang La: %d Dung O Vi Tri a[%d].",Solon,Vitri);
}
void SoBe (int a[],int n){
	int i;
	int Sobe = a[0];
	int Vitri = 0;
	for (i = 0; i < n; i++){
		if (a[i] < Sobe){
			Sobe = a[i];
			Vitri = i+1;
		}
	}
	printf("\n So Be Nhat Trong Mang La: %d Dung O Vi Tri a[%d].",Sobe,Vitri);
}

int main(){
	int n;
	do {
		printf("\n Vui Long Nhap So Nguyen n: ");
		scanf("%d",&n);
		if (n > 0){
			printf("\n Chay Rui Ne.");
			int a[n];
			NhapMang(a,n);
			Solon(a,n);
			SoBe(a,n);
		} else {
			printf("\n So Nguyen Ban Nhap Be Hon 0.");
		}
	} while (n <= 0);
	return 0;
}
