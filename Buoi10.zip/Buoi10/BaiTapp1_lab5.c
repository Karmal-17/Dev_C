#include <stdio.h>

void HienThi(int a[], int n){
	int i;
	for (i = 0;i <= n -1 ; i++){
	printf("\n Nhap a[%d] = ",i+1);
	scanf("%d",&a[i]);
    }
}
void HienThi1(int a[],int n){
	int i;
	int solon = a[0];
	int vitri = 0;
	for (i = 0;i <= n-1; i++){
		if (a[i] > solon){
			solon =a[i];
			vitri = i+1;
		}
	}
	printf("\n So Lon Nhat La: %d Dung O Vi Tri Thu a[%d] \n",solon,vitri);
}
void HienThi2 (int a[],int n){
	int i;
	int sobe = a[0];
	int vitri = 0;
	for (i = 0;i < n;i++){
		if (a[i] < sobe){
			sobe = a[i];
			vitri = i + 1;
		}
	}
	printf("\n So Be Nhat La: %d Dung O Vi Tri Thu a[%d]",sobe,vitri);
}
int main(){
	int n;
	do{
	printf("\n Nhap So n (Chi Duoc Nhap 3 So): ");
	scanf("%d",&n);
	    if(n == 3){
	    	int a[n];
	        HienThi(a,n);
	        HienThi1(a,n);
	        HienThi2(a,n);
		}
		else {
			printf("\n Nhap Sai Rui! Nhap Lai Di. \n");
		}
	} 
	while (n != 3);
	return 0;
}
