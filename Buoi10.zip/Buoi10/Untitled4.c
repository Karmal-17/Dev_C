#include <stdio.h>

// H�m nh?p m?ng
void Nhapmang(int array[], int n) {
    int i;
    printf("Nhap cac phan tu cua mang:\n");
    for (i = 0; i < n; i++) {
        printf("Nhap phan tu so %d: ", i + 1);
        scanf("%d", &array[i]);
    }
}

// H�m t�nh t?ng
void Sum(int arr[], int n) {
    int i, tong = 0;
    for (i = 0; i < n; i++) {
        tong += arr[i];
    }
    printf("Tong cac phan tu la: %d\n", tong);
}

int main() {
    int i, n;

    // Nh?p s? ph?n t? c?a m?ng
    printf("Nhap so luong phan tu cua mang: ");
    scanf("%d", &n);

    // Ki?m tra n h?p l?
    if (n <= 0) {
        printf("So luong phan tu cua mang phai lon hon 0!\n");
        return 1; // K?t th�c chuong tr�nh n?u n kh�ng h?p l?
    }

    int a[n]; // Khai b�o m?ng v?i k�ch thu?c n

    // Nh?p v� hi?n th? c�c ph?n t? c?a m?ng
    Nhapmang(a, n);

    printf("Cac phan tu cua mang la: ");
    for (i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");

    // T�nh t?ng c�c ph?n t?
   

