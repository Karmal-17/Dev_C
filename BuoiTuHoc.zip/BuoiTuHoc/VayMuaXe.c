#include <stdio.h>
#include <math.h>

void HienThi7() {
    printf("\n ==== Mua Xe Tra Gop ====");
    printf("\n + 1.Vay Tien Mua Xe.   +");
    printf("\n + 0.Thoat Chuong Trinh.+");
    printf("\n ========================");
}

void SuLyHienThi7() {
    int LuaChon7;
    do {
        system("cls");
        HienThi7();
        printf("\n Nhap Lua Chon Cua Ban: ");
        scanf("%d", &LuaChon7);
        switch (LuaChon7) {
            case 1: {
                printf("\n Tinh Lai Mua Xe.\n");
                float GiaTriCuaXe, LaiXuatNamCoDinh, PhanTramVayCoDinh;
                int ThoiHanVay;
                printf("\n Nhap Gia Tri Cua Xe Ma Ban Muon (VND): ");
                scanf("%f", &GiaTriCuaXe);
                if (GiaTriCuaXe <= 0) {
                    printf("\n Gia tri cua xe khong hop le. Vui long nhap lai.\n");
                    break;
                }
                printf("\n Nhap Lai Xuat Co Dinh Theo Nam (%%): ");
                scanf("%f", &LaiXuatNamCoDinh);
                if (LaiXuatNamCoDinh <= 0 || LaiXuatNamCoDinh > 100) {
                    printf("\n Lai xuat khong hop le. Vui long nhap lai.\n");
                    break;
                }
                printf("\n Nhap Thoi Han Vay Cua Ban (So Nam): ");
                scanf("%d", &ThoiHanVay);
                if (ThoiHanVay <= 0) {
                    printf("\n Thoi han vay khong hop le. Vui long nhap lai.\n");
                    break;
                }
                printf("\n Nhap Phan Tram Vay Toi Da (0 - 100): ");
                scanf("%f", &PhanTramVayCoDinh);
                if (PhanTramVayCoDinh < 0 || PhanTramVayCoDinh > 100) {
                    printf("\n Phan tram vay khong hop le. Vui long nhap lai.\n");
                    break;
                }
                float SoTienTraTruoc = (1 - PhanTramVayCoDinh / 100) * GiaTriCuaXe;
                float SoTienDuocVayDeMuaXe = GiaTriCuaXe - SoTienTraTruoc;
                float LaiXuatThang = LaiXuatNamCoDinh / 12 / 100;
                int SoThangPhaiTra = ThoiHanVay * 12;
                float SoTienPhaiTraHangThang = SoTienDuocVayDeMuaXe * (LaiXuatThang * pow(1 + LaiXuatThang, SoThangPhaiTra)) / (pow(1 + LaiXuatThang, SoThangPhaiTra) - 1);
                printf("\n So Tien Ban Phai Tra Truoc La: %.2f VND \n", SoTienTraTruoc);
                printf("\n So Tien Ban Phai Tra Hang Thang La: %.2f VND \n", SoTienPhaiTraHangThang);
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Tinh Lai Xuat Vay Mua Xe.\n");
                break;
            }
            default:
                printf("\n Lua Chon Khong Hop Le. Vui Long Thu Lai.\n");
        }
        if (LuaChon7 != 0) {
            printf("\n Nhan Phim Bat Ky De Tiep Tuc Tinh...\n");
            getchar();
            getchar();
        }
    } while (LuaChon7 != 0);
}

int main() {
    SuLyHienThi7();
    return 0;
}

