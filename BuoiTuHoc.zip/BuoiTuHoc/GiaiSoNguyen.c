#include <stdio.h>

int main() {
    int n,i, isPrime = 1; // Bi?n isPrime d? d�nh d?u s? nguy�n t?

    // Nh?p s? t? ngu?i d�ng
    printf("Nh?p m?t s? nguy�n duong: ");
    scanf("%d", &n);

    // Ki?m tra n?u n <= 1, kh�ng ph?i s? nguy�n t?
    if (n <= 1) {
        isPrime = 0;
    } else {
        // Ki?m tra n c� chia h?t cho b?t k? s? n�o t? 2 d?n n-1
        for (i = 2; i < n; i++) {
            if (n % i == 0) {
                isPrime = 0;
                break; // Tho�t v�ng l?p s?m n?u t�m th?y u?c s?
            }
        }
    }

    // In k?t qu?
    if (isPrime == 1) {
        printf("%d l� s? nguy�n t?.\n", n);
    } else {
        printf("%d kh�ng ph?i l� s? nguy�n t?.\n", n);
    }

    return 0;
}

