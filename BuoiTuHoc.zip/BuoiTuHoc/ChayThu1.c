#include <stdio.h>
#include <math.h> // Thu vi?n d�ng cho h�m sqrt

void HienThi1(){
	printf("\n ===== Kiem Tra So Nguyen ======");
	printf("\n + 1.Xac Dinh So Nguyen.       +");
	printf("\n + 2.Xac Dinh So Nguyen To.    +");
	printf("\n + 3.Xac Dinh So Chinh Phuong. +");
	printf("\n + 4.Xac Dinh Ca.              +");
	printf("\n + 0.Thoat Chuong Trinh.       +");
	printf("\n ===============================");
}

void SyLyHienThi1(){
	int LuaChon1;
	do {
		system("cls");
		HienThi1();
		printf("\n Nhap Lua Chon Cua Ban: ");
		scanf("%d",&LuaChon1);
		switch(LuaChon1){
			case 1: {
				printf("\n 1.Xac Dinh So Nguyen.");
				float a;
				printf("\n Vui Long Nhap So (Am Hoac Duong): ");
				scanf("%f",&a);
				printf("\n So Ban Vua Nhap La: %.2f",a);
			    if (a == (int)a){
				    if (a > 0){
					    printf("\n So %d Ban Vua Nhap La So Nguyen Duong.",(int)a);
				    } else {
					    if ( a == 0){
						printf("\n So %d Ban Vua Nhap La So Nguyen.",(int)a);
					    } else {
						    printf("\n  So %d Ban Vua Nhap La So Nguyen Am.",(int)a);
					    }
				    }
			    } else {
			    	printf("\n So Ban Vua Nhap khong Phai La So Nguyen.");
				}
				break;
			}
			case 2: {
				printf("\n 2.Xac Dinh So Nguyen To.");
				float a;
				int xacdinh = 1;
				printf("\n Nhap So Nguyen To Ban Muon: ");
				scanf("%f",&a);
				printf("\n So Ban Vua Nhap La: %.2f",a);
				if (a == (int)a){
						if (a <= 1){
					        xacdinh = 0;
				 	        printf("\n So Ban Vua Nhap Chua Phai La So Nguyen To.");
				            } else {
					            int i;
					            for ( i = 2 ; i < a; i++){
						            if((int)a % i == 0){
							        xacdinh = 0;
						        }
					        }
				        printf("\n So %d Cua Ban Vua Nhap La So Nguyen To.",(int)a);	
				   }
				} else {
					printf("\n So Ban Vua Nhap Chua Phai La So Nguyen.");
					printf("\n Vui Long Chon Va Nhap Lai.");
				}
				break;
			}
			case 3: {
				printf("\n 3. Xac Dinh So Chinh Phuong.");
				float a;
				int i;
				printf("\n Nhap Ban Muon: ");
				scanf("%f",&a);
				printf("\n So Ban Vua Nhap La: %.2f",a);
				if (a == (int)a){
					if (a < 0){
					    printf("\n So %d Ban Vua Nhap Chua Phai La So Chinh Phuong.",(int)a);
				    } else {
					    int XacDinh;
					    XacDinh = (int)sqrt(a) * (int)sqrt(a);
					    if (XacDinh == a){
						    printf("\n So %d Ban Vua Nhap La So Chinh Phuong.",(int)a);
					    }
				   }
				} else {
					printf("\n So Ban Vua Nhap Chua Phai La So Nguyen.");
					printf("\n Nen Phep Tinh Khong Duoc Thuc Hien.");
				}
				break;
			}
			case 4: {
				printf("\n 4.Xac Dinh Ca.");
				int a,i;
				int XacDinh = 1;
				int XacDinh1 = 0;
				printf("\n Nhap Mot So Nguyen Ban Muon: ");
				scanf("%d",a);
				if (a == (int)a){
					if (a <= 1){
					    XacDinh = 0;
					    printf("\n So Ban Vua Nhap Chua Phai La So Nguyen To.");
				    } else {
					    for (i = 2; i <= sqrt(a); i++){
						    if (a % i == 0){
							    XacDinh = 0;
						    }
					    }
					printf("\n So %d La Mot So Nguyen To.");		
				}
				if (a >= 0){
					int XacDinh1 = (int)sqrt(a) * (int)sqrt(a);
					if (XacDinh1 == a){
						printf("\n So %d Ban Vua Nhap La So Chinh Phuong",a);
					} else {
						printf("\n So %d Ban Vua Nhap Khong Phai La So Chinh Phuong.",a);
					}
				}
			} else {
				printf("\n So Ban Vua Nhap Khong Phai La So nguyen.");
				printf("\n Nen Phep Tinh Chua Duoc Thuc Hien.");
			}	
				break;
			}
			case 0:{
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung.");
				break;
			}
			default :
				printf("\n Chon Sai Rui! Vui Long Chon Lai Nhe.");
		}
		if (LuaChon1 != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Chuong Trinh.......");
			getchar();
			getchar();
		}
	} while (LuaChon1 != 0);
}
int main(){
	SyLyHienThi1();
}
