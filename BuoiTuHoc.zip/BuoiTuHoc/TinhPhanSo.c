#include <stdio.h>

// H�m t�nh UCLN
int timUCLN(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// H�m r�t g?n ph�n s?
void rutGonPhanSo(int *tu, int *mau) {
    int ucln = timUCLN(*tu, *mau);
    *tu /= ucln;
    *mau /= ucln;
}

// H�m t�nh t?ng hai ph�n s?
void tongPhanSo(int tu1, int mau1, int tu2, int mau2, int *tuKq, int *mauKq) {
    *tuKq = tu1 * mau2 + tu2 * mau1;
    *mauKq = mau1 * mau2;
    rutGonPhanSo(tuKq, mauKq);
}

// H�m t�nh hi?u hai ph�n s?
void hieuPhanSo(int tu1, int mau1, int tu2, int mau2, int *tuKq, int *mauKq) {
    *tuKq = tu1 * mau2 - tu2 * mau1;
    *mauKq = mau1 * mau2;
    rutGonPhanSo(tuKq, mauKq);
}

// H�m t�nh t�ch hai ph�n s?
void tichPhanSo(int tu1, int mau1, int tu2, int mau2, int *tuKq, int *mauKq) {
    *tuKq = tu1 * tu2;
    *mauKq = mau1 * mau2;
    rutGonPhanSo(tuKq, mauKq);
}

// H�m t�nh thuong hai ph�n s?
void thuongPhanSo(int tu1, int mau1, int tu2, int mau2, int *tuKq, int *mauKq) {
    *tuKq = tu1 * mau2;
    *mauKq = mau1 * tu2;
    rutGonPhanSo(tuKq, mauKq);
}

int main() {
    int tu1, mau1, tu2, mau2;
    int tuKq, mauKq;

    // Nh?p ph�n s? th? nh?t
    printf("Nhap tu so va mau so cua phan so thu nhat (dinh dang: tu mau): ");
    scanf("%d %d", &tu1, &mau1);

    // Nh?p ph�n s? th? hai
    printf("Nhap tu so va mau so cua phan so thu hai (dinh dang: tu mau): ");
    scanf("%d %d", &tu2, &mau2);

    // T�nh t?ng
    tongPhanSo(tu1, mau1, tu2, mau2, &tuKq, &mauKq);
    printf("Tong hai phan so: %d/%d\n", tuKq, mauKq);

    // T�nh hi?u
    hieuPhanSo(tu1, mau1, tu2, mau2, &tuKq, &mauKq);
    printf("Hieu hai phan so: %d/%d\n", tuKq, mauKq);

    // T�nh t�ch
    tichPhanSo(tu1, mau1, tu2, mau2, &tuKq, &mauKq);
    printf("Tich hai phan so: %d/%d\n", tuKq, mauKq);

    // T�nh thuong
    if (tu2 != 0) {
        thuongPhanSo(tu1, mau1, tu2, mau2, &tuKq, &mauKq);
        printf("Thuong hai phan so: %d/%d\n", tuKq, mauKq);
    } else {
        printf("Khong the chia cho 0!\n");
    }

    return 0;
}

