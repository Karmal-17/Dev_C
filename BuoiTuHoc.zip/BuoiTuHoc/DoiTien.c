#include <stdio.h>
#include <stdlib.h>

// Hi?n th? menu ch?c nang
void HienThi5() {
    printf("\n ====== Hien Thi Doi Tien Theo Menh Gia ======");
    printf("\n + 1. Doi Tien Voi Menh Gia Hop Ly.          +");
    printf("\n + 0. Thoat Chuong Trinh.                    +");
    printf("\n =============================================");
}

// X? l� ch?c nang d?i ti?n
void SuLyHienThi5() {
    int LuaChon5;
    do {
        system("cls");
        HienThi5();
        printf("\n Moi Ban Chon So: ");
        scanf("%d", &LuaChon5);
        switch (LuaChon5) {
            case 1: {
                printf("\n Doi Tien Voi Menh Gia Hop Ly.");
                int SoTienCanDoi;
                int MenhGia[] = {500, 200, 100, 50, 20, 10, 5, 2, 1};
                int SoLuongTien[9] = {0};
                int i;

                printf("\n Nhap So Tien Ban Muon Doi: ");
                scanf("%d", &SoTienCanDoi);

                if (SoTienCanDoi <= 0) {
                    printf("\n So tien phai la so duong. Vui long nhap lai!");
                    break;
                }

                printf("\n So Tien Ban Da Nhap La: %d", SoTienCanDoi);
                for (i = 0; i < 9; i++) {
                    if (SoTienCanDoi >= MenhGia[i]) {
                        SoLuongTien[i] = SoTienCanDoi / MenhGia[i];
                        SoTienCanDoi %= MenhGia[i];
                    }
                }
                printf("\n Ket Qua Doi Tien La: \n");
                for (i = 0; i < 9; i++) {
                    if (SoLuongTien[i] > 0) {
                        printf(" - %d To Tien Gia %d.000 VND\n", SoLuongTien[i], MenhGia[i]);
                    }
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh Tinh Tien.");
                printf("\n Cam On Ban Da Su Dung.");
                break;
            }
            default:
                printf("\n Ban Da Chon Sai So Rui!");
                printf("\n Vui Long Chon Lai So.");
        }

        if (LuaChon5 != 0) {
            printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe......");
            getchar(); // �?i ngu?i d�ng nh?n ph�m
            getchar(); // �?m b?o kh�ng b? qua l?nh
        }
    } while (LuaChon5 != 0);
}

int main() {
    SuLyHienThi5(); // G?i h�m x? l� ch�nh
    return 0;
}

