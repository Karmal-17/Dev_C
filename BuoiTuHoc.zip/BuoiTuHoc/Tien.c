#include <stdio.h>
void HienThi3(){
	printf("\n ====== Tinh Tien Karaoke ======");
	printf("\n + 1.Tinh Tien Karaoke.        +");
	printf("\n + 2.Thoat Chuong Trinh.       +");
	printf("\n ===============================");
} 

void SuLyHienThi3(){
	int LuaChon3;
	do {
		system("cls");
		HienThi3();
		printf("\n Vui Long Chon So Ban Muon: ");
		scanf("%d",&LuaChon3);
		switch(LuaChon3){
			case 1: {
				int GioVao,GioRa,TongGio;
	            float ThanhTien = 0;
	            printf("\n Vui Long Nhap So Gio Vao (12h - 23h): ");
	            scanf("%d",&GioVao);
	            printf("\n Vui Long Nhap So Gio Ra (12h - 23h): ");
	            scanf("%d",&GioRa);
	            printf("\n So Gio Ban Vua Nhap Tu %d gio Den %d gio.",GioVao,GioRa);
	            TongGio = GioRa - GioVao;
	            if (GioVao < 12 || GioVao > 23 || GioRa < 12 || GioRa > 23 || GioVao >= GioRa){
	            	printf("\n Ban Da Nhap Sai So Gio Vao Hoac So Gio Ra");
	            	printf("\n Vui Long Nhap Lai So Gio Nhe.");
	            } else {
	        	    if (TongGio <= 3) {
                        ThanhTien = TongGio * 50.000;
                    } else {
                    	ThanhTien = 3 * 50.000;
                	    ThanhTien += (TongGio - 3) * 50.000 * 0.7;
		    	    }
			        if (GioVao >= 14 && GioVao <= 17){
			    	    ThanhTien *= 0.9; 
			        }
			        printf("\n Tong Tien Ma Ban Phai Tra Sau %d Gio La: %.3f VND\n",TongGio,ThanhTien);
	        	}
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Tinh.");
				break;
			}
			default :
				printf("\n Ban Da Chon Sai So!");
				printf("\n Vui Long Chon Lai.");
		} if (LuaChon3 != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe.......");
		    getchar();
		    getchar();
		}
	} while (LuaChon3 != 0);
}
int main(){
	int LuaChon;
	SuLyHienThi3();
	return 0;
}
