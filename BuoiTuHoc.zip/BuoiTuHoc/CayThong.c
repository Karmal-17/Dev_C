#include <stdio.h>

void drawChristmasTree(int height) {
    // V? ph?n l� c�y
    int i,j;
    for (i = 1; i <= height; i++) {
        for (j = 1; j <= height - i; j++) {
            printf(" "); // In kho?ng tr?ng d? canh gi?a
        }
        for ( j = 1; j <= (2 * i - 1); j++) {
            if (j % 2 == 0) {
                printf("o"); // Trang tr� v?i "o"
            } else {
                printf("*"); // In k� t? "*"
            }
        }
        printf("\n");
    }

    // V? th�n c�y
    for ( i = 0; i < 5; i++) { // Chi?u cao th�n c�y l� 3
        for ( j = 1; j < height - 1; j++) {
            printf(" "); // Canh gi?a th�n c�y
        }
        printf("|||"); // Th�n c�y
        printf("\n");
    }
}

int main() {
    int height;

    printf("Nh?p chi?u cao c?a c�y th�ng Noel: ");
    scanf("%d", &height);

    drawChristmasTree(height);

    return 0;
}

