#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void HienThiMenu(){
	printf("\n +-------------- Menu -------------+");
	printf("\n + 1. Nhap Thong Tin Ca Nhan.      +");
	printf("\n + 2. Tinh Tong.                   +");
	printf("\n + 3. Thong Tin Sinh Vien Cac Lop. +");
	printf("\n + 0.Thoat Chuong Trinh.           +");
	printf("\n -----------------------------------");
	printf("\n Moi Ban Chon Chon So: ");
}

int main(){
	int LuaChon;
	do {
		system("cls");
		HienThiMenu();
		scanf("%d",&LuaChon);
		getchar();
		switch(LuaChon){
			case 1: {
				printf("\n Trang Tinh Thong Tin Ca Nhan Nhap Thong Tin Ca Nhan.");
				char Ten[100];
			    int Tuoi;
			    char DiaChi[100];
			    int HocKy;
			    char ChuyenNganh[100];
			    printf("\n Moi Ban Nhap Ho Va Ten: ");
			    gets(Ten);
			    printf("\n Moi Ban Nhap Tuoi: ");
			    scanf("%d",&Tuoi);
			    getchar();
			    printf("\n Nhap Dia Chi Cua Ban: ");
			    gets(DiaChi);
			    printf("\n Nhap Hoc Ky Cua Ban: ");
			    scanf("%d",&HocKy);
			    getchar();
			    printf("\n Moi Ban Nhap Chuyen Nganh Cua Ban: ");
			    gets(ChuyenNganh);
			    printf("\n Thong Tin Cua Ban. ");
			    printf("\n Ten: %s",Ten);
			    printf("\n Tuoi: %d",Tuoi);
			    printf("\n Dia Chi: %s",DiaChi);
			    printf("\n Hoc Ky: %d",HocKy);
			    printf("\n Chuyen Nganh: %s",ChuyenNganh);
			    printf("\n Het Rui Nhe.........");
				break;
			}
			case 2: {
				printf("\n Tinh Tong.");
				int n;
				printf("\n Nhap So Nguyen n: ");
				scanf("%d",&n);
				int i,Tong = 0;
				printf("\n So N Ban Vua Nhap La: %d",n);
				if (n <= 0){
					printf("\n So %d Ban Vua Nhap Be Hon Hoac Bang 0.");
				} else {
					for (i = 0; i <= n;i++){
						Tong += i;
					}
					printf("\n Tong Cac So Nguyen Tu 1 Den %d La: %d",n,Tong);
				}
				break;
			}
			case 3: {
				printf("\n Nhap Thong Tin Sinh. ");
				int SoLuong;
				printf("\n Nhap So Luong Lop Hoc: ");
				scanf("%d",&SoLuong);
				getchar();
				char Ten[SoLuong][100];
				int SoLuongSV[SoLuong];
				if (SoLuong <= 0){
					printf("\n So Luong Lop Hoc Cua Ban Vua Nhap Be Hon Hoac Bang 0");
				} else {
					int i;
					for( i = 0 ; i < SoLuong ; i ++){
					printf("\n Moi Ban Nhap Ten Lop Thu %d La: ",i+1);
					gets(Ten[i]);
					printf("\n Nhap So Luong Sinh Vien Lop: ");
					scanf("%d",&SoLuongSV);
					getchar();
				    }
				    printf("\n +---------------- Xuat Thong Tin Sinh Vien -------------------+");
				    printf("\n So Luong Lop Hoc La: %d",SoLuong);
				    for (i = 0;i < SoLuong; i ++){
				    	printf("\n Ten Lop Thu %d La: %s",i+1,Ten[i]);
				    	printf("\n So Luong Sinh Vien Lop %s La: %d",Ten[i],SoLuongSV[i]);
					}
					int SoLuongNN = SoLuongSV[0];
					for (i = 0;i < SoLuong;i++){
						if (SoLuongSV[i] < SoLuongNN){
							SoLuongNN = i;
						}
					}
					printf("\n Lop Co So Luong Sinh Vien Nho Nhat La: ");
					printf("\n Ten Lop Thu %d La: %s",i+1,Ten[i]);
					printf("\n So Luong Sinh Vien: %d",SoLuongNN);
					if (SoLuongSV[i] < 30 ){
						int Dem = 0;
						for (i = 0;i < SoLuong;i++){
							printf("\n Ten Lop Thu %d La: %s",i+1,Ten[i]);
							printf("\n So Luong Sinh Vien: %d",SoLuongSV[i]);
							Dem ++;
						}
						printf("\n Co So Luong Lop Hoc Co So Luong Sinh Vien Be Hon 30 La: %d",Dem);
					} else {
						printf("\n Trong Nhung Lop Ban Vua Nhap Chua Co Lop Hoc Nao Co Luong Sinh Vien Be Hon 30.");
					}
				}
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default :
				printf("\n Ban Da Chon Sai So Rui!");
				printf("\n Vui Long Chon Lai Nhe.");
		}
		if (LuaChon != 0){
			printf("\n Nhan Vua Phim Bat Ky De Tiep Tuc Nhe........");
			getchar();
			getchar();
		}
	} while (LuaChon != 0);
	return 0;
}
