#include <stdio.h>
#include <math.h>

void HienThi2(){
	printf("\n ====== Tim Uoc Va Boi Chung ======");
	printf("\n + 1.Tim Uoc Chung.               +");
	printf("\n + 2.Tim Boi Chung.               +");
	printf("\n + 3.Tim Ca Uoc Va Boi Chung.     +");
	printf("\n + 0.Thoat Truong Trinh.          +");
	printf("\n ==================================");
}

void SuLyHienThi2(){
	int LuaChon2;
	do {
		system("cls");
		HienThi2();
		printf("\n Nhap Lua Chon Cua Ban: ");
		scanf("%d",&LuaChon2);
		switch(LuaChon2){
			case 1: {
				printf("\n 1.Tim Uoc Chung Cua Hai So.");
				float a,b;
				printf("\n Nhap So Thu Nhat: ");
				scanf("%f",&a);
				printf("\n Nhap So Thu Hai: ");
				scanf("%f",&b);
				printf("\n So Ban Vua Nhap La: a = %.2f va b = %.2f",a,b);
				if (a == (int)a && b == (int)b){
					if (a <= 0 || a <= 0){
						printf("\n Ca Hai So Deu Be Hon Khong.");
						printf("\n Phep Tinh Chua Duoc Thuc Hien.");
					} else {
						int UocChungLN = (int)b;
						b = (int)a % (int)b;
						a = UocChungLN;
						printf("\n Uoc chung lon nhat cua %d va %d la: %d\n", (int)a, (int)b, UocChungLN);
					}
				} else {
					printf("\n Hai So Ban Vua Nhap Chua Phai La So Nguyen.");
					printf("\n Nen Phep Tinh Chua Duoc Thuc Hien.");
				}
				
				break;
			}
			case 2: {
				printf("\n Tim Boi Chung Nho Nhat Cua Hai So.");
				float a,b;
				printf("\n Nhap So a = ");
				scanf("%f",&a);
				printf("\n Nhap So b = ");
				scanf("%f",&b);
				printf("\n Cac So Ban Vua Nhap La: a = %.2f va b = %.2f",a,b);
				if (a == (int)a && b == (int)b){
					if(a <= 0 || b <= 0){
						printf("\n Hai So Ban Vua Nhap Be Hon Hoac Bang 0.");
						printf("\n Nen Phep Tinh Chua Duoc Thuc Hien.");
					} else {
						int UocChungLN = (int)b;
						b = (int)a % (int)b;
						a = UocChungLN;
						int BoiChungNN = (int)(a * b) / UocChungLN;
						printf("\n Boi Chung Nho Nhat Cua %d va %d La: %d",(int)a,(int)b,BoiChungNN);
					}
				} else {
					printf("\n Hai So Ban Vua Nhap Chua Phai La So Nguyen.");
					printf("\n Vui Long Chon Va Nhap lai.");
				}
				break;
			}
			case 3:{
				printf("\n Tim Ca Uoc Chung Lon Nhat Va Boi Chung Nho Nhat Cua Hai So.");
				float a,b;
				printf("\n Nhap So a = ");
				scanf("%f",&a);
				printf("\n Nhap So b = ");
				scanf("%f",&b);
				printf("\n Cac So Ban Vua Nhap La: a = %.2f va b = %.2f");
				if (a == (int)a && b == (int)b){
					if (a <= 0 || b <= 0){
						printf("\n Hai So Ban Vua Nhap Be Hon Hoac Bang 0.");
						printf("\n Nen Phep Tinh Chua Duoc Thuc Hien.");
					} else {
						int UocChungLN = (int)b;
						b = (int)a % (int)b;
						a = UocChungLN;
						int BoiChungNN = (int)(a * b) / UocChungLN;
						printf("\n Uoc Chung Lon Nhat Cua %d Va %d La: %d",(int)a,(int)b,UocChungLN);
						printf("\n Boi Chung Nho Nhat Cua %d Va %d La: %d",(int)a,(int)b,BoiChungNN);
					}
				} else {
					printf("\n Hai So Ban Vua Nhap Chua Phai La So Nguyen.");
					printf("\n Vui Long Chon Va Nhap Lai.");
				}
				break;
			}
			case 4: {
				printf("\n Dang Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Tinh.");
				break;
			}
			default :
				printf("\n Ban Chon Sai So Rui!");
				printf("\n Vui Long Chon lai So Nhe.");
		}
		if (LuaChon2 != 0){
			printf("\n Nhan Vao Phim Bat Ki De Tiep Tuc Nhe........");
			getchar();
			getchar();
		}
	} while (LuaChon2 != 0);
}

int main(){
	SuLyHienThi2();
	return 0;
}
