#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    int SoLuong;

    printf("\n Nhap So Luong Lop Hoc: ");
    scanf("%d", &SoLuong);
    getchar(); // Lo?i b? k� t? xu?ng d�ng c�n s�t l?i trong b? d?m

    if (SoLuong <= 0) {
        printf("\n So Luong Lop Hoc Ban Nhap Be Hon Hoac Bang 0.\n");
        return 0; // Tho�t chuong tr�nh n?u s? lu?ng l?p kh�ng h?p l?
    }

    // Khai b�o m?ng d?ng d? luu th�ng tin l?p h?c
    char Ten[SoLuong][100]; // M?i t�n l?p c� t?i da 99 k� t?
    int SoLuongSV[SoLuong];

    // Nh?p th�ng tin t?ng l?p
    for (int i = 0; i < SoLuong; i++) {
        printf("\n Moi Ban Nhap Ten Lop Thu %d: ", i + 1);
        fgets(Ten[i], sizeof(Ten[i]), stdin);
        Ten[i][strcspn(Ten[i], "\n")] = '\0'; // Lo?i b? k� t? xu?ng d�ng

        printf("\n Nhap So Luong Sinh Vien Lop %s: ", Ten[i]);
        scanf("%d", &SoLuongSV[i]);
        getchar(); // Lo?i b? k� t? xu?ng d�ng c�n s�t l?i
    }

    // In th�ng tin c�c l?p h?c
    printf("\n +---------------- Xuat Thong Tin Lop Hoc -------------------+");
    printf("\n So Luong Lop Hoc: %d", SoLuong);
    for (int i = 0; i < SoLuong; i++) {
        printf("\n Ten Lop Thu %d: %s", i + 1, Ten[i]);
        printf("\n So Luong Sinh Vien Lop %s: %d", Ten[i], SoLuongSV[i]);
    }

    // T�m l?p c� s? lu?ng sinh vi�n nh? nh?t
    int minSV = SoLuongSV[0];
    int minIndex = 0;
    for (int i = 1; i < SoLuong; i++) {
        if (SoLuongSV[i] < minSV) {
            minSV = SoLuongSV[i];
            minIndex = i;
        }
    }
    printf("\n\n Lop Co So Luong Sinh Vien Nho Nhat La:");
    printf("\n Ten Lop: %s", Ten[minIndex]);
    printf("\n So Luong Sinh Vien: %d\n", minSV);

    // Li?t k� c�c l?p c� s? lu?ng sinh vi�n < 30
    printf("\n +---------- Danh Sach Lop Co So Luong Sinh Vien < 30 ----------+");
    int found = 0;
    for (int i = 0; i < SoLuong; i++) {
        if (SoLuongSV[i] < 30) {
            printf("\n Ten Lop: %s, So Luong Sinh Vien: %d", Ten[i], SoLuongSV[i]);
            found = 1;
        }
    }
    if (!found) {
        printf("\n Khong Co Lop Hoc Nao Co So Luong Sinh Vien < 30.");
    }

    return 0;
}

