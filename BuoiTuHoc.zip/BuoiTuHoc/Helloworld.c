#include <stdio.h>

int main (){
	printf("\n Hello world")
}
