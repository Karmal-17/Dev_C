#include <stdio.h>

void tinhLaiSuat(int tienVay, float laiSuat, int kyHan) {
    int tienGocPhaiTra = tienVay / kyHan;
    int soDu = tienVay;
    
    printf("Ky han\tLai phai tra\tGoc phai tra\tSo tien phai tra\tSo tien con lai\n");
    int i;
    for (i = 1; i <= kyHan; i++) {
        int tienLaiPhaiTra = (int)(soDu * laiSuat);
        int soTienPhaiTra = tienLaiPhaiTra + tienGocPhaiTra;
        soDu -= tienGocPhaiTra;

        printf("%d\t%d\t\t%d\t\t%d\t\t\t%d\n", i, tienLaiPhaiTra, tienGocPhaiTra, soTienPhaiTra, soDu);
    }
}

int main() {
    int tienVay = 12000000;  // S? ti?n vay (12 tri?u)
    float laiSuat = 0.05;   // L�i su?t 5%/th�ng
    int kyHan = 12;         // K? h?n 12 th�ng

    tinhLaiSuat(tienVay, laiSuat, kyHan);

    return 0;
}

