#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
	char Khoa[] = "TG00418";
	char NhapKhoa[50];
	printf("\n Vui Long Nhap Mat Khau: ");
	while (1) {
	    system("cls");
		fgets(NhapKhoa,sizeof(NhapKhoa),stdin);
		NhapKhoa[strcspn(NhapKhoa, "\0")] = 0;
		if (strstr(NhapKhoa,Khoa)) {
			printf("\n Da Mo Khoa. ");
			system("clear");
			SuLyHienThi();
		} else {
			printf("\n Ban Da Nhap Khoa Sai Roi! Vui Long Nhap Lai Nhe: ");
		}
	}

	return 0;
}

