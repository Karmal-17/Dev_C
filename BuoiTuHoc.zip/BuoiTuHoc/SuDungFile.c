#include <stdio.h>

#include <stdio.h>

int main() {
    FILE *file;

    // Ghi v�o file
    file = fopen("example.txt", "w");
    if (file == NULL) {
        printf("Khong The Mo File De Ghi Du Lieu!\n");
        return 1;
    }
    fprintf(file, "Xin Chao, Day La File Van Ban.\n");
    fprintf(file, "Hoc Ngon Ngu C Rat Thu Vi!\n");
    fclose(file);

    // �?c t? file
    file = fopen("example.txt", "r");
    if (file == NULL) {
        printf("Khong The Mo File De Doc Duoc!\n");
        return 1;
    }
    char buffer[100];
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        printf("%s", buffer);
    }
    fclose(file);

    return 0;
}

