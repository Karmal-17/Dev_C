#include <stdio.h>
#include <graphics.h>
#include <conio.h>
int main(){
	int gd = DETECT,gm;
	initgraphic(&gd,&gm,"");
	line (100,100,200,200);
	getch();
	closegraphic();
	return 0;
}
