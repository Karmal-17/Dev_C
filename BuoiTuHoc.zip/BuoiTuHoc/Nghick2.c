#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main() {
//	textcolor(4);
    int a, b, i;
    while (1) {
        printf("Vui Long Nhap So A = ");
        scanf("%d", &a);
        printf("\nVui Long Nhap So B = ");
        scanf("%d", &b);
        printf("\n+-------------+\n");

        if (a < b) {
            printf("\n So Chan: ");
            for (i = a; i <= b; i++) {
                if (i % 2 == 0) {
                    printf("%d ", i);
                }
            }
            printf("\n So Le: ");
            for (i = a; i <= b; i++) {
                if (i % 2 != 0) {
                    printf("%d ", i);
                }
            }
        } else {
            printf("\n So Chan: ");
            for (i = a; i >= b; i--) {
                if (i % 2 == 0) {
                    printf("%d ", i);
                }
            }
            printf("\n So Le: ");
            for (i = a; i >= b; i--) {
                if (i % 2 != 0) {
                    printf("%d ", i);
                }
            }
        }
        printf("\n");
    }
    return 0;
}


