#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>

void draw_firework(int x, int y, int color) {
    setcolor(color);
    int i;
    for ( i = 0; i < 360; i += 15) {
        int dx = x + 50 * cos(i * M_PI / 180.0);
        int dy = y + 50 * sin(i * M_PI / 180.0);
        line(x, y, dx, dy);
    }
}

void fireworks_display() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, NULL);

    srand(time(0));
    int i;
    for ( i = 0; i < 20; i++) {
        cleardevice();
        int x = rand() % getmaxx();
        int y = rand() % (getmaxy() / 2);
        int color = 1 + rand() % 15;
        draw_firework(x, y, color);
        delay(500);
    }

    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    setcolor(YELLOW);
    outtextxy(getmaxx() / 2 - 150, getmaxy() - 100, "Chuc Mung Nam Moi!");

    delay(3000);
    closegraph();
}

int main() {
    fireworks_display();
    return 0;
}

