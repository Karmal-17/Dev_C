#include <stdio.h>
#include <string.h>

void HienThiMenu(){
	printf("\n ============ Menu ==============");
	printf("\n + 1.Thong Tin Nguoi Yeu Cu.    +");
	printf("\n + 2.Tong Cac So Le Tu 1 Den n. +");
	printf("\n + 3.Thong Tin Vac Xin.         +");
	printf("\n + 0.Thoat Chuong Trinh.        +");
	printf("\n ================================");
	printf("\n Nhap So Ma Ban Muon: ");
}

void SuLyThongTinNguoiYeuCu(){
	printf("\n Thong Tin Nguoi Yeu Cu.");
	int SoLuongNguoiYeuCu;
	printf("\n Vui Long Thanh That Voi So Nguoi Yeu Cu Cua Ban: ");
	scanf("%d",&SoLuongNguoiYeuCu);
	getchar();
	char Ten[SoLuongNguoiYeuCu][100];
	int SoLanCamSungBan[SoLuongNguoiYeuCu];
	if(SoLuongNguoiYeuCu <= 0){
		printf("\n Khong Ngo Ban Chua Co Nguoi Yeu Cu.");
		printf("\n Vui Long Them Ngay 1 Vai Nguoi Yeu Cu Nhe.");
	} else {
		int i,j;
		for (i = 0;i < SoLuongNguoiYeuCu;i++){
			printf("\n Nhap Ten Nguoi Yeu Cu Thu %d Cua Ban: ",i+1);
			gets(Ten[i]);
			printf("\n Nhap So Lan Cam Sung Ban: ");
			scanf("%d",SoLanCamSungBan[i]);
			getchar();
		}
		for (i = 0;i < SoLuongNguoiYeuCu;i ++){
			for (j = 0 ; j < SoLuongNguoiYeuCu; j ++){
				if (SoLanCamSungBan[i] < SoLanCamSungBan[j]){
					int SoLan = SoLanCamSungBan[i];
					SoLanCamSungBan[i] = SoLanCamSungBan[j];
					SoLanCamSungBan[j] = SoLan;
					
					char Tenx[100] ;
					strcpy(Tenx,Ten[i]);
					strcpy(Ten[i],Ten[j]);
					strcpy(Ten[j],Tenx);
				}
			}
		}
		printf("\n Thong Tin Xep Hang %d Nguoi Yeu Cu Co So Lan Cam Sung Ban Nhieu Nhat: ",SoLuongNguoiYeuCu);
		for (i = 0;i < SoLuongNguoiYeuCu;i++){
			printf("\n Ten Cua Nguoi Yeu Cu Thu %d La: %s",i+1,Ten[i]);
			printf("\n So Lan Cam Sung Ban : %d",SoLanCamSungBan[i]);
		}
	}
}

void SuLyHienThi2(){
	printf("\n Tong Cac So Le Tu 1 Den n.");
	int n,i;
	printf("\n Nhap So Nguyen n Ma Ban Muon: ");
	scanf("%d",&n);
	int Tong = 0;
	int SoChanLonNhat = 0;
	printf("\n Cac So Le Tu 1 Den %d La: ",n);
	for (i = 0; i <= n; i ++){
		if (i % 2 != 0){
			printf("%d  ",i);
			Tong += i;
		} else {
			if (i > SoChanLonNhat){
				SoChanLonNhat = i;
			}
		}
	}
	printf("\n Tong Cac So Nguyen Le La: %d",Tong);
	if (SoChanLonNhat != 0){
		printf("\n So Chan Lon Nhat Tu 1 Den %d La: %d",n,SoChanLonNhat);
	} else {
		printf("\n Khong Co So Chan Tu 1 Den %d.",n);
	}
}
void HienThi3(){
	printf("\n ============ Nhap Vacxin ===============");
	printf("\n + 1.So Luong VacXin Vs Thoi Gian       +");
	printf("\n + 0. Thoat Chuong Trinh.               +");
	printf("\n ========================================");
	printf("\n Moi Ban Chon So Ban Muon: ");
}
void SuLyHienThi3(){
	int LuaChon1;
	do {
		system("cls");
		HienThi3();
		scanf("%d",&LuaChon1);
		switch(LuaChon1){
			case 1: {
				printf("\n Thong Tin Ve Vacxin.");
	            int SoThongTin;
	            printf("\n Nhap So Luong Vacxin: ");
	            scanf("%d",&SoThongTin);
	            getchar();
	            char Ten[SoThongTin][100];
	            int SoLuong[SoThongTin];
	            int i;
	            int ThoiGian[SoThongTin];
	            if (SoThongTin <= 0){
	            	printf("\n So Vacxin Ban Vua Nhap Da Be Hon 0.");
	            	printf("\n Vui Long Di Tiem Vac Xin Ngay.");
				} else {
					for(i = 0; i < SoThongTin; i ++){
						printf("\n Ten Vac xin Thu %d La: ",i+1);
						gets(Ten[i]);
						printf("\n Nhap So Luong Vacxin %s : ",Ten[i]);
						scanf("%d",&SoLuong);
						printf("\n Thoi Gian Vacxin %s : ",Ten[i]);
						scanf("%d",&ThoiGian);
						getchar();
					}
					int ThoiGianThapNhat = 0;
					int ThoiGianCaoNhat = 1;
					for (i = 0;i < SoThongTin; i++){
						if (i < ThoiGianCaoNhat){
							ThoiGianCaoNhat = i;
						}
					}
					for (i = 0;i < SoThongTin; i++){
						if (i > ThoiGianThapNhat){
							ThoiGianThapNhat = i;
						}
					}
					
					printf("\n ======= Xuat Thong Em Tin =========");
					printf("\n Thong Tin Cac %d VacXin La: ");
					for (i = 0;i < SoThongTin;i ++){
						printf("\n Ten VacXin Thu %d La: %s",i+1,Ten[i]);
						printf("\n So Luong VacXin %s La: %d",Ten[i],SoLuong[i]);
						printf("\n Thoi Gian VacXin %s : %d");
					}
				}
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh. ");
				printf("\n Cam On Ban Da Su Dung.");
				break;
			}
			default:
				printf("\n Ban Da Chon Sai So Rui! ");
				printf("\n Vui  Long Chon Lai.");
		} 
		if(LuaChon1 != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe......");
			getchar();
			getchar();
		}
	} while (LuaChon1 != 0);
	
	
}
int main (){
	int LuaChon;
	do {
		system("cls");
		HienThiMenu();
		scanf("%d",&LuaChon);
		getchar();
		switch(LuaChon){
			case 1: {
				SuLyThongTinNguoiYeuCu();
				break;
			}
			case 2: {
				SuLyHienThi2();
				break;
			}
			case 3: {
				SuLyHienThi3();
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default :
				printf("\n Ban Da Chon Sai So Rui!");
				printf("\n Vui  Long Chon Lai So Nhe.");
		}
		if (LuaChon != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiec Tuc Nhe......");
			getchar();
			getchar();
		}
	} while (LuaChon != 0);
}
