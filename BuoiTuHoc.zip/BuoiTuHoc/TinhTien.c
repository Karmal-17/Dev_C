void HienThi3() {
    int LuaChon3;
    do {
        system("cls");
        HienThi3();
        printf("\n Moi Ban Chon So.\n");
        
        int GioVao, GioRa, TongGio;
        float ThanhTien = 0;
        // Nh?p gi? v�o v� gi? ra
        printf("\nVui Long Nhap So Gio Vao (12h - 23h): ");
        scanf("%d", &GioVao);
        printf("\nVui Long Nhap So Gio Ra (12h - 23h): ");
        scanf("%d", &GioRa);

        // T�nh to�n th?i gian v� ki?m tra di?u ki?n
        TongGio = GioRa - GioVao;
        if (GioVao < 12 || GioRa < 12 || GioRa > 23 || GioVao > 23 || GioVao >= GioRa) {
            printf("\nBan Da Nhap Sai So Gio Hoac So Gio Ra.");
            printf("\nVui Long Nhap Lai So Gio Nhe.");
        } else {
            if (TongGio <= 3) {
                ThanhTien = TongGio * 50000;
            } else {
                ThanhTien = 3 * 50000;
                ThanhTien += (TongGio - 3) * 50000 * 0.7;
            }

            if (GioVao >= 14 && GioVao <= 17) {
                ThanhTien *= 0.9;
            }

            printf("\nTong Thoi Gian Ban Thue La %d Gio.", TongGio);
            printf("\nSo Tien Ma Ban Phai Tra Sau %d Gio La: %.3f VND\n", TongGio, ThanhTien);
        }

        // H?i ngu?i d�ng c� mu?n ti?p t?c kh�ng
        printf("\nBan Co Muon Tiep Tuc? (y/n): ");
        getchar(); // X�a b? d?m
        tiepTuc = getchar();

    } while (tiepTuc == 'y' || tiepTuc == 'Y');
}

