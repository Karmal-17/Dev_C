#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
void HienThi(){
	printf("\n +---------- Hien Thi Menu -------------+");
	printf("\n 1. Tinh Toan Co Ban.");
	printf("\n 2. Tinh Toan Nang Cao.");
	printf("\n 3. Thong Tin Ca Nhan.");
	printf("\n 4. Thong Tin Sinh Vien.");
	printf("\n 0. Thoat Chuong Trinh.");
	printf("\n +--------------------------------------+");
	printf("\n Moi Ban Chon So: ");
}
void HienThi1(){
	printf("\n Tinh Toan Co Ban.");
	printf("\n 1. Phep Tinh Cong Hai So A Va B.");
	printf("\n 2. Phep Tinh Tru Hai So A Va B.");
	printf("\n 3. Phep Tinh Nhap Hai So A Va B.");
	printf("\n 4. Phep Tinh Chia Hai So A Va B.");
	printf("\n 0. Thoat Chuong Trinh.");
}
void SuLyHienThi1(){
	int LuaChon1;
	do {
		system("cls");
		HienThi1();
		printf("\n Vui Long Chon So: ");
		scanf("%d",&LuaChon1);
		switch(LuaChon1){
			case 1: {
				printf("\n Phep Tinh Cong Hai So A Va B.");
				int a,b;
				printf("\n Vui Long Nhap So A = ");
				scanf("%d",&a);
				printf("\n Vui Long Nhap So B = ");
				scanf("%d",&b);
				int Tong = 0;
				Tong = a + b;
				printf("\n Tong Hai So %d Va %d La: %d",a,b,Tong);
				printf("\n Het Rui");
				break;
			}
			case 2: {
				printf("\n Phep Tinh Tru Hai So A Va B.");
				int a,b;
				printf("\n Vui Long Nhap So A = ");
				scanf("%d",&a);
				printf("\n Vui Long Nhap So B = ");
				scanf("%d",&b);
				int Tru ;
				Tru = a - b;
				printf("\n Ket QUa Phep Tinh Tru Hai So %d Va %d La: %d",a,b,Tru);
				printf("\n Het Rui.");
				break;
			}
			case 3: {
				printf("\n Phep Tinh Nhan Hai So A Va B.");
				int a,b,Nhan;
				printf("\n Vui Long Nhap So A = ");
				scanf("%d",&a);
				printf("\n Vui Long Nhap So B = ");
				scanf("%d",&b);
				Nhan = a * b;
				printf("\n Ket Qua Cua Phep Tinh Nhan Hai So %d Va %d La: %d",a,b,Nhan);
				printf("\n Het Rui");
				break;
			}
			case 4: {
				printf("\n Phep Tinh Chia Hai So A  Va B.");
				int a,b,Chia;
				printf("\n Vui Long Nhap So A = ");
				scanf("%d",&a);
				printf("\n Vui Long Nhap So B = ");
				scanf("%d",&b);
				Chia = a / (float)b;
				printf("\n Ket Qua Phep Chia Hai So %d Va %d La: %d",a,b,Chia);
				printf("\n Het Roi");
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default: 
			printf("\n Ban Da Chon Sai So Roi!");
			printf("\n Vui Long Chon Lai So Nhe.");
		} if (LuaChon1 != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe.....");
			getchar();
			getchar();
		}
	} while (LuaChon1 != 0);
}
void HienThi2(){
	printf("\n Phep Tinh Nang Cao.");
	printf("\n 1. Phuong Trinh Bac Nhat.");
	printf("\n 2. Phuong Trinh Bac Hai.");
	printf("\n 3. Phep Tinh Luy Thua.");
	printf("\n 4. Phep Tinh Gia Tri Tuyet Doi.");
	printf("\n 5. Phep Tint Can Bac Hai.");
	printf("\n 6. Phep Tinh Can Bac Ba.");
	printf("\n 0. Thoat Chuong Trinh.");
}
void SuLyHienThi2(){
	int LuaChon2;
	do {
		system("cls");
		HienThi2();
		printf("\n Vui Long Chon So: ");
		scanf("%d",&LuaChon2);
		switch(LuaChon2){
			case 1: {
				printf("\n Phuong Trinh Bac Nhat.");
				float a,b,x;
				printf("\n Vui Long Nhap So Thu Nhat = ");
				scanf("%f",&a);
				printf("\n Vui Long Nhap So Thu Hai  = ");
				scanf("%f",&b);
				if (a == 0){
					if (b == 0){
						printf("\n Phuong Trinh %.2f * x + %.2f = 0 .",a,b);
						printf("\n Co Vo So Nghiem.");
					} else {
						printf("\n Phuong Trinh %.2f * x + %.2f = 0 .",a,b);
						printf("\n Vo Nghiem.");
					}
				} else {
					printf("\n Phuong Trinh %.2f * x + %.2f = 0 .",a,b);
					printf("\n Co Nghiem Duy Nhat.");
					x = - b / (float)a;
					printf("\n x = %.2f",x);
				}
				break;
			}
			case 2:{
				printf("\n Phuong Trinh Bac Hai.");
				float a,b,c,Delta,x,x1,x2,x3;
				printf("\n Vui Long Nhap So A = ");
				scanf("%f",&a);
				printf("\n Vui Long Nhap So B = ");
				scanf("%f",&b);
				printf("\n Vui Long Nhap So C = ");
				scanf("%f",&c);
				if (a == 0){
					if(b == 0){
						if (c == 0){
							printf("\n Phuong Trinh %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c);
							printf("\n Co Vo So Nghiem.");
						} else {
							printf("\n Phuong Trinh %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c);
							printf("\n Vo Nghiem.");
						}
					} else {
						printf("\n Phuong Trinh %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c);
						printf("\n Co Nhiem Duy Nhat La:");
						x = - b / c;
						printf("\n x = %.2f.",x);
					}
				} else {
					Delta = b * b - 4 * a * c;
					x1 = (- b + sqrt(Delta)) / (2 * a);
					x2 = (- b - sqrt(Delta)) / (2 * a);
					if (Delta > 0){
						printf("\n Phuong Trinh %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c);
						printf("\n Co Hai Nghiem Phan Biet:");
						printf("\n x1 = %.2f.",x1);
						printf("\n x2 = %.2f.",x2);
					} else {
						if (Delta == 0){
							printf("\n Phuong Trinh %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c);
							printf("\n Co Nghiem Kep.");
							x3 = - b / 2 * a;
							printf("\n x = %.2f.",x3);
						} else {
							printf("\n Phuong Trinh %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c);
							printf("\n Vo Nghiem.");
						}
					}
				}
				
				break;
			}
			case 3: {
				printf("\n Phep Tinh Luy Thua.");
				float a,b;
				printf("\n Vui Long Nhap Phan Co So: ");
				scanf("%f",&a);
				printf("\n Vui Long Nhap Phan So Mu: ");
				scanf("%f",&b);
				printf("\n Ket Qua Cua %.2f^%.2f La: %.2f",a,b,pow(a,b));
				break;
			}
			case 4: {
				printf("\n Phep Tinh Gia Tri Tuyet Doi.");
				float a;
				printf("\n Vui Long Nhap So Ban Muon: ");
				scanf("%f",&a);
				printf("\n Ket Qua Cua Phep Toan Tinh Gia Tri Tuyet Doi La: %.2f",fabs(a));
				break;
			}
			case 5:{
				printf("\n Phep Toan Tinh Can Bac Hai");
				float a;
				printf("\n Vui Long Nhap So A = ");
				scanf("%f",&a);
				if (a <= 0){
					printf("\n So Ban Vua Nhap Be Hon Hoac Bang 0.");
				} else {
					printf("\n Ket Qua Cua Can Bac Hai La: %.2f",sqrt(a));
				}
				break;
			}
			case 6: {
				printf("\n Phep Toan Tinh Can Bac Ba:");
				float a;
				printf("\n Vui Long Nhap So Ban Muon Tinh: ");
				scanf("%f",&a);
				if (a <= 0){
					printf("\n So Ban Vua Nhap Be Hon Hoac Bang 0.");
					printf("\n Vui Long Chon So Va Nhap Lai Nhe.");
				} else {
					printf("\n Ket Qua Cua Phep Tinh Can Bac Ba La: %.2f",cbrt(a));
				}
				break;
			} 
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung.");
				break;
			}
			default: 
			printf("\n Ban Da Chon Sai So Roi!");
			printf("\n Vui Long Chon Lai So Nhe.");
		} 
		if (LuaChon2 != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Chuong Trinh Nhe....");
			getchar();
			getchar();
		}
	} while (LuaChon2 != 0);
}
void SuLyHienThi3(){
	printf("\n Nhap Thong Tin Ca Nha Cua Ban: ");
	char Ten[100];
	int Tuoi;
	float Diem;
	char DiaChi[100];
	getchar();
	printf("\n Vui Long Nhap Ten Cua Ban: ");
	gets(Ten);
	printf("\n Vui Long Nhap Tuoi Cua Ban: ");
	scanf("%d",&Tuoi);
	printf("\n Vui Long Nhap Diem Cua Ban: ");
	scanf("%f",&Diem);
	getchar();
	printf("\n Vui Long Nhap Dia Chi Cua Ban: ");
	gets(DiaChi);
	printf("\n \n Thong Tin Ca Nhan Cua Ban La: ");
	printf("\n Ten: %s",Ten);
	printf("\n Tuoi: %d",Tuoi);
	printf("\n Diem: %.1f",Diem);
	printf("\n Dia Chi: %s",DiaChi);
	printf("\n Het Roi!");
}

void SuLyHienThi4() {
    printf("\n Thong Tin Sinh Vien.");
    int i,SoLuong;

    printf("\n Vui Long Nhap So Luong Sinh Vien: ");
    scanf("%d", &SoLuong);
    getchar();

    if (SoLuong <= 0) {
        printf("\n So Luong Sinh Vien Ban Vua Nhap Be Hon Hoac Bang 0.");
        printf("\n Vui Long Chon Va Nhap Lai Nhe.");
        return;
    }

    char Ten[SoLuong][100];
    float Diem[SoLuong];
    float CanNang[SoLuong];

    for (i = 0; i < SoLuong; i++) {
        printf("\n Vui Long Nhap Ten Cua Sinh Vien Thu %d: ", i + 1);
        fgets(Ten[i], sizeof(Ten[i]), stdin);
        Ten[i][strcspn(Ten[i], "\n")] = '\0'; // Remove newline character

        printf("\n Vui Long Nhap Diem Cua Sinh Vien %s: ", Ten[i]);
        scanf("%f", &Diem[i]);

        printf("\n Vui Long Nhap Can Nang Cua Sinh Vien %s: ", Ten[i]);
        scanf("%f", &CanNang[i]);
        getchar();
    }

    // Find max and min scores and weights
    int ViTriMaxDiem = 0, ViTriMinDiem = 0, ViTriMaxCanNang = 0, ViTriMinCanNang = 0;

    for ( i = 1; i < SoLuong; i++) {
        if (Diem[i] > Diem[ViTriMaxDiem]) ViTriMaxDiem = i;
        if (Diem[i] < Diem[ViTriMinDiem]) ViTriMinDiem = i;
        if (CanNang[i] > CanNang[ViTriMaxCanNang]) ViTriMaxCanNang = i;
        if (CanNang[i] < CanNang[ViTriMinCanNang]) ViTriMinCanNang = i;
    }

    // Display results
    printf("\n Sinh Vien Co So Diem Cao Nhat La: %s", Ten[ViTriMaxDiem]);
    printf("\n Diem: %.2f", Diem[ViTriMaxDiem]);
    printf("\n Can Nang: %.2f", CanNang[ViTriMaxDiem]);

    printf("\n\n Sinh Vien Co Can Nang Cao Nhat La: %s", Ten[ViTriMaxCanNang]);
    printf("\n Diem: %.2f", Diem[ViTriMaxCanNang]);
    printf("\n Can Nang: %.2f", CanNang[ViTriMaxCanNang]);

    printf("\n\n Sinh Vien Co So Diem Thap Nhat La: %s", Ten[ViTriMinDiem]);
    printf("\n Diem: %.2f", Diem[ViTriMinDiem]);
    printf("\n Can Nang: %.2f", CanNang[ViTriMinDiem]);

    printf("\n\n Sinh Vien Co Can Nang Thap Nhat La: %s", Ten[ViTriMinCanNang]);
    printf("\n Diem: %.2f", Diem[ViTriMinCanNang]);
    printf("\n Can Nang: %.2f", CanNang[ViTriMinCanNang]);

    // Students with scores >= 8
    printf("\n\n Nhung Sinh Vien Co Diem Lon Hon Hoac Bang 8 La:");
    int Dem = 0;
    for ( i = 0; i < SoLuong; i++) {
        if (Diem[i] >= 8) {
            printf("\n - %s (Diem: %.2f, Can Nang: %.2f)", Ten[i], Diem[i], CanNang[i]);
            Dem++;
        } 
    }
    if (Dem == 0) {
        printf("\n Khong Co Sinh Vien Nao Co Diem Lon Hon Hoac Bang 8.");
    }
    printf("\n Tong So Sinh Vien Co Diem Lon Hon Hoac Bang 8: %d\n", Dem);
}

void ChayHam() {
    int LuaChon;
    do {
    	system("cls");
    	HienThi();
    	scanf("%d",&LuaChon);
    	switch(LuaChon){
    		case 1: {
    			SuLyHienThi1();
				break;
			}
			case 2: {
				SuLyHienThi2();
				break;
			}
			case 3:{
				SuLyHienThi3();
				break;
			} 
			case 4: {
				SuLyHienThi4();
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default:
				printf("\n Ban Da Chon Sai So Rui!");
				printf("\n Vui Long Chon Lai So Nhee.");
		}
		if (LuaChon != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Chuong Trinh Nhe....");
			getchar();
			getchar();
		}
	} while (LuaChon != 0);
}

int main() {
    char correctKey[] = "Key123";  // Kh�a d�ng
    char inputKey[50];            // Kh�a do ngu?i d�ng nh?p

    printf("Nhap Khoa Bi Mat De Mo Ham Kho Bi Mat: ");
    while (1) {  // Lop Cho Den Khi Nhap Dung
        fgets(inputKey, sizeof(inputKey), stdin);
        inputKey[strcspn(inputKey, "\n")] = 0; // Xoa Ky Tu Xuong Dong

        // Kiem Tra Neu Chuoi Nhap Khoa Dung
        if (strstr(inputKey, correctKey)) {
            printf("Kh�a ch�nh x�c!\n");
            ChayHam();
            break;  // Thoat Khoi Vong Lap;
        }
    }

    return 0;
}

