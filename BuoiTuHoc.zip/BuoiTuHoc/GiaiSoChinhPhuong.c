#include <stdio.h>
#include <math.h>

int is_perfect_square(int n) {
    if (n < 0) return 0; // Kh�ng c� s? ch�nh phuong �m
    int sqrt_n = (int)sqrt(n); // L?y can b?c hai nguy�n
    return (sqrt_n * sqrt_n == n); // Ki?m tra n?u b�nh phuong can b?c hai b?ng ch�nh s? d�
}

int main() {
    int number;

    // Nh?p s? t? ngu?i d�ng
    printf("Nh?p m?t s? nguy�n: ");
    scanf("%d", &number);

    // Ki?m tra v� in k?t qu?
    if (is_perfect_square(number)) {
        printf("%d l� s? ch�nh phuong.\n", number);
    } else {
        printf("%d kh�ng ph?i l� s? ch�nh phuong.\n", number);
    }

    return 0;
}

