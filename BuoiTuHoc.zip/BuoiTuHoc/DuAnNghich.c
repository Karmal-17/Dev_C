#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

void HienThi(){
	printf("\n +----------------- Menu Main -----------------+");
	printf("\n + 1. Cac Phep Tinh Co Ban.                    +");
	printf("\n + 2. Cac Phep Tinh Nang Cao.                  +");
//	printf("\n + 3. Cac Cong Thuc Toan Hoc.                  +");
//	printf("\n + 4. Cac Cong Thuc Vat Ly Lop 10.             +");
//	printf("\n + 5. Cac Cong Thuc Vat Ly Lop 11.             +");
//	printf("\n + 6. Cac Cong Thuc Vat Ly Lop 12.             +");
	printf("\n + 3. Thong Tin Ca Nhan.                       +");
	printf("\n + 4. Thong Tin Sinh Vien.                     +");
	printf("\n + 5. Thong Tin Ve Tivi.                       +");
	printf("\n + 6. Thong Tin Ve Con Vat.                    +");
	printf("\n + 0. Thoat Chuong Trinh.                      +");
	printf("\n +---------------------------------------------+");
	printf("\n Vui Long Chon So Ban Muon: ");
}
void HienThi1Y1(){
	printf("\n +-------- Phep Tinh Cong ---------+");
	printf("\n + 1. Phep Tinh Cong Hai So.       +");
	printf("\n + 2. Phep Tinh Cong Ba So.        +");
	printf("\n + 3. Phep Tinh Cong Bon So.       +");
	printf("\n + 4. Phep Tinh Cong Nhieu So.     +");
	printf("\n + 0. Thoat Chuong Trinh.          +");
	printf("\n +---------------------------------+");
	printf("\n Vui Long Chon So Ban Muon: ");
}
void SuLyHienThi1Y1(){
	int LuaChon1Y1;
	do {
		system("cls");
		HienThi1Y1();
		scanf("%d",&LuaChon1Y1);
		switch(LuaChon1Y1){
			case 1: {
				printf("\n Phep Tinh Cong Hai So.");
				double a,b;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				double Tong = a + b;
				printf("\n Ket Qua Cua: %.2lf + %.2lf = %.2lf.",a,b,Tong);
				break;
			}
			case 2: {
				printf("\n Phep Tinh Cong Ba So.");
				double a,b,c,Tong = 0;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				printf("\n Vui Long Nhap So Thu Ba: ");
				Tong = a + b + c;
				printf("\n Ket Qua Cua: %.2lf + %.2lf + %.2lf = %.2lf ",a,b,c,Tong);
				break;
			}
			case 3: {
				printf("\n Phep Tinh Cong Bon So.");
				double a,b,c,d,Tong  = 0;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				printf("\n Vui Long Nhap So Thu Ba: ");
				scanf("%lf",&c);
				printf("\n Vui Long Nhap So Thu Tu: ");
				scanf("%lf",&d);
				Tong = a + b + c + d;
				printf("\n Ket Qua Cua: %.2lf + %.2lf + %.2lf + %.2lf = %.2lf",a,b,c,d,Tong);
				break;
			}
			case 4: {
				printf("\n Phep Tinh Cong Nhieu So.");
				int soluong;
				printf("\n Vui Long Nhap So Luong So: ");
				scanf("%d",&soluong);
				int i;
				double nhanGT[soluong],Tong = 0;
				for (i = 0; i < soluong;i ++){
					printf("\n Vui Long Nhap So Thu %d La: ",i + 1);
					scanf("%lf",&nhanGT[i]);
					Tong += nhanGT[i];
				}
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh Tinh.");
				printf("\n Cam On Ban Da Su Dung Chuong Trinh.");
				break;
			}
			default:
				printf("\n Ban Da Chon Sai So Roi!");
				printf("\n Vui Long Chon Lai So Nhe.");
		}
		if (LuaChon1Y1 != 0){
			printf("\n Vui Long Nhan Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Nhe....");
			getchar();
			getchar();
		}
	} while (LuaChon1Y1 != 0);
}
void HienThi1Y2(){
	printf("\n +------- Phep Tinh Tru ----------+");
	printf("\n 1. Phep Tinh Tru Hai So.         +");
	printf("\n 2. Phep Tinh Tru Ba So.          +");
	printf("\n 3. Phep Tinh Tru Bon So.         +");
	printf("\n 4. Phep Tinh Tru Nhieu So.       +");
	printf("\n 0. Thoat Chuong Trinh.           +");
	printf("\n +--------------------------------+");
	printf("\n Vui Long Chon So Ban Muon: ");
}
void SuLyHienThi1Y2(){
	int LuaChon1Y2;
	do {
		system("cls");
		HienThi1Y2();
		scanf("%d",&LuaChon1Y2);
		switch(LuaChon1Y2){
			case 1: {
				printf("\n Phep Tinh Tru Hai So.");
				double a,b,Hieu;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				Hieu = a - b;
				printf("\n Ket Qua Cua %.2lf - %.2lf = %.2lf",a,b,Hieu);
				break;
			}
			case 2: {
				printf("\n Phep Tinh Tru Ba So.");
				double a,b,c,Hieu;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				printf("\n Vui Long Nhap So Thu Ba: ");
				scanf("%lf",&c);
				Hieu = a - b - c ;
				printf("\n Ket Qua Cua: %.2lf - %.2lf - %.2lf = %.2lf",a,b,c,Hieu);
				break;
			}
			case 3: {
				printf("\n Phep Tinh Tru Bon So.");
				double a,b,c,d,Hieu;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				printf("\n Vui Long Nhap So Thu Ba: ");
				scanf("%lf",&c);
				printf("\n Vui Long Nhap So Thu Tu: ");
				scanf("%lf",&d);
				Hieu = a - b - c - d;
				printf("\n Ket Qua Cua: %.2lf - %.2lf - %.2lf - %.2lf = %.2lf",a,b,c,d,Hieu);
				break;
			}
			case 4: {
				printf("\n Phep Tinh Tru Nhieu So.");
				int soluong;
				printf("\n Vui Long Nhap So Luong So Ban Muon: ");
				scanf("%d",&soluong);
				double nhanGT[soluong];
				double Hieu;
				int i;
				if (soluong <= 0){
					printf("\n So Luong So Ban Vua Nhap Be Hon Hoac Bang 0. ");
					printf("\n Vui LOng Chon Va Nhap Lai So Nhe.");
				} else {
					for (i = 0;i < soluong;i ++){
						printf("\n So Thu %d La: ",i + 1);
						scanf("%lf",&nhanGT[i]);
						Hieu -= nhanGT[i];
					}
					printf("\n Ket Qua Cua: ");
					for (i = 0;i < soluong;i ++){
						printf("%.2lf - ",nhanGT[i]);
					}
					printf("La: %.2lf",Hieu);
				}
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh Tinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default:
				printf("\n Ban Da Chon Sai So Roi!");
				printf("\n Vui Long Nhap Lai So Nhe.");
		}
		if(LuaChon1Y2 != 0){
			printf("\n Vui Long Nhap Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Nhe....");
			getchar();
			getchar();
		}
	} while (LuaChon1Y2 != 0);
}
void HienThi1Y3(){
	printf("\n +------- Phep Tinh Nhan ---------+");
	printf("\n + 1. Phep Tinh Nhan Hai So.      +");
	printf("\n + 2. Phep Tinh Nhan Ba So.       +");
	printf("\n + 3. Phep Tinh Nhan Bon So.      +");
	printf("\n + 4. Phep Tinh Nhan Nhieu So.    +");
	printf("\n + 0. Thoat Chuong Trinh Tinh.    +");
	printf("\n +--------------------------------+");
	printf("\n Vui Long Chon So Ban Muon Nhe: ");
}
void SuLyHienThi1Y3(){
	int LuaChon1Y3;
	do{
		system("cls");
		HienThi1Y3();
		scanf("%d",&LuaChon1Y3);
		switch(LuaChon1Y3){
			case 1: {
				printf("\n Phep Tinh Nhan Hai So.");
				double a,b,Nhan;
				pritnf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				Nhan = a * b;
				printf("\n Ket Qua Cua: %.2lf * %.2lf = %.2lf ",a,b,Nhan);
				break;
			}
			case 2: {
				printf("\n Phep Tinh Nhan Ba So.");
				double a,b,c,Nhan;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				printf("\n Vui Long Nhap So Thu Ba: ");
				scanf("%lf",&c);
				Nhan = a * b * c;
				printf("\n Ket Qua Cua: %.2lf * %.2lf * %.2lf = %.2lf",a,b,c,Nhan);
				break;
			}
			case 3: {
				printf("\n Phep Tinh Nhan Bon So.");
				double a,b,c,d;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				printf("\n Vui Long Nhap So Thu Ba: ");
				scanf("%lf",&c);
				printf("\n Vui Long Nhap So Thu Bon: ");
				scanf("%lf",&d);
				double Nhan = a * b * c * d;
				printf("\n Ket Qua Cua: %.2lf * %.2lf * %.2lf * %.2lf = %.2lf",a,b,c,d,Nhan);
				break;
			}
			case 4: {
				printf("\n Phep Tinh Nhan Nhieu So");
				int soluong;
				printf("\n Vui Long Nhap So Luong So Ban Muon: ");
				scanf("%d",&soluong);
				if(soluong <= 0){
					printf("\n So Luong So Ban Vua Nhap Be Hon Hoac Bang 0");
					printf("\n Vui Long Chon Va Nhap Lai Nhe.");
				} else {
					int i;
					double Tich = 1,nhanGT[soluong];
					for(i = 0;i < soluong; i ++){
						printf("\n Vui LOng Nhap So Thu %d La: ",i +1);
						scanf("%lf",&nhanGT[i]);
						Tich *= nhanGT[i];
					}
					printf("\n Ket Qua Cua %d So La: %.2lf",soluong,Tich);
				}
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh Tinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh Nhe.");
				break;
			}
			default: 
			printf("\n Ban Da Chon Sai So Roi!");
			printf("\n Vui Long Chon So Va Nhap Lai Nhe.");
		} 
		if(LuaChon1Y3 != 0){
			printf("\n Vui Long Nhap Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Nhe.....");
			getchar();
			getchar();
		}
	} while (LuaChon1Y3 != 0);
}
void HienThi1Y4(){
	printf("\n +--------- Phep Tinh Chia -----------+ ");
	printf("\n + 1. Phep Tinh Chia Hai So.          +");
	printf("\n + 2. Phep Tinh Chia Ba So.           +");
	printf("\n + 3. Phep Tinh Chia Bon So.          +");
	printf("\n + 4. Phep Tinh Chia Nhieu So.        +");
	printf("\n + 0. Thoat Chuong Trinh.             +");
	printf("\n +------------------------------------+");
	printf("\n Vui Long Chon So Ban Muon: ");
}
void SuLyHienThi1Y4(){
	int LuaChon1Y4;
	do {
		system("cls");
		HienThi1Y4();
		scanf("%d",LuaChon1Y4);
		switch(LuaChon1Y4){
			case 1: {
				printf("\n Phep Tinh Chia Hai So.");
				double a,b,Chia;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				Chia = a / b;
				printf("\n Ket Qua Cua: %.2lf / %.2lf = %.2lf ",a,b,Chia);
				break;
			}
			case 2: {
				printf("\n Phep Tinh Chia Ba So.");
				double a,b,c,Chia;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				printf("\n Vui Long Nhap So Thu Ba: ");
				scanf("%lf",&c);
				Chia = a / b /c;
				printf("\n Ket Qua Cua: %.2lf / %.2lf / %.2lf = %.2lf",a,b,c,Chia);
				break;
			}
			case 3:{
				printf("\n Phep Tinh Chia Bon So.");
				double a,b,c,d,Chia;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scnaf("%lf",&b);
				printf("\n Vui Long Nhap So Thu Ba: ");
				scanf("%lf",&c);
				printf("\n Vui Long Nhap So Thu Tu: ");
				scanf("%lf",&d);
				Chia = a / b / c / d;
				printf("\n Ket Qua Cua: %.2lf / %.2lf / %.2lf / %.2lf = %.2lf ",a,b,c,d,Chia);
				break;
			}
			case 4: {
				printf("\n Phep Tinh Chia Nhieu So.");
				int soluong;
				printf("\n Vui Long Nhap So Luong So: ");
				scanf("%d",&soluong);
				if(soluong <= 0){
					printf("\n So Luong So Ban Vua Nhap Be Hon Hoac Bang 0.");
					printf("\n Vui Long Chon Lai So Nhe.");
				} else {
					int i;
					double Chia,nhanGT[soluong];
					for (i = 0; i < soluong; i++){
						printf("\n Vui Long Nhap So Thu %d La: ",i + 1);
						scanf("%lf",nhanGT[i]);
						Chia /= nhanGT[i];
					}
					printf("\n Ket Qua Cua Phep Tinh Chia %d So La: %.2lf",soluong,Chia);
				}
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh Tinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default:
				printf("\n Ban Da Chon Sai So Roi!");
				printf("\n Vui Long Chon Lai So Nhe.");
		}
		if(LuaChon1Y4 != 0){
			printf("\n Vui Long Nhap Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Nhe......");
			getchar();
			getchar();
		}
	} while (LuaChon1Y4 != 0);
}
 int timsoNT(int a) {
    if (a <= 1) {
        return 0; // Tra Ve 0 Neu Phai Phai La So Nguyen To
    }
    int i;
    for (i = 2; i <= a / 2; i++) {
        if (a % i ==  0) {
            return 0; // Tr? v? 0 n?u kh�ng ph?i s? nguy�n t?
        }
    }
    return 1; // Tr? v? 1 n?u l� s? nguy�n t?
}

int timsoCP(int a) {
    if (a < 0) {
        return 0; // Tr? v? 0 n?u kh�ng ph?i s? ch�nh phuong
    }
    int timcanbachai = sqrt(a);
    return (timcanbachai * timcanbachai == a) ? 1 : 0; // Tr? v? 1 n?u l� s? ch�nh phuong, ngu?c l?i tr? v? 0
}

void HienThi2(){
	printf("\n +-------- Cac Phep Tinh Nang Cao ---------+");
	printf("\n + 1. Phep Tinh Xac Dinh So Nguyen.        +");
	printf("\n + 2. Phep Tinh Xac Dinh So Nguyen To.     +");
	printf("\n + 3. Phep Tinh Xac Dinh So Chinh Phuong.  +");
	printf("\n + 4. Phep Tinh Phuong Trinh Bac Nhat.     +");
	printf("\n + 5. Phep Tinh Phuong Trinh Bac Hai.      +");
	printf("\n + 6. Phep Tinh Phuong Trinh Bac Ba.       +");
	printf("\n + 7. Phep Tinh Phuong Trinh Bac Bon.      +");
	printf("\n + 8. Phep Tinh Phuong Trinh Bac Nam.      +");
	printf("\n + 9. Phep Tinh Phuong Trinh Bac Nhat 2 An.+");
	printf("\n + 10. Phep Tinh Can Bac Hai.              +");
	printf("\n + 11. Phep Tinh Can Bac Ba.               +");
	printf("\n + 12. Phep Tinh Can Bac Bon.              +");
	printf("\n + 13 Phep Tinh Gia Tri Tuyet Doi.         +");
	printf("\n +-----------------------------------------+");
	printf("\n Vui Long Chon So Ban Muon: ");
}
double GiaTri (double a,double b,double c,double d,double e,double x){
	return a * pow(x,4) + b * pow(x,3) + c * x * x + d * x + e;
}
double HamGiaTri(double x,double b, double c,double d,double e,double f){
	return a * pow(x,5) + b * pow(x, 4) + c * pow(x, 3) + d * pow(x, 2) + e * x + f;
}
void SuLyHienThi2(){
	int LuaChon2;
	do {
		system("cls");
		HienThi2();
		scanf("%d",&LuaChon2);
		switch(LuaChon2){
			case 1: {
				printf("\n Sac Dinh So Nguyen.");
				double a;
				printf("\n Vui Long Nhap So Ban Muon: ");
				scanf("%lf",&a);
				if(a == (int)a){
					printf("\n So Ban Vua Nhap La So Nguyen.");
				} else {
					printf("\n So Ban Vua Nhap Khong Phai La So Nguyen.");
				}
				break;
			}
			case 2: {
				printf("\n Phep Tinh Sac Dinh So Nguyen To.");
				int a;
				printf("\n Vui Long Nhap So Nguyen: ");
				scanf("%d",&a);
				if (timsoNT(a)){
					printf("\n La So NT");
				} else {
					printf("\n Khong Phai La So Nguyen To.");
				}
				break;
			}
			case 3: {
				printf("\n Sac Dinh So Chinh Phuong.");
				int a;
				printf("\n Vui Long Nhap So Nguyen: ");
				scanf("%d",&a);
				if(timsoCP(a)){
					printf("\n La So Chinh Phuong.");
				} else {
					printf("\n Khong Phai La So Nguyen To.");
				}
				break;
			}
			case 4: {
				printf("\n Phep Tinh Phuong Trinh Bac Nhat.");
				double a,b,x;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				if (a == 0){
					if (b == 0){
						printf("\n Phuong Trinh Co Vo So Nghiem.");
					} else {
						printf("\n Phuong Trinh Vo Nghiem.");
					}
				} else {
					x = - b / a;
					printf("\n Phuong Trinh Co Nghiem Duy Nhat.");
					printf("\n x = %.2lf",x);
				}
				break;
			}
			case 5: {
				printf("\n Phuong Trinh Bac Hai.");
				double a,b,c,x,x1,x2,x3,Delta;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				printf("\n Vui Long Nhap So Thu Ba: ");
				scanf("%lf",&c);
				printf("\n Phuong Trinh: %.2lf * x^2 + %.2lf * x + %.2lf = 0",a,b,c);
				if(a == 0){
					if (b == 0){
						if (c == 0){
							printf("\n Phuong Trinh Co Vo So Nghiem.");
						} else {
							printf("\n Phuong Trinh Vo Nghiem.");
						}
					} else {
						printf("\n Trinh Co Nghiem Duy Nhat.");
						x = - c / b;
						printf("\n x = %.2lf",x);
					}
				} else {
					Delta = b * b - 4 * a * c;
					x1 = (- b + sqrt(Delta)) / (2 * a);
					x2 = (- b - sqrt(Delta)) / (2 * a);
					if(Delta > 0){
						printf("\n Phuong Trinh Co Hai Nghiem Phan Biet.");
						printf("\n x1 = %.2lf",x1);
						printf("\n x2 = %.2lf",x2);
					} else {
						if (Delta == 0){
							printf("\n Phuong Trinh Co Nghiem Kep.");
							x3 = - b / (2 * a);
							printf("\n x1 = x2 = %.2lf",x3);
						} else {
							printf("\n Phuong Trinh Vo Nghiem.");
						}
					}
				}
				break;
			} 
			case 6: {
				printf("\n Phuong Trinh Bac Ba.");
				double a,b,c,d,x,x1,x2,x3,y1,y2,y3,Delta,Delta1;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&b);
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&c);
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&d);
				if (a == 0){
					if (b == 0){
						if (c == 0){
							if (d == 0){
								printf("\n Phuong Trinh Ban Vua Nhap Co Vo So Nghiem.");
							} else {
								printf("\n Phuong Trinh Vo Nghiem.");
							}
						} else {
							printf("\n Phuong Trinh Co Nghiem Duy Nhat.");
							x = - d / c;
							printf("\n x = %.2lf",x);
						}
					} else {
						Delta = c * c - 4 * d * b;
						x1 = (- c + sqrt(Delta)) / (b * 2);
						x2 = (- c - sqrt(Delta)) / (b * 2);
						if (Delta > 0){
							printf("\n Phuong Trinh Co Hai Nghiem Phan Biet.");
							printf("\n x1 = %.2lf \n x2 = %.2lf",x1,x2);
						} else {
							if (Delta == 0){
								printf("\n Phuong Trinh Co Nghiem Kep.");
								x3 = - c / (2 * b);
								printf("\n x1 = x2 = %.2lf",x3);
							} else {
								printf("\n Trinh Vo Nghiem.");
							}
						}
					}
				} else {
					double p = (3 * a * c - b * b) / (3 * a * a);
					double q = (2 * b * b * b - 9 * a * b * c + 27 * a * a * d) / (27 * a * a * a);
					Delta1 = (q * q) / 4 + (p * p * p) / 27;
					if (Delta1 > 0){
						printf("\n Phuong TRinh Co Mot Nghiem Thuc.");
						double u = cbrt(- q / 2 + sqrt(Delta1));
						double v = cbrt(- q / 2 - sqrt(Delta1));
						y1 = u + v;
						printf("\n x = %.2lf",y1); 
					} else {
						if (Delta1 == 0){
							printf("\n Phuong Trinh Co Ba Nghiem Thuc Trong Do Co Hai Nghiem Kep.");
							y2 = - 2 * cbrt(q / 2);
							printf("\n x1 = x2 = %.2lf",y2);
							printf("\n x3 = %.2lf", - y2 / 2);
						} else {
							double theta = acos( - q / (2 * sqrt(p * p * p / 27)));
							double r = 2 * sqrt(- p / 3);
							y3 = r * cos(theta / 3);
							double y4,y5;
							y4 = r * cos((theta + 2 * M_PI) / 3);
							y5 = r * cos((theta + 4 * M_PI) / 3);
							printf("\n Phuong Trinh Co Ba Nghiem Phan Biet.");
							printf("\n x1 = %.2lf \n x2 = %.2lf \n x3 = %.2lf",y3,y4,y5);
						}
					}
				}
				break;
			}
			case 7: {
				printf("\n Phuong Trinh Bac Bon.");
				double a,b,c,d,e;
				printf("\n Vui LongNhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long NHap So Thu Hai: ");
				scanf("%lf",&b);
				printf("\n Vui Long Nhap So Thu Ba: ");
				scanf("%lf",&c);
				printf("\n Vui LOng Nhap So Thu Tu: ");
				scanf("%lf",&d);
				printf("\n Vui Long NHap So Thu Nam: ");
				scanf("%lf",&e);
				printf("\n Phuong TRinh: %.2lf * x^4 + %.2lf * x^3 + %.2lf * x^2 + %.2lf * x + %.2lf = 0 ",a,b,c,d,e);
				if (a == 0){
					if(b == 0){
						if(c == 0){
							if(d == 0){
								if(e == 0){
									printf("\n Phuong Trinh Co Vo So Nghiem.");
								} else {
									printf("\n Phuong Trinh Vo Nghiem.");
								}
							} else {
								double x = - e / d;
								printf("\n Phuong Trinh Co Nhiem Duy Nhat.");
								printf("\n x = %.2lf",x);
							}
						} else {
							double Delta = d * d - 4 * a * c;
							double x1 = (- d + sqrt(Delta)) / (2 * c);
							double x2 = (- d - sqrt(Delta)) / (2 * c);
							if (Delta > 0){
								printf("\n Phuong Trinh Co Hai Nghiem Phan Biet.");
								printf("\n x1 = %.2lf",x1);
								printf("\n x2 = %.2lf",x2);
							} else {
								if (Dalta == 0){
									printf("\n Phuong Trinh Co Nghiem Kep.");
									double x3 = - d / (2 * c);
									printf("\n x1 = x2 = %.2lf",&x3);
								} else {
									printf("\n Phuong TRinh Vo Nghiem.");
								}
							}
						}
					} else {
					    double p = (3 * a * c - b * b) / (3 * a * a);
						double q = (2 * b * b * b - 9 * a * b * c + 27 * a * a * d) / (27 * a * a * a);
						Delta1 = (q * q) / 4 + (p * p * p) / 27;
						if (Delta1 > 0){
							printf("\n Phuong TRinh Co Mot Nghiem Thuc.");
							double u = cbrt(- q / 2 + sqrt(Delta1));
							double v = cbrt(- q / 2 - sqrt(Delta1));
							y1 = u + v;
							printf("\n x = %.2lf",y1); 
						} else {
							if (Delta1 == 0){
								printf("\n Phuong Trinh Co Ba Nghiem Thuc Trong Do Co Hai Nghiem Kep.");
								y2 = - 2 * cbrt(q / 2);
								printf("\n x1 = x2 = %.2lf",y2);
								printf("\n x3 = %.2lf", - y2 / 2);
							} else {
								double theta = acos( - q / (2 * sqrt(p * p * p / 27)));
								double r = 2 * sqrt(- p / 3);
								y3 = r * cos(theta / 3);
								double y4,y5;
								y4 = r * cos((theta + 2 * M_PI) / 3);
								y5 = r * cos((theta + 4 * M_PI) / 3);
								printf("\n Phuong Trinh Co Ba Nghiem Phan Biet.");
								printf("\n x1 = %.2lf \n x2 = %.2lf \n x3 = %.2lf",y3,y4,y5);
							}
						}
					}	
				} else {
					double Giua,GiaTri_Trai,GiaTra_Giua,Trai,Phai;
					const double SaiSo = 1e-6;
					// double GiaTri = a * x * x * x * x + b * x * x * x + c * x * x + d * x + e;
					while (Phai - Trai > SaiSo) {
						Giua = (Trai + Phai) / 2.0;
						GiaTri_Trai = GiaTri(a,b,c,d,e,Trai);
						GiaTra_Giua = GiaTri(a,b,c,d,e,Giua);
						if (GiaTri_Trai * GiaTra_Giua <= 0) {
							Phai = Giua;
						} else {
							Trai = Giua;
						}
					}
					printf("\n Nghiem Gan Dung: %.3lf", (Trai + Phai) / 2.0);
				}
				break;
			}
			case 8: {
				printf("\n Phuong Trinh Bac Nam.");
				double a,b,c,d,e,f,Trai,Phai,SaiSo;
				printf("\n Vui Long Nhap So Thu Nhat: ");
				scanf("%lf",&a);
				printf("\n Vui Long Nhap So Thu Hai: ");
				scanf("%lf",&b);
				printf("\n Vui Long Nhap So Thu Ba: ");
				scanf("%lf",&c);
				printf("\n Vui Long Nhap So Thu Tu: ");
				scanf("%lf",&d);
				printf("\n Vui Long Nhap So Thu Nam: ");
				scanf("%lf",&e);
				printf("\n Vui Long nHap So Thu Sau: ");
				scanf("%lf",&f);
				printf("\n Vui Long Nhap Khoang Tim Nghiem [Trai]: ");
				scanf("%lf",&Trai);
				printf("\n Vui Long Nhap Khoang Tim Nghiem [Phai]: ");
				scanf("%lf",&Phai);
				printf("\n Vui Long Nhap Khoang Sai So: ");
				scanf("%lf",&SaiSo);
				if(a == 0){
					if(b == 0){
						if(c == 0){
							if(d == 0){
								if(e == 0){
									if(f == 0){
										printf("\n Phuong Trinh Ban Vua Nhap Co Vo So Nghiem.");
									} else {
										printf("\n Phuong Trinh Ban Vua Nhap Vo Nghiem.");
									}
								} else {
									double x = - f / e;
									printf("\n Phuong Trinh Co Nghiem Duy Nhat.");
									printf("\n x = %.2lf",x);
								}
							} else {
								double Dalta = e * e - 4 * a * c;
								double x1 = (- e + sqrt(Delta)) / (2 * d);
								double x2 = (- e - sqrt(Delta)) / (2 * d);
								if(Delta > 0){
									printf("\n Phuong TRinh Ban Vua Nhap Co Hai Nghiem Phan Biet.");
									printf("\n x1 = %.2lf",x1);
									printf("\n x2 = %.2lf",x2);
								} else {
									if (Delta == 0){
										printf("\n Phuong Trinh Ban Vua Nhap Co Nghiem Kep.");
										double x3 = - e / (2 * d);
										printf("\n x1 = x2 = %.2lf",x3);
									} else {
										printf("\n Phuong TRinh Vo Nghiem.");
									}
								}
							}
						} else {
							double p = (3 * c * e - d * d) / (3 * c * c);
							double q = (2 * d * d * d - 9 * c * d * e + 27 * c * c * d) / (27 * c * c * c);
							double Delta1 = pow(q / 2,2) + pow(p / 3,3);
							if(Delta1 > 0){
								double u = cbrt(- q / 2 + sqrt(Delta1));
								double v = cbrt(- p / 2 + sqrt(Delta1));
								double y1 = u + v - d / (3 * c);
								printf("\n Nghiem Thuc Cua Phuong Trinh La: ");
								printf("\n x1 = %.2lf",y1);
							} else {
								if(Delta == 0){
									double  u1 = cbrt(- q / 2);
									double y2 = 2 * u1 - d / (3 * c);
									double y3 = - u1 - d / (3 * c);
									printf("\n Phuong Trinh Co Nghiem Kep Va Nghiem Don: ");
									printf("\n x1 = x2 = %.2lf",y1);
									printf("\n x3 = %.2lf",y2);
								} else {
									double r = sqrt(- pow(p / 3,3));
									double phi = acos(- q / (2 * r));
									double y4 = 2 * cbrt(r) * cos(phi / 3) - d / (3 * c);
									double y5 = 2 * cbrt(r) * cos((phi + 2 * M_PI) / 3) - d / (3 * c);
									double y6 = 2 * cbrt(r) * cos((phi + 4 * M_PI) / 3) - d / (3 * c);
									printf("\n Phuong Trinh Co Ba Nghiem Phan Biet. ");
									printf("\n x1 = %.2lf",y4);
									printf("\n x2 = %.2lf",y5);
									printf("\n x3 = %.2lf",y6);
								}
							}
						}
					} else {
						double Giua1, GiaTri_Trai1, GiaTra_Giua1, Trai1, Phai1;
						const double SaiSo1 = 1e-6;
						while(Phai1 - Trai1 > SaiSo1){
							Giua1 = (Trai1 - Phai1) / 2.0;
							GiaTri_Trai1 = GiaTri(b,c,d,e,f,Trai1);
							GiaTri_Giua1 = GiaTri(b,c,d,e,f,Giua1);
							if(GiaTri_Trai1 * GiaTri_Giua1 <= 0){
								Phai1 = Giua1;
							} else {
								Trai1 = Giua1;
							}
						}
						printf("\n Nghiem Gan Dung: %.3lf",(Trai1 + Phai) / 2.0);
					}
				} else {
					if (HamGiaTri(Trai,a,b,c,d,e,f) * HamGiaTri(Phai,a,b,c,d,e,f) >= 0) {
						printf("Khoa:#ng [%.2f, %.2f] khC4ng cha;)a nghia;m hoa:7c cC3 nhia;u nghia;m.\n", Trai, Phai);
						return;
					} else {
						double Giua,GiaTri_Trai,GiaTra_Giua;
						while ((Phai - Trai) >= SaiSo) {
							Giua = (Phai + Trai ) / 2.0;
							GiaTri_Trai = HamGiaTri(Trai,a,b,c,d,e,f);
							GiaTra_Giua = HamGiaTri(Giua,a,b,c,d,e,f);
							if (GiaTra_Giua == 0.0) {
								break;
							} else if (GiaTri_Trai * GiaTra_Giua < 0) {
								Phai = Giua;
							} else {
								Trai = Giua;
							}
					printf("\n Nghien Gan Dung Trong Khoang: %.6lf",(Trai + Phai) / 2.0);
						}
					}
				}
				break;
			}
			case 9: {
				printf("\n Phuong Trinh Bac Nhat Hai An.");
				double a,b,c,x,y;
				printf("\n Vui Long Nhap So A = ");
				scanf("%lf",&a);
				printf("\n Vui Long NHap So B = ");
				scanf("%lf",&b);
				printf("\n Vui Long Nhap So C = ");
				scanf("%lf",&c);
				it (a == 0 && b == 0){
					printf("\n Phuong Trinh Vo Nghiem.");
//				    break;
				} else if (b == 0){
					printf("\n Phuong Trinh Co Vo So Nghiem: x = %.2lf Va y Thuoc R",c / a);
				} else {
					printf("\n Phuong Trinh Co Vo So Nghiem: x = %.2lf - %.2lfx",c / b,a / b);
				}
				break;
			}
			case 10: {
				printf("\n Phep Tinh Can Bac Hai.");
				double a;
				printf("\n Vui Long Nhap So Ban Muon: ");
				scanf("%lf",&a);
				if (a <= 0){
					printf("\n So Ban Vua Nhap Be Hon Hoac Bang 0!");
					printf("\n Vui Long Chon Va Nhap Lai So Nhe.");
					break;
				} else {
					printf("\n Ket Qua Can Bac Hai Cua %.2lf La: %.2lf ",a,sqrt(a));
				}
				break;
			}
			case 11: {
				printf("\n Phep Tinh Can Bac Ba");
				double a;
				printf("\n Vui LOng Nhap So Ban Muon: ");
				scanf("%lf",&a);
				if(a <= 0){
					printf("\n So Ban Vua Nhap Be Hon Hoac bang 0.");
					printf("\n Vui Long Chon So Nhap Lai Nhe.");
					break;
				} else {
					printf("\n Ket Qua Can bac Ba Cua %.2lf La: %.2lf",a,cbrt(a));
				}
				break;
			} 
			case 12: {
				printf("\n Phep Tinh Can Bac Bon.");
				double a;
				printf("\n Vui Long Nhap So Ban Muon: ");
				scanf("%lf",&a);
				if (a <= 0){
					printf("\n So Ban Vua Nhap Be Hon Bang 0.");
					printf("\n Vui Long Chon So Nhap Lai Nhe.");
					break;
				} else {
					printf("\n Ket Qua Can Bac Bon Cua %.2lf La: %.2lf",a,sqrt(sqrt(a)));
				}
				break;
			}
			case 13: {
				printf("\n Phep Tinh Gia Tri Tuyet Doi.");
				double a;
				printf("\n Vui LOng Nhap So Ban Muon: ");
				scanf("%lf",&a);
				if (a >= 0){
					printf("\n So Ban Vua Nhap Da La So Duong Roi!");
					break;
				} else {
					printf("\n Ket Qua Cua %.2lf La: %.2lf",a,fabs(a));
				}
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default:
				printf("\n Ban Da Nhap Sai So Roi!");
				printf("\n Vui Long Nhap Lai Nhe.");
		}
		if (LuaChon2 != 0){
			printf("\n Vui Long Nhap Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Nhe......");
			getchar();
			getchar();
		}
	} while (LuaChon2 != 0);
}
void HienThi1(){
	printf("\n +------- Cac Phep Tinh Co Ban ---------+");
	printf("\n + 1. Phep Tinh Cong.                   +");
	printf("\n + 2. Phep Tinh Tru.                    +");
	printf("\n + 3. Phpe Tinh Nhan.                   +");
	printf("\n + 4. Phep Tinh Chia.                   +");
	printf("\n + 0. Thoat Chuong Trinh Tinh.          +");
	printf("\n +--------------------------------------+");
	printf("\n Vui Long Nhap Lua Chon Cua Ban: ");
}
void SuLyHienThi1(){
	int LuaChon1;
	do {
		system("cls");
		HienThi1();
		scanf("%d",&LuaChon1);
		switch(LuaChon1){
			case 1: {
				SulyHienThi1Y1();
				break;
			}
			case 2: {
				SuLyHienThi1Y2();
				break;
			}
			case 3: {
				SuLyHienThi1Y3();
				break;
			}
			case 4: {
				SuLyHienThi1Y4();
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh Tinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default:
				printf("\n Ban Da Chon Sai So Roi!");
				printf("\n Vui Long Chon Lai So Nhe.");
		}
		if (LuaChon1 != 0){
			printf("\n Vui Long Nhan Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Tinh Nhe.....");
			getchar();
			getchar();
		}
	} while (LuaChon1 != 0);
}
SuLyHienThi3(){
	char HoTen[50];
	int Tuoi;
	char DiaChi[50];
	int sdt;
	char TenThanhPho[20];
	char TenQuocGia[20];
	getchar();
	printf("\n +------- Nhap Thong Tin Ca Nhan --------+");
	printf("\n Vui Long Nhap Ho Ten Cua Ban: ");
	fgets(HoTen,sizeof(HoTen),stdin);
	HoTen[strcspn(HoTen), "\n"] = 0;
	printf("\n Vui Long NHap Tuoi Cua Ban: ");
	scanf("%d",&Tuoi);
	getchar();
	printf("\n Vui Long NHap Dia Chi Cua Ban: ");
	fgets(DiaChi,sizeof(DiaChi), stdin);
	DiaChi[strcpsn(DiaChi), "\ "] = 0;
	printf("\n Vui Long Nhap So Dien Thoai Cua Ban: ");
	scanf("%d",&sdt);
	getchar();
	printf("\n Vui Long Nhap Ten Thanh Pho Cua Ban: ");
	fgets(TenThanhPho,sizeof(TenThanhPho),stdin);
	TenThanhPho[strcspn(TenThanhPho), "\n"] = 0;
	printf("\n Vui Long Nhap Ten Quoc Gia Cua Ban: ");
	fgets(TenQuocGia,sizeof(TenQuocGia),stdin);
	TenQuocGia[strcspn(TenQuocGia),"\n"] = 0;
	printf("\n");
	printf("\n +----- Hien Thi Thong Tin Ca Nhan ------+");
	printf("\n Ten: %s",Ten);
	printf("\n Tuoi: %d",Tuoi);
	printf("\n So Dien Thoai: %d",sdt);
	printf("\n Dia Chi: %s",DiaChi);
	printf("\n Ten Thanh Pho: %s",TenThanhPho);
	printf("\n Ten Quoc Gia: %s",TenQuocGia);
	printf("\n +----- Het Roi -----+");
}
void SuLyHienThi4(){
	int soluong;
	printf("\n Vui Long Nhap So Luong Sinh Vien: ");
	scanf("%d",&soluong);
	if(soluong <= 0){
		printf("\n So Luong Sinh Vien Ban Vua Nhap Be Hon Hoac Bang 0.");
		printf("\n Vui Long Chon Va Nhap Lai So Nhe.");
//		break;
	} else {
		int i;
		int masv[soluong];
		char Ten[soluong][20];
		double Diem[soluong];
		for(i = 0; i < soluong; i ++){
			printf("\n Vui Long Nhap Ma So Sinh Vien Thu %d La: ",i + 1);
			scanf("%d",&masv[i]);
			getchar();
			printf("\n Vui Long Nhap Ten Sinh Vien: ");
			fgets(Ten[i],sizeof(Ten[i]),stdin);
			Ten[i][strcspn(Ten[i]),"\n"] = 0;
			printf("\n Vui Long Nhap Diem: ");
			scanf("%lf",&Diem[i]);
		}
		
		printf("\n");
		int chon;
		do {
			system("cls");
			printf("\n +---- Vui Long Chon -----+");
			printf("\n 1. Hien Thi Thong Tin.");
			printf("\n 2. Tim Sinh Vien Co Diem Lon Nhat.");
			printf("\n 3. Tim Sinh Vien Co Diem Thap Nhat.");
			printf("\n 4. Tinh Diem Trung Binh Sinh Vien.");
			printf("\n 5. Hien Thi Sinh Vien Tu Diem 8 Tro Xuong.");
			printf("\n 0. Thoat.");
			printf("\n +------------------------------+");
			printf("\n Nhap So: ");	
			scanf("%d",&Chon);
			switch(Chon){
				case 1: {
					printf("\n Hien Thi Thong Tin Sinh Vien.");
					printf("\n");
//			printf("\n +---- Hien Thi Thong Tin Sinh Vien ----+");
					for(i = 0;i < soluong; i ++){
						printf("\n Ma Sinh Vien Thu %d La: %d",(i + 1),masv[i]);
						printf("\n Ten Sinh Vien: %s",Ten[i]);
						printf("\n Diem Sinh Vien: %.2lf",Diem[i]);
					}
					printf("\n +---- Het Roi ----+");
					break;
				}
				case 2: {
					printf("\n Tim Sinh Vien Co Diem Cao Nhat.");
					double DiemMax = Diem[0];
					int ViTriMax = 0;
					for(i = 0;i < soluong;i ++){
						if(Diem[i] > DiemMax){
							DiemMax = Diem[i];
							ViTriMax = i;
						}
					}
					printf("\n Ma So Sinh Vien: %d",masv[ViTriMax]);
					printf("\n Ten Sinh Vien: %s",Ten[ViTriMax]);
					printf("\n Diem: %.2lf",DiemMax);
					break;
				}
				case 3: {
					printf("\n Tim Sinh Vien Co Diem Thap Nhat.");
					double DiemMin = Diem[0];
					int ViTriMin = 0;
					for(i = 0; i < soluong;i ++){
						if(Diem[i] < DiemMin){
							DiemMin = Diem[i];
							ViTriMin = i;
						}
					}
					printf("\n Ma So Sinh Vien: %d",masv[ViTriMin]);
					printf("\n Ten Sinh Vien: %s",Ten[ViTriMin]);
					printf("\n Diem: %.2lf",DiemMin);
					break;
				}
				case 4: {
					printf("\n Sap Xep Thong Tin Sinh Vien Co Diem Tu 8 Tro Xuong.");
					double MocDiem;
					int MocMasv;
					char MocTen[50];
					int j;
					for (i = 0;i < soluong; i ++){
						for(j = 0;j < soluong;j ++){
							if(Diem[i] <= 8){
								strcpy(Moc,Diem[i]);
								strcpy(Diem[i],Diem[j]);
								strcpy(Diem[j],Moc);
								
								strcpy(MocMasv,masv[i]);
								strcpy(masv[i],mas[j]);
								strcpy(masc[j],MocMasv);
								
								strcpy(MocTen,Ten[i]);
								strcpy(Ten[i],Ten[j]);
								strcpy(Ten[j],MocTen);
							}
						}
					}
					break;
				}
				case 0: {
					printf("\n Thoat Chuong Trinh Thong Tin Sinh Vien.");
					printf("\n Cam On Ban Da Su Dung.");
					break;
				}
				default:
					printf("\n Ban Da Nhap Sai So Roi!");
					printf("\n Vui Long Chon Lai So Nhe:) ");
			}
			if(Chon != 0){
				printf("\n Vui Long Nhap Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Nhe........");
				getchar();
				getchar();
			}
		} while (Chon != 0);
	}
}
void SuLyHienThi(){
	int LuaChon;
	do {
		system("cls");
		HienThi();
		scanf("%d",&LuaChon);
		switch(LuaChon){
			case 1: {
				SuLyHienThi1();
				break;
			}
			case 2: {
				SuLyHienThi2();
				break;
			}
			case 3: {
				SuLyHienThi3();
				break;
			}
			case 4: {
				SuLyHienThi4();
				break;
			}
			case 5: {
				SuLyHienThi5();
				break;
			}
			case 6: {
				printf("\n 1.");
				break;
			}
			case 7: {
				printf("\n 1.");
				break;
			}
			case 8: {
				printf("\n 1.");
				break;
			}
//			case 9: {
//				printf("\n 1.");
//				break;
//			}
//			case 10: {
//				printf("\n 1.");
//				break;
//			}
			case 0: {
				printf("\n Thoat Chuong Trinh!");
				printf("\n Cam On Ban Da Su Dung Chuong Trinh.");
				break;
			}
			default:
				printf("\n Ban Da Chon Sai So Roi!");
				printf("\n Vui Long Chon Lai So Nhe.");
		}
		if (LuaChon != 0){
			printf("\n Vui Long Nhan Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Nhe......");
			getchar();
			getchar();
		}
	} while (LuaChon != 0);
}
int main(){
	char MatKhau[] = "TG00418";
	char NhapMK[20];
	printf("\n Vui Long Nhap Mat Khau De Chay Chuong Trinh: ");
	while(1){
		fgets(NhapMK,sizeof(NhapMK),stdin);
		NhapMK[strcspn(NhapMK,"\n")] = 0;
		if (strstr(NhapMK,MatKhau)){
			printf("\n Ban Da Mo Duoc Khoa Roi Le!");
			SuLyHienThi();
			break;
		} else {
			printf("\n Ban Da Nhap Sai Khoa Roi! Vui Long Nhap Lai Khoa Nhe: ");
		}
	}
}
