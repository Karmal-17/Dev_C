#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void HienThiMenu(){
	printf("\n =========== Menu ===========");
	printf("\n + 1.Thong Tin Gia Dinh.    +");
	printf("\n + 2.Thong Tin Sinh Vien.   +");
	printf("\n + 0.Thoat Chuong Trinh.    +");
	printf("\n ============================");
	printf("\n Nhap So Ban Chon: ");
}
void SuLyHienThi1(){
	int SoLuongThanhVien;
	printf("\n Nhap So Luong Thanh Vien Trong Gia Dinh: ");
	scanf("%d",&SoLuongThanhVien);
	char Ten[SoLuongThanhVien][100];
	int Tuoi[SoLuongThanhVien];
	int i;
	if (SoLuongThanhVien <= 0){
		printf("\n Thanh Vien Trong Gia Dinh Khong The Be Hon Hoac Bang 0.");
	} else {
		getchar();
		for (i = 0;i < SoLuongThanhVien; i++){
			printf("\n Nhap Ten Thanh Vien Thu %d La: ",i+1);
			gets(Ten[i]);
			printf("\n Nhap So Tuoi Cua Thanh Vien Thu %d La: ",i+1);
			scanf("%d",&Tuoi[i]);
			getchar();
		}
		printf("\n Thong Tin Thanh Vien Trong Gia Dinh Co %d Nguoi La: ",SoLuongThanhVien);
		for (i = 0;i < SoLuongThanhVien;i++){
			printf("\n Ten Thanh Vien %d La: %s ",i+1,Ten[i]);
			printf("\n Tuoi Thanh Vien %d La: %d",i+1,Tuoi[i]);
			printf("\n ");
		}
	}	
}

void HienThi2(){
	printf("\n ======== Menu Sinh Vien ========");
	printf("\n + 1. Thong Tin Sinh Vien.      +");
	printf("\n + 2. Xep Hang Diem So.         +");
	printf("\n + 3. Xep Hang Can Nang.        +");
	printf("\n + 0. Thoat ChuongTrinh.        +");
	printf("\n ================================");
	printf("\n Moi Ban Chon So: ");
}

void SuLyHienThi2(){
	int LuaChon2;
	do {
		system("cls");
		HienThi2();
		scanf("%d",&LuaChon2);
		switch (LuaChon2){
			case 1: {
				printf("\n Hien Thi Thong Tin Sinh Vien.");
				int SoLuongSinhVien;
				printf("\n Vui Long Nhap So Luong Sinh Vien: ");
				scanf("%d",&SoLuongSinhVien);
				char Ten[SoLuongSinhVien][100];
				char Lop[SoLuongSinhVien][100];
				int Tuoi[SoLuongSinhVien];
				int i;
				if(SoLuongSinhVien <= 0){
					printf("\n So Luong Sinh Vien Ban Vua Nhap Be Hon Hoac Bang 0");
					printf("\n Vui Long Chon So Va Nhap Lai.");
				} else {
					getchar();
					for(i = 0 ; i < SoLuongSinhVien;i++){
						printf("\n Nhap Ten Sinh Vien %d La: ",i);
						gets(Ten[i]);
						printf("\n Nhap Lop Cua Sinh Vien %d La: ",i);
						gets(Lop[i]);
						printf("\n Nhap Tuoi Cua Sinh Vien %d La: ",i);
						scanf("%d",&Tuoi[i]);
					}
					printf("\n Thong Tin Ve %d Sinh Vien Ban Vua Nhap La: ",i);
					for ( i = 1; i < SoLuongSinhVien;i++){
						printf("\n Ten Sinh Vien Thu %d La: %s",i,Ten[i]);
						printf("\n Lop Cua Sinh Vien Thu %d La: %s",i,Lop[i]);
						printf("\n Tuoi Cua Sinh Vien Thu %d La: %d",i,Tuoi[i]);
					}
				}
				
				break;
			}
			case 2: {
				printf("\n Hien Thi Xep Hang Diem Cua Sinh Vien.");
				int SoLuongSinhVien;
				printf("\n Moi Ban Nhap So Luong Sinh Vien: ");
				scanf("%d",&SoLuongSinhVien);
				getchar();
				char Ten[SoLuongSinhVien][100];
				int Diem[SoLuongSinhVien];
				if (SoLuongSinhVien <= 0){
					printf("\n So LuongSinh Vien Ban Vua Nhap Be Hon Hoac Bang 0!");
					printf("\n Vui Long Chon So Va Nhap Lai Nhe.");
				} else {
					int i;
					for (i = 1; i < SoLuongSinhVien;i++){
						printf("\n Nhap Ten Cua Sinh Vien Thu %d La: ",i);
						gets(Ten[i]);
						printf("\n Nhap Diem Cua Sinh Vien Thu %d La: ",i);
						scanf("%d",&Diem[i]);
						getchar();
					}
					int j;
					for (i = 1;i < SoLuongSinhVien;i ++){
						for (j = 1;j < SoLuongSinhVien;j ++){
							if (Diem[i] < Diem[j]){
								int TimDiem = Diem[i];
								Diem[i] = Diem[j];
								Diem[j] = TimDiem;
								
								char TimTen[100];
								strcpy(TimTen,Ten[i]);
								strcpy(Ten[i],Ten[j]);
								strcpy(Ten[j],TimTen);
							}
						}
					}
				    printf("\n Thong Tin Ve Xep Hang Diem Cua %d Sinh Vien.",SoLuongSinhVien);
				    for (i = 1;i < SoLuongSinhVien;i++){
				    	printf("\n Ten Sinh Vien Thu %d La: %s",i,Ten[i]);
				    	printf("\n Diem Cua Sinh Vien %s La: %d",Ten[i],Diem[i]);
					}
				}
				break;
			}
			case 3: {
				printf("\n Xep Hang Can Nang Cua Sinh Vien.");
				int SoLuongSinhVien;
				printf("\n Nhap So Luong Sinh Vien: ");
				scanf("%d",&SoLuongSinhVien);
				getchar();
				char Ten[SoLuongSinhVien][100];
				int CanNang[SoLuongSinhVien];
				int i,j;
				if (SoLuongSinhVien <= 0){
					printf("\n So Luong Sinh Vien Ban Vua Nhap Be Hon Hoac Bang 0.");
					printf("\n Vui Long Chon Vao Nhap Lai Nhe.");
				} else {
					for(i = 1; i < SoLuongSinhVien;i++){
						printf("\n Nhap Ten Sinh Vien Thu %d La: ",i);
						gets(Ten[i]);
						printf("\n Nhap Can Nang Cua Sinh Vien Thu %d La: ",i);
						scanf("%d",CanNang[i]);
					}
					for (i = 1; i < SoLuongSinhVien;i++){
						for(j = 1;i < SoLuongSinhVien;i ++){
							int TimCan = CanNang[i];
							CanNang[i] = CanNang[j];
							CanNang[j] = TimCan;
							
							char TimTen[100];
							strcpy(TimTen,Ten[i]);
							strcpy(Ten[i],Ten[j]);
							strcpy(Ten[j],TimTen);
							
						}
					}
					printf("\n Thong Tin Can Nang Cua %d Sinh Vien.",SoLuongSinhVien);
					for(i = 1;i <SoLuongSinhVien;i++){
						printf("\n Ten Sinh Vien Thu %d La: %s",i,Ten[i]);
						printf("\n Can Nang Sinh Vien Thu %d La: %d",i,CanNang[i]);
					}
				}
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default:
				printf("\n Lua Chon Sai So Rui!");
				printf("\n Vui Long Chon Lai So Nhe.");
		} 
		if (LuaChon2 != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe......");
			getchar();
			getchar();
		}
	} while (LuaChon2 != 0);
}
int main (){
	int LuaChon;
	do {
		system("cls");
		HienThiMenu();
		scanf("%d",&LuaChon);
		switch(LuaChon){
			case 1: {
				SuLyHienThi1();
				break;
			}
			case 2: {
				SuLyHienThi2();
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung.");
				break;
			}
			default:
				printf("\n Ban Da Lua Chon Sai So Rui!");
				printf("\n Vui Long Chon Lai So Nhe.");
		}
		if (LuaChon != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe.......");
			getchar();
			getchar();
		}
	} while(LuaChon != 0);
}
