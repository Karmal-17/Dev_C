#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// H�m ch�nh cho game FPOLY-LOTT
void gameFPOLY_LOTT() {
    int soNguoiChon[2], soHeThong[2];
    int i,j,trungKhop = 0;

    // Nh?p s? t? ngu?i choi
    printf("Nhap 2 so (tu 1 den 15):\n");
    for ( i = 0; i < 2; i++) {
        printf("So thu %d: ", i + 1);
        scanf("%d", &soNguoiChon[i]);

        // Ki?m tra s? nh?p v�o h?p l?
        if (soNguoiChon[i] < 1 || soNguoiChon[i] > 15) {
            printf("So khong hop le! Vui long nhap lai.\n");
            i--;
        }
    }

    // Sinh 2 s? ng?u nhi�n t? 1 d?n 15
    srand(time(NULL));
    for ( i = 0; i < 2; i++) {
        soHeThong[i] = rand() % 15 + 1;
    }

    // Hi?n th? s? c?a h? th?ng
    printf("\nHe thong da chon 2 so: %d va %d\n", soHeThong[0], soHeThong[1]);

    // Ki?m tra s? tr�ng kh?p
    for ( i = 0; i < 2; i++) {
        for ( j = 0; j < 2; j++) {
            if (soNguoiChon[i] == soHeThong[j]) {
                trungKhop++;
                soHeThong[j] = -1; // ��nh d?u d� tr�ng d? tr�nh d?m l?i
                break;
            }
        }
    }

    // Hi?n th? k?t qu?
    if (trungKhop == 0) {
        printf("\nChuc ban may man lan sau!\n");
    } else if (trungKhop == 1) {
        printf("\nChuc mung ban da trung giai nhi!\n");
    } else if (trungKhop == 2) {
        printf("\nChuc mung ban da trung giai nhat!\n");
    }
}

int main() {
    // Ch?y game FPOLY-LOTT
    gameFPOLY_LOTT();
    return 0;
}

