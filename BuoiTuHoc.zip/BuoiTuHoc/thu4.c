#include <stdio.h>
#include <string.h>

int main() {
    printf("\n Thong Tin Lop Hoc.");
    int SoLuongLop;

    printf("\n Vui Long Nhap So Luong Lop Hoc: ");
    scanf("%d", &SoLuongLop);
    getchar();  // Clear the newline character from the input buffer

    if (SoLuongLop <= 0) {
        printf("\n So Luong Lop Ban Vua Nhap Be Hon Hoac Bang 0.");
        printf("\n Vui Long Chon Va Nhap Lai!");
        return 0;
    }

    char Ten[SoLuongLop][100];
    int SoLuongSinhVien[SoLuongLop];
    int i;

    // Input class names and student counts
    for (i = 0; i < SoLuongLop; i++) {
        printf("\n Nhap Ten Lop Thu %d: ", i + 1);
        fgets(Ten[i], sizeof(Ten[i]), stdin);
        Ten[i][strcspn(Ten[i], "\n")] = '\0';  // Remove trailing newline

        printf(" So Luong Sinh Vien Cua Lop %s: ", Ten[i]);
        scanf("%d", &SoLuongSinhVien[i]);
        getchar();  // Clear the newline character
    }

    // Find the class with the minimum number of students
    int Min = SoLuongSinhVien[0];
    int ViTri = 0;
    for (i = 1; i < SoLuongLop; i++) {
        if (SoLuongSinhVien[i] < Min) {
            Min = SoLuongSinhVien[i];
            ViTri = i;
        }
    }

    // Display all class information
    printf("\n +-------------- Danh Sach Lop Hoc --------------+");
    for (i = 0; i < SoLuongLop; i++) {
        printf("\n Ten Lop Thu %d: %s (SoLuongSV: %d)", i + 1, Ten[i], SoLuongSinhVien[i]);
    }

    // Display the class with the minimum number of students
    printf("\n\n Lop Co So Luong Sinh Vien Thap Nhat: %s (SoLuongSV: %d)\n", Ten[ViTri], Min);

    // Display classes with fewer than 30 students
    printf("\n +---------- Lop Co So Luong Sinh Vien < 30 ----------+");
    int Dem = 0;
    for (i = 0; i < SoLuongLop; i++) {
        if (SoLuongSinhVien[i] < 30) {
            printf("\n Ten Lop Thu %d: %s (SoLuongSV: %d)", i + 1, Ten[i], SoLuongSinhVien[i]);
            printf("\n SoLuong Sinh Vien: %d",SoLuongSinhVien[i]);
            Dem = 1;
        }
    }

    if (Dem == 0) {
        printf("\n Khong Co Lop Nao Co So Luong Sinh Vien Be Hon 30.");
    }

    return 0;
}

