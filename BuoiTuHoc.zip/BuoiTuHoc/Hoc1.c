#include <stdio.h>
#include <stdlib.h>

int main() {
    // Cap Phat Bo Nho Dung Cho Mang 5 Phan Tu
    int i,*arr = (int *)malloc(5 * sizeof(int));
    if (arr == NULL) {
        printf("Kh�ng th? c?p ph�t b? nh?.\n");
        return 1;
    }

    // Khoi Tao Mang
    for ( i = 0; i < 5; i++) {
        arr[i] = i + 1;
    }

    // Hien Thi Mang
    printf("M?ng ban d?u: ");
    for ( i = 0; i < 5; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    // Thay Doi Kich Thuoc Cua Mang Len 10 Phan Tu
    arr = (int *)realloc(arr, 10 * sizeof(int));
    if (arr == NULL) {
        printf("Kh�ng th? thay d?i k�ch thu?c b? nh?.\n");
        return 1;
    }

    // Khoi Tao Cac Phan Tu Moi
    for (i = 5; i < 10; i++) {
        arr[i] = i + 1;
    }

    // Hien Thi Mang Sau Khi Thay Doi Kich Thuoc
    printf("M?ng sau khi thay d?i k�ch thu?c: ");
    for ( i = 0; i < 10; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    // Giai Phong Bo Nho
    free(arr);

    return 0;
}

