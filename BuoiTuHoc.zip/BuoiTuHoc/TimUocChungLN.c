#include <stdio.h>

// H�m t�nh UCLN b?ng thu?t to�n Euclid
int UCLN(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int main() {
    int a, b;
    printf("Nhap hai so nguyen duong:\n");
    printf("Nhap so thu nhat: ");
    scanf("%d", &a);
    printf("Nhap so thu hai: ");
    scanf("%d", &b);

    if (a <= 0 || b <= 0) {
        printf("Vui long nhap hai so nguyen duong!\n");
    } else {
        int uocChungLonNhat = UCLN(a, b);
        printf("Uoc chung lon nhat cua %d va %d la: %d\n", a, b, uocChungLonNhat);
    }

    return 0;
}

