#include <stdio.h>

// H�m t�m u?c chung c?a hai s?
void TimUocChung(int a, int b) {
    printf("Cac uoc chung cua %d va %d la: ", a, b);
    int min = (a < b) ? a : b; // Ch? c?n ki?m tra d?n s? nh? hon
    int i;
    for (i = 1; i <= min; i++) {
        if (a % i == 0 && b % i == 0) { // �i?u ki?n d? i l� u?c chung
            printf("%d ", i);
        }
    }
    printf("\n");
}

int main() {
    int a, b;
    printf("Nhap hai so nguyen duong:\n");
    printf("Nhap so thu nhat: ");
    scanf("%d", &a);
    printf("Nhap so thu hai: ");
    scanf("%d", &b);

    if (a <= 0 || b <= 0) {
        printf("Vui long nhap hai so nguyen duong!\n");
    } else {
        TimUocChung(a, b);
    }
    return 0;
}

