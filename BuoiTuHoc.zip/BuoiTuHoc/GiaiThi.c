#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to clear the console
void ClearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

// Function to display the menu
void HienThiMenu() {
    printf("\n +------------------ Menu -----------------+");
    printf("\n + 1. Nhap Thong Tin Ca Nhan.              +");
    printf("\n + 2. Tinh Tong.                           +");
    printf("\n + 3. Thong Tin Sinh Vien Cac Lop.         +");
    printf("\n + 0. Thoat Chuong Trinh.                  +");
    printf("\n +-----------------------------------------+");
    printf("\n Moi Ban Chon So: ");
}

// Function to handle personal information input and output
void HienThi1() {
    printf("\n Thong Tin Ca Nhan.");
    char Ten[100], DiaChi[100], ChuyenNganh[100];
    int Tuoi, HocKy;

    printf("\n Nhap Ho Va Ten Cua Ban: ");
    fgets(Ten, sizeof(Ten), stdin);
    Ten[strcspn(Ten, "\n")] = '\0';  // Remove trailing newline

    printf("\n Tuoi Cua Ban: ");
    scanf("%d", &Tuoi);
    getchar();  // Clear the newline character

    printf("\n Nhap Dia Chi Cua Ban: ");
    fgets(DiaChi, sizeof(DiaChi), stdin);
    DiaChi[strcspn(DiaChi, "\n")] = '\0';

    printf("\n Hoc Ky Cua Ban: ");
    scanf("%d", &HocKy);
    getchar();

    printf("\n Nhap Chuyen Nganh Cua Ban: ");
    fgets(ChuyenNganh, sizeof(ChuyenNganh), stdin);
    ChuyenNganh[strcspn(ChuyenNganh, "\n")] = '\0';

    printf("\n Hien Thi Thong Tin Ca Nhan.");
    printf("\n Ho Va Ten: %s", Ten);
    printf("\n Tuoi: %d", Tuoi);
    printf("\n Dia Chi: %s", DiaChi);
    printf("\n Hoc Ky: %d", HocKy);
    printf("\n Chuyen Nganh: %s", ChuyenNganh);
}

// Function to calculate the sum of numbers from 1 to n
void HienThi2() {
    printf("\n Trang Tinh Tong.");
    int n, Tong = 0;

    printf("\n Vui Long Nhap So Nguyen n: ");
    scanf("%d", &n);
int i;
    for ( i = 1; i <= n; i++) {
        Tong += i;
    }

    printf("\n Tong Cac So Tu 1 Den %d La: %d", n, Tong);
}

// Function to manage and display class information
void HienThi3() {
    printf("\n +-------------- Thong Tin Lop Hoc --------------+");
    int SoLuong;

    printf("\n Vui Long Nhap So Luong Lop Hoc: ");
    scanf("%d", &SoLuong);
    getchar();  // Clear newline character

    if (SoLuong <= 0) {
        printf("\n So Luong Lop Hoc Khong Duoc Be Hon Hoac Bang 0");
        return;
    }

    char Ten[SoLuong][100];
    int SoLuongSV[SoLuong];
int i;
    for ( i = 0; i < SoLuong; i++) {
        printf("\n Nhap Ten Lop Thu %d: ", i + 1);
        fgets(Ten[i], sizeof(Ten[i]), stdin);
        Ten[i][strcspn(Ten[i], "\n")] = '\0';  // Remove trailing newline

        printf("\n So Luong Thanh Vien Cua Lop %s: ", Ten[i]);
        scanf("%d", &SoLuongSV[i]);
        getchar();
    }

    // Finding the class with the minimum students
    int Min = SoLuongSV[0], ViTri = 0;
    for ( i = 1; i < SoLuong; i++) {
        if (SoLuongSV[i] < Min) {
            Min = SoLuongSV[i];
            ViTri = i;
        }
    }

    printf("\n +------------------ Xuat Thong Tin Lop Hoc ----------------------+");
    printf("\n So Luong Lop Hoc: %d", SoLuong);

    for ( i = 0; i < SoLuong; i++) {
        printf("\n Ten Lop Thu %d: %s", i + 1, Ten[i]);
        printf("\n So Luong Sinh Vien Cua Lop %s: %d", Ten[i], SoLuongSV[i]);
    }

    printf("\n Lop Co So Luong Sinh Vien It Nhat La: %s (So Luong: %d)", Ten[ViTri], Min);

    // Display classes with <= 30 students
    printf("\n\n Lop Co So Luong Sinh Vien Be Hon Hoac Bang 30:");
    int Found = 0;
    for ( i = 0; i < SoLuong; i++) {
        if (SoLuongSV[i] <= 30) {
            printf("\n - Ten Lop: %s (So Luong: %d)", Ten[i], SoLuongSV[i]);
            Found = 1;
        }
    }

    if (!Found) {
        printf("\n Khong Co Lop Nao Co So Luong Sinh Vien Be Hon Hoac Bang 30.");
    }
}

// Main function
int main() {
    int LuaChon;

    do {
        ClearScreen();
        HienThiMenu();
        scanf("%d", &LuaChon);
        getchar();  // Clear newline character

        switch (LuaChon) {
            case 1:
                HienThi1();
                break;
            case 2:
                HienThi2();
                break;
            case 3:
                HienThi3();
                break;
            case 0:
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Su Dung Chuong Trinh.");
                break;
            default:
                printf("\n Lua Chon Khong Hop Le. Vui Long Thu Lai.");
        }

        if (LuaChon != 0) {
            printf("\n\n Nhan Enter De Tiep Tuc...");
            getchar();
        }
    } while (LuaChon != 0);

    return 0;
}

