#include <stdio.h>
#include <stdlib.h>

void HienThi6() {
    printf("\n ======== Tinh Lai =========");
    printf("\n + 1. Tinh Lai Ngan Hang.   +");
    printf("\n + 0. Thoat Chuong Trinh.   +");
    printf("\n ===========================");
}

void SuLyHienThi6() {
    int LuaChon6;
    do {
        system("cls");
        HienThi6();
        printf("\n Vui Long Chon So: ");
        scanf("%d", &LuaChon6);
        switch (LuaChon6) {
            case 1: {
                printf("\n Tinh Lai Xuat Ngan Hang.");
                int TienVay, KyHan = 12;
                float LaiXuat = 0.05;
                printf("\n Nhap So Tien Vay (VND): ");
                scanf("%d", &TienVay);
                int SoTienGocPhaiTra = TienVay / KyHan;
                int SoDu = TienVay; 
                printf("\n Ky Han \t Tien Lai Phai Tra \t Tien Goc Phai Tra \t Tong Tien Phai Tra \t So Du Con Lai\n");
                int i;
                for (i = 1; i <= KyHan; i++) {
                    int TienLaiPhaiTra = (int)(SoDu * LaiXuat);  
                    int TongTienPhaiTra = SoTienGocPhaiTra + TienLaiPhaiTra; 
                    SoDu -= SoTienGocPhaiTra; 

                    printf("%6d \t %18d \t %17d \t %20d \t %15d\n", i, TienLaiPhaiTra, SoTienGocPhaiTra, TongTienPhaiTra, SoDu);
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh Tinh Tien Lai.");
                printf("\n Cam On Ban Da Su Dung Nha.");
                break;
            }
            default:
                printf("\n Lua Chon Khong Hop Le! Vui Long Chon Lai.");
        }
        if (LuaChon6 != 0) {
            printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc.");
            getchar();
            getchar();
        }
    } while (LuaChon6 != 0);
}

int main() {
    SuLyHienThi6();
    return 0;
}

