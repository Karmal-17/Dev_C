#include <stdio.h>
#include <stdlib.h>

// H�m t�m UCLN c?a hai s?
int UCLonNhat(int a, int b) {
    while (b != 0) {
        int So = b;
        b = a % b;
        a = So;
    }
    return abs(a);
}

// H�m r�t g?n ph�n s?
void RutGonPhanSo(int *tu, int *mau) {
    int uocchungln = UCLonNhat(*tu, *mau);
    *tu /= uocchungln;
    *mau /= uocchungln;
}

void HienThi10() {
    printf("\n =========== Tinh Phan So ===========");
    printf("\n + 1. Cong Hai Phan So.              +");
    printf("\n + 2. Tru Phan So.                   +");
    printf("\n + 3. Nhan Phan So.                  +");
    printf("\n + 4. Chia Phan So.                  +");
    printf("\n + 0. Thoat Chuong Trinh.            +");
    printf("\n ====================================");
}

void SuLyHienThi10() {
    int LuaChon10;
    do {
        system("cls");
        HienThi10();
        printf("\n Nhap Lua Chon Cua Ban: ");
        scanf("%d", &LuaChon10);
        switch (LuaChon10) {
            case 1: {
                printf("\n 1. Cong Hai Phan So. ");
                int Tu1, Tu2, Mau1, Mau2;
                printf("\n Nhap Tu So Phan So Thu Nhat: ");
                scanf("%d", &Tu1);
                printf("\n Nhap Mau So Phan So Thu Nhat: ");
                scanf("%d", &Mau1);
                printf("\n Nhap Tu So Phan So Thu Hai: ");
                scanf("%d", &Tu2);
                printf("\n Nhap Mau So Phan So Thu Hai: ");
                scanf("%d", &Mau2);

                if (Mau1 == 0 || Mau2 == 0) {
                    printf("\n Loi: Mau So Khong Duoc Bang 0.\n");
                } else {
                    int KetQuaTu = Tu1 * Mau2 + Tu2 * Mau1;
                    int KetQuaMau = Mau1 * Mau2;
                    RutGonPhanSo(&KetQuaTu, &KetQuaMau);
                    printf("\n Ket Qua Phep Cong: %d / %d\n", KetQuaTu, KetQuaMau);
                }
                break;
            }
            case 2: {
                printf("\n 2. Tru Hai Phan So. ");
                int Tu1, Tu2, Mau1, Mau2;
                printf("\n Nhap Tu So Phan So Thu Nhat: ");
                scanf("%d", &Tu1);
                printf("\n Nhap Mau So Phan So Thu Nhat: ");
                scanf("%d", &Mau1);
                printf("\n Nhap Tu So Phan So Thu Hai: ");
                scanf("%d", &Tu2);
                printf("\n Nhap Mau So Phan So Thu Hai: ");
                scanf("%d", &Mau2);

                if (Mau1 == 0 || Mau2 == 0) {
                    printf("\n Loi: Mau So Khong Duoc Bang 0.\n");
                } else {
                    int KetQuaTu = Tu1 * Mau2 - Tu2 * Mau1;
                    int KetQuaMau = Mau1 * Mau2;
                    RutGonPhanSo(&KetQuaTu, &KetQuaMau);
                    printf("\n Ket Qua Phep Tru: %d / %d\n", KetQuaTu, KetQuaMau);
                }
                break;
            }
            case 3: {
                printf("\n 3. Nhan Hai Phan So. ");
                int Tu1, Tu2, Mau1, Mau2;
                printf("\n Nhap Tu So Phan So Thu Nhat: ");
                scanf("%d", &Tu1);
                printf("\n Nhap Mau So Phan So Thu Nhat: ");
                scanf("%d", &Mau1);
                printf("\n Nhap Tu So Phan So Thu Hai: ");
                scanf("%d", &Tu2);
                printf("\n Nhap Mau So Phan So Thu Hai: ");
                scanf("%d", &Mau2);

                if (Mau1 == 0 || Mau2 == 0) {
                    printf("\n Loi: Mau So Khong Duoc Bang 0.\n");
                } else {
                    int KetQuaTu = Tu1 * Tu2;
                    int KetQuaMau = Mau1 * Mau2;
                    RutGonPhanSo(&KetQuaTu, &KetQuaMau);
                    printf("\n Ket Qua Phep Nhan: %d / %d\n", KetQuaTu, KetQuaMau);
                }
                break;
            }
            case 4: {
                printf("\n 4. Chia Hai Phan So. ");
                int Tu1, Tu2, Mau1, Mau2;
                printf("\n Nhap Tu So Phan So Thu Nhat: ");
                scanf("%d", &Tu1);
                printf("\n Nhap Mau So Phan So Thu Nhat: ");
                scanf("%d", &Mau1);
                printf("\n Nhap Tu So Phan So Thu Hai: ");
                scanf("%d", &Tu2);
                printf("\n Nhap Mau So Phan So Thu Hai: ");
                scanf("%d", &Mau2);

                if (Mau1 == 0 || Mau2 == 0 || Tu2 == 0) {
                    printf("\n Loi: Mau So Hoac Tu So Cua Phan So Thu Hai Khong Duoc Bang 0.\n");
                } else {
                    int KetQuaTu = Tu1 * Mau2;
                    int KetQuaMau = Mau1 * Tu2;
                    RutGonPhanSo(&KetQuaTu, &KetQuaMau);
                    printf("\n Ket Qua Phep Chia: %d / %d\n", KetQuaTu, KetQuaMau);
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh. Cam On Ban!\n");
                break;
            }
            default: {
                printf("\n Lua Chon Khong Hop Le. Vui Long Thu Lai!\n");
            }
        }
        if (LuaChon10 != 0) {
            printf("\n Nhan Phim Bat Ky De Tiep Tuc...");
            getchar();
            getchar();
        }
    } while (LuaChon10 != 0);
}

