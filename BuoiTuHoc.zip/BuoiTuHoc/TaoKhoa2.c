#include <stdio.h>
#include <string.h>

int main(){
	char KhoaChinh[] = "Key123";
	char NhapKhoa[50];
	printf("\n Vui Long Nhap Mat Ma De Mo Khoa: ");
	while (1){
		fgets(NhapKhoa,sizeof(NhapKhoa),stdin);
		NhapKhoa[strcspn(NhapKhoa,"\n")] = 0;
		if (strstr(NhapKhoa,KhoaChinh)) {
			printf("\n Khoa Chinh  Xac");
			break;
		} else {
			printf("\n Khoa Ban Vua Nhap Khong Chinh Sac!");
		}
	}
	return 0;
}
