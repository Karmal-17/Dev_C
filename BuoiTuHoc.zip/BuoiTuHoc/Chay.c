#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STUDENTS 100
#define NAME_LENGTH 50

typedef struct {
    int id;
    char name[NAME_LENGTH];
    float gpa;
} Student;

Student students[MAX_STUDENTS];
int studentCount = 0;

void addStudent() {
    if (studentCount >= MAX_STUDENTS) {
        printf("Danh s�ch d� d?y!\n");
        return;
    }

    printf("Nh?p ID sinh vi�n: ");
    scanf("%d", &students[studentCount].id);
    printf("Nh?p t�n sinh vi�n: ");
    scanf(" %[^\n]", students[studentCount].name);
    printf("Nh?p GPA sinh vi�n: ");
    scanf("%f", &students[studentCount].gpa);

    studentCount++;
    printf("Th�m sinh vi�n th�nh c�ng!\n");
}

void displayStudents() {
    printf("\nDanh s�ch sinh vi�n:\n");
    int i;
    for ( i = 0; i < studentCount; i++) {
        printf("ID: %d, T�n: %s, GPA: %.2f\n", students[i].id, students[i].name, students[i].gpa);
    }
}

void searchStudent() {
    int id;
    printf("Nh?p ID sinh vi�n c?n t�m: ");
    scanf("%d", &id);
    int i;
    for ( i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            printf("T�m th?y sinh vi�n: ID: %d, T�n: %s, GPA: %.2f\n", students[i].id, students[i].name, students[i].gpa);
            return;
        }
    }

    printf("Kh�ng t�m th?y sinh vi�n v?i ID: %d\n", id);
}

void deleteStudent() {
    int id;
    printf("Nh?p ID sinh vi�n c?n x�a: ");
    scanf("%d", &id);
    int i,j;
    for ( i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            for ( j = i; j < studentCount - 1; j++) {
                students[j] = students[j + 1];
            }
            studentCount--;
            printf("X�a sinh vi�n th�nh c�ng!\n");
            return;
        }
    }

    printf("Kh�ng t�m th?y sinh vi�n v?i ID: %d\n", id);
}

int main() {
    int choice;

    while (1) {
        printf("\nChuong tr�nh qu?n l� sinh vi�n:\n");
        printf("1. Th�m sinh vi�n\n");
        printf("2. Hi?n th? danh s�ch sinh vi�n\n");
        printf("3. T�m ki?m sinh vi�n\n");
        printf("4. X�a sinh vi�n\n");
        printf("5. Tho�t\n");
        printf("L?a ch?n c?a b?n: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addStudent();
                break;
            case 2:
                displayStudents();
                break;
            case 3:
                searchStudent();
                break;
            case 4:
                deleteStudent();
                break;
            case 5:
                printf("Tho�t chuong tr�nh.\n");
                return 0;
            default:
                printf("L?a ch?n kh�ng h?p l?. Vui l�ng ch?n l?i.\n");
        }
    }

    return 0;
}

