#include <stdio.h>
#include <math.h> // Thu vi?n d�ng cho h�m pow()

void tinhTienVayXe(float phanTramVayToiDa, float giaTriXe, float laiSuatNam, int thoiHanVayNam) {
    // T�nh to�n
    float soTienTraTruoc = (1 - phanTramVayToiDa / 100) * giaTriXe;
    float soTienDuocVay = giaTriXe - soTienTraTruoc;
    float laiSuatThang = laiSuatNam / 12 / 100;
    int soThang = thoiHanVayNam * 12;
    float tienTraHangThang = soTienDuocVay * (laiSuatThang * pow(1 + laiSuatThang, soThang)) / 
                             (pow(1 + laiSuatThang, soThang) - 1);

    // In k?t qu?
    printf("\nSo tien phai tra truoc: %.2f VND\n", soTienTraTruoc);
    printf("So tien tra hang thang: %.2f VND\n", tienTraHangThang);
}

int main() {
    float giaTriXe;          // Gi� tr? xe
    float laiSuatNam;        // L�i su?t c? d?nh theo nam
    int thoiHanVayNam;       // Th?i h?n vay
    float phanTramVayToiDa;  // Ph?n tram vay t?i da

    // Nh?p th�ng tin t? ngu?i d�ng
    printf("Nhap gia tri cua xe (VND): ");
    scanf("%f", &giaTriXe);

    printf("Nhap lai suat theo nam (%%): ");
    scanf("%f", &laiSuatNam);

    printf("Nhap thoi han vay (so nam): ");
    scanf("%d", &thoiHanVayNam);

    printf("Nhap phan tram vay toi da (0-100): ");
    scanf("%f", &phanTramVayToiDa);

    // G?i h�m t�nh to�n v� in k?t qu?
    tinhTienVayXe(phanTramVayToiDa, giaTriXe, laiSuatNam, thoiHanVayNam);

    return 0;
}

