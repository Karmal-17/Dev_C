#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
void HienThi(){
	printf("\n +------- Menu --------+");
	printf("\n 1.Doi Tien VND Sang Tien USD.");
	printf("\n 2.Tinh Diem Trung Binh 3 Mon.");
	printf("\n 3.Giai Phuong Trinh Bac 2.");
	printf("\n 4.Doi Tu Do Xang Radian.");
	printf("\n 5.Kiem Tra Hai So a Va b.");
	printf("\n 0.Thoat Truong Trinh.");
	printf("\n +---------------------+");
	printf("\n Vui Long Chon So Ban Muon: ");
}

void HienThi1(){
	printf("\n + ------ Doi Tien ------ +");
	printf("\n 1. Doi Tien VND Thanh USD.");
	printf("\n 2. Doi Tien USD Thanh VND.");
	printf("\n 0. Thoat.");
	printf("\n + ---------------------- +");
	printf("\n Vui Long Chon So Ban Muon : ");
}

void SuLyHienThi1(){
	int LuaChon1;
	do {
		system("cls");
		HienThi1();
		scanf("%d",&LuaChon1);
		switch(LuaChon1){
			case 1: {
				printf("\n 1. Doi Tien Tu VND Thanh USD.");
				int SoTien;
				printf("\n Vui Long Nhap So Tien Ban Muon Doi:  VND");
				scanf("%d",&SoTien);
				if (SoTien > 1000){
					float ThanhTien = SoTien / 25000;
					printf("\n So Tien Ban Vua Nhap: %d VND",SoTien);
					printf("\n So Tien Ban Doi Duoc La: %.2f USD",ThanhTien);
				} else {
					printf("\n So Tien Ban Muon Doi Be Hon 1000.");
					printf("\n Tien It Doi Lam Cai Dau Buoi.");
					printf("\n Jack Viec.");
				}
				break;
			} 
			case 2: {
				printf("\n 2.  Doi Tien Tu USD Thanh VND.");
				float SoTien;
				printf("\n Vui Long Nhap So Tien Ban Muon Doi:  USD");
				scanf("%f",&SoTien);
				if (SoTien <= 0 ){
					printf("\n So Tien Ban Vua Nhap Be Hon Hoac Bang 0.");
					printf("\n Co Tien Khong Ma Doi Doi.");
					printf("\n Bao H Co Tien Thi Hang Doi Nha.");
				} else {
					int ThanhTien = SoTien * 25000;
					printf("\n So Tien Ban Vua Nhap La: %.2f USD",SoTien);
					printf("\n So Tien Ban Doi Duoc La: %d VND",ThanhTien);
				}
				break;
			} 
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung.");
				break;
			}
			default : 
			printf("\n Ban Da Chon Sai So Roi!");
			printf("\n Vui Long Chon Lai Nhe.");
		}
		if (LuaChon1 != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe....");
			getchar();
			getchar();
		}
	} while (LuaChon1 != 0);
}

void SuLyHienThiY2(){
	printf("\n Tinh Diem Trung Binh Cua Ba Mon Hoc Ban Muon.");
	int SoLuongMon;
//	char Ten[SoLuongMon][100];
//	float Diem[SoLuongMon];
	printf("\n Vui Long Nhap So Luong Mon Ban Muon: ");
	scanf("%d",&SoLuongMon);
	getchar();
	if (SoLuongMon <= 0){
		printf("\n So Luong Mon Ban Vua Nhap Be Hon Hoac Bang 0.");
		printf("\n Chuong Trinh Khong The Thuc Hien Duoc!");
		printf("\n Vui Long Chon Va Nhap Lai Nhe.");
	} else {
		char Ten[SoLuongMon][100];
    	float Diem[SoLuongMon];
		int i;
	    for(i = 0 ; i < SoLuongMon; i ++){
		    printf("\n\n  Ten Mon Thu %d La:  ",i+1);
			gets(Ten[i]);
			printf("\n Vui Long Nhap Diem Cua Mon %s La: ",Ten[i]);
			scanf("%f",&Diem[i]);
			getchar();
		}
		float Tong = 0;
		for(i = 0; i < SoLuongMon; i ++){
			Tong += Diem[i];
		}
		float TrungBinh = Tong / SoLuongMon;
		printf("\n Trung Binh Cua %d Mon La: %.2f",SoLuongMon,TrungBinh);
	}
}
void SuLyHienThiY3(){
	printf("\n Giai Phuong Trinh Bac Hai.");
	int a,b,c;
	float Delta,x,x1,x2;
	printf("\n Vui Long Nhap So a = ");
	scanf("%d",&a);
	printf("\n Vui Long Nhap So b = ");
	scanf("%d",&b);
	printf("\n Vui Long Nhap So c = ");
	scanf("%d",&c);
	if (a == 0){
		if(b == 0){
			if(c == 0){
				printf("\n Phuong Trinh Co Vo So Nghiem.");
			} else {
				printf("\n Phuong Trinh Vo Nghiem.");
			}
		} else {
			printf("\n Phuong Trinh Co Nghiem Duy Nhat La: ");
			x = (float)a / (float)b;
			printf("\n x = %.2f",x);
		}
	} else {
		Delta = b * b - 4 * a * c ;
		x1 = (- b + sqrt(Delta)) / (2 * a);
		x2 = (- b - sqrt(Delta)) / (2 * a);
		if (Delta > 0){
			printf("\n Phuong Trinh %d * x^2 + %d * x + %d Co Hai Nghiem Phan Biet.",a,b,c);
			printf("\n x1 = %.2f",x1);
			printf("\n x2 = %.2f",x2);
		} else {
			if (Delta < 0){
				printf("\n Phuong Trinh %d * x^2 + %d * x + %d Vo Nghiem",a,b,c);
			} else {
				printf("\n Phuong Trinh %d * x^2 + %d * x + %d Co Nghiem Kep.",a,b,c);
				x1 = - b / (float)a;
				printf("\n x1 = x2 = %.2f",x1);
			}
		}
	}
}
void HienThiY4(){
	printf("\n +--------- Doi Do ------------+");
	printf("\n 1. Doi Tu Do Sang Radian");
	printf("\n 2. Doi Tu Radian Sang Do");
	printf("\n 0. Thoat.");
	printf("\n +-----------------------------+");
	printf("\n Vui Long Chon So: ");
}
void SuLyHienThiY4(){
	int LuaChon4;
	do {
		system("cls");
		HienThiY4();
		scanf("%d",&LuaChon4);
		switch(LuaChon4){
			case 1: {
				printf("\n Doi Tu Do Sang Radian.");
				float a;
				printf("\n Vui Long Nhap So Do Ban Muon Doi Nhe:   do");
				scanf("%f",&a);
				if(a <=  0){
					printf("\n So %d Ban Vua Nhap Be Hon Hoac Bang 0!");
					printf("\n Vui Long Chon Va Nhap Lai Nhe.");
				} else {
					float Radian = a * (3.14 / 180);
					printf("\n %.2f Do = %.2f Rad",a,Radian);
				}
				break;
			}
			case 2: {
				printf("\n Do Tu Radian Sang Do.");
				float a;
				printf("\n Vui Long Nhap So Radian Ban Muon Doi:   Rad");
				scanf("%f",&a);
				if(a <= 0){
					printf("\n So %d Rad Ban Vua Nhap Be Hon Hoac Bang 0");
					printf("\n Vui Long Chon So Va Nhap Lai Nhe.");
				} else {
					float Do = a * (180 / 3.14);
					printf("\n %.2f Rad = %.2f Do",a,Do);
				}
				break;
			} case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Da Su Dung.");
				break;
			} 
			default:
				printf("\n Ban Da Chon Sai So Roi!");
				printf("\n Vui Long Chon Lai Nhe.");
		} 
		if (LuaChon4 != 0){
			printf("\n Nhan Vao Pham Bat Ky De Tiep Tuc Chuong Trinh Nhe....");
			getchar();
			getchar();
		}
	} while (LuaChon4 != 0);
}
void SuLyHienThiY5(){
	printf("\n 5. So Sanh Hai So a Va b.");
	int a,b;
	printf("\n Vui Long Nhap So A = ");
	scanf("%d",&a);
	printf("\n Vui Long Nhap So B = ");
	scanf("%d",&b);
	if (a > b){
		printf("\n So %d Lon Hon So %d",a,b);
	} else {
		if (a == b){
			printf("\n So %d Bang So %d",a,b);
		} else {
			printf("\n So %d Be Hon So %d",a,b);
		}
	}
}
int main(){
	int LuaChon;
	do {
		system("cls");
		HienThi();
		scanf("%d",&LuaChon);
		switch(LuaChon){
			case 1: {
				SuLyHienThi1();
				break;
			}
			case 2: {
				SuLyHienThiY2();
				break;
			}
			case 3 : {
				SuLyHienThiY3();
				break;
			}
			case 4: {
				SuLyHienThiY4();
				break;
			}
			case 5: {
				SuLyHienThiY5();
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Da Su Dung");
				break;
			}
			default:
				printf("\n Ban Da Chon Sai So Roi! \n  Vui Long Chon Lai So Nhe.");
		} 
		if (LuaChon != 0){
			printf("\n Vui Long Nhan Vao Phim Bat Ky De Tiep Tuc Chuong Trinh Nhe....");
			getchar();
			getchar();
		}
	} while (LuaChon != 0);
	return 0;
}
