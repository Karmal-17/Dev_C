#include <stdio.h>
#include <math.h>
#include <stdlib.h>

// Hi?n th? menu
void HienThi1() {
    printf("\n ===== Kiem Tra So Nguyen ======");
    printf("\n + 1. Xac Dinh So Nguyen.       +");
    printf("\n + 2. Xac Dinh So Nguyen To.    +");
    printf("\n + 3. Xac Dinh So Chinh Phuong. +");
    printf("\n + 4. Xac Dinh Ca.              +");
    printf("\n + 0. Thoat Chuong Trinh.       +");
    printf("\n ===============================");
}

void SyLyHienThi1() {
    int LuaChon1;
    do {
        system("cls");
        HienThi1();
        printf("\n Nhap Lua Chon Cua Ban: ");
        scanf("%d", &LuaChon1);
        switch (LuaChon1) {
            case 1: { 
                printf("\n 1. Xac Dinh So Nguyen.");
                float a;
                printf("\n Vui Long Nhap So (Am Hoac Duong): ");
                scanf("%f", &a);
                if (a == (int)a) {
                    if (a > 0) {
                        printf("\n So %d Ban Vua Nhap La So Nguyen Duong.", (int)a);
                    } else if (a == 0) {
                        printf("\n So %d Ban Vua Nhap La So Nguyen Khong Am.", (int)a);
                    } else {
                        printf("\n So %d Ban Vua Nhap La So Nguyen Am.", (int)a);
                    }
                } else {
                    printf("\n So Ban Vua Nhap Khong Phai La So Nguyen.");
                }
                break;
            }
            case 2: { 
                printf("\n 2. Xac Dinh So Nguyen To.");
                int a,i, XacDinh = 1;
                printf("\n Nhap So Nguyen Can Kiem Tra: ");
                scanf("%d", &a);
                if (a <= 1) {
                    XacDinh = 0;
                } else {
                    for ( i = 2; i <= sqrt(a); i++) {
                        if (a % i == 0) {
                            XacDinh = 0;
                            break;
                        }
                    }
                }
                if (XacDinh) {
                    printf("\n So %d Ban Vua Nhap La So Nguyen To.", a);
                } else {
                    printf("\n So %d Ban Vua Nhap Khong Phai La So Nguyen To.", a);
                }
                break;
            }
            case 3: { 
                printf("\n 3. Xac Dinh So Chinh Phuong.");
                int a;
                printf("\n Nhap So Nguyen Can Kiem Tra: ");
                scanf("%d", &a);
                if (a >= 0) {
                    int sqrtA = (int)sqrt(a);
                    if (sqrtA * sqrtA == a) {
                        printf("\n So %d Ban Vua Nhap La So Chinh Phuong.", a);
                    } else {
                        printf("\n So %d Ban Vua Nhap Khong Phai La So Chinh Phuong.", a);
                    }
                } else {
                    printf("\n So %d Khong Phai So Chinh Phuong (Khong Ap Dung Cho So Am).", a);
                }
                break;
            }
            case 4: { 
                printf("\n 4. Xac Dinh Ca So Nguyen To Va So Chinh Phuong.");
                int a,i, XacDinh = 1;
                printf("\n Nhap So Nguyen Can Kiem Tra: ");
                scanf("%d", &a);
                if (a <= 1) {
                    XacDinh = 0;
                } else {
                    for ( i = 2; i <= sqrt(a); i++) {
                        if (a % i == 0) {
                            XacDinh = 0;
                            break;
                        }
                    }
                }
                if (XacDinh) {
                    printf("\n So %d Ban Vua Nhap La So Nguyen To.", a);
                } else {
                    printf("\n So %d Ban Vua Nhap Khong Phai La So Nguyen To.", a);
                }
                if (a >= 0) {
                    int sqrtA = (int)sqrt(a);
                    if (sqrtA * sqrtA == a) {
                        printf("\n So %d Ban Vua Nhap La So Chinh Phuong.", a);
                    } else {
                        printf("\n So %d Ban Vua Nhap Khong Phai La So Chinh Phuong.", a);
                    }
                } else {
                    printf("\n So %d Khong Phai So Chinh Phuong (Khong Ap Dung Cho So Am).", a);
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Su Dung.");
                break;
            }
            default:
                printf("\n Chon Sai Roi! Vui Long Chon Lai Nhe.");
        }
        if (LuaChon1 != 0) {
            printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Chuong Trinh.......");
            getchar();
            getchar();
        }
    } while (LuaChon1 != 0);
}

int main() {
    SyLyHienThi1();
    return 0;
}

