#include <stdio.h>

void HienThiMenu(){
	printf("\n +-------------Menu---------------+");
	printf("\n + 1. Thong Tin Ca Nhan.          +");
	printf("\n + 2.Tinh Tong.                   +");
	printf("\n + 3. Thong Tin Sinh Vien.        +");
	printf("\n + 0. Thoat Chuong Trinh.         +");
	printf("\n +--------------------------------+");
	printf("\n Moi Ban Chon So: ");
}

void HienThi1(){
	printf("\n Thong Tin Ca Nhan.");
	char Ten[100];
	int Tuoi;
	char DiaChi[100];
	int HocKy;
	char ChuyenNganh[100];
	printf("\n Vui Long Nhap Ho Va Ten Cua Ban: ");
	gets(Ten);
	printf("\n Vui Long Nhap Tuoi Cua Ban: ");
	scanf("%d",&Tuoi);
	getchar();
	printf("\n Vui Long Nhap Dia Chi Cua Ban: ");
	gets(DiaChi);
	printf("\n Vui Long Nhap Hoc Ky Cua Ban: ");
	scanf("%d",&HocKy);
	getchar();
	printf("\n Vui Long Nhap Chuyen Nganh Cua Ban: ");
	gets(ChuyenNganh);
	
	printf("\n Hien Thi Thong Tin Ca Nhan Cua Ban: ");
	printf("\n Ten Cua Ban: %s",Ten);
	printf("\n Tuoi Cua Ban: %d",Tuoi);
	printf("\n Dia Chi Cua Ban: %s",DiaChi);
	printf("\n Hoc Ky Cua Ban: %d",HocKy);
	printf("\n Chuyen Nganh Cua Ban: %s",ChuyenNganh);
	printf("\n ----Het Rui----");
}

void HienThi2(){
	printf("\n Hien Thi Tinh Tong Cac So Tu 1 Den n.");
	int n,i,Tong =0;
	printf("\n Vui Long Nhap So Nguyen n: ");
	scanf("%d",&n);
	printf("\n So Nguyen N Ban Vua Nhap La: %d \n ",n);
	for(i = 0; i <= n; i ++){
		Tong += i;
	}
	printf("\n Tong Cac So Nguyen Tu 1 Den %d La: %d",n,Tong);
	printf("\n +----- Het Rui -----+");
}

void HienThi3(){
	printf("\n +-------- Thong Tin Sinh Vie Cac Lop ----------+");
	int SoLuongLop;
	printf("\n Vui Long Nhap So Luong Lop: ");
	scanf("%d",&SoLuongLop);
	getchar();
	char Ten[SoLuongLop][100];
	int SoLuongSinhVien[SoLuongLop];
	int i;
	if (SoLuongLop <= 0 ){
		printf("\n So Luong Lop Hoc Ban Vua Nhap Be Hon Hoac Bang 0.");
		printf("\n Vui Long Chon So Va Nhap Lai Nhe.");
	} else {
		for (i = 0; i < SoLuongLop; i++){
			printf("\n Vui Long Nhap Ten Lop Thu %d La: ",i+1);
			gets(Ten[i]);
			printf("\n Vui Long Nhap So Luong Sinh Vien Cua Lop %s La:",Ten[i]);
			scanf("%d",&SoLuongSinhVien[i]);
			getchar();
		}
		int Min = SoLuongSinhVien[0], ViTriMin = 0;
		int Max = SoLuongSinhVien[0], ViTriMax = 0;
		for (i = 0;i < SoLuongLop; i ++){
			if (SoLuongSinhVien[i] > Max){
				Max = SoLuongSinhVien[i];
				ViTriMax = i;
			}
		}
		for (i = 0;i < SoLuongLop; i ++){
			if (SoLuongSinhVien[i] < Min){
				Min = SoLuongSinhVien[i];
				ViTriMin = i;
			}
		}
		printf("\n +---- Xuat Thong Tin Sinh Vien ----+");
		printf("\n So Luong Lop Hoc La: %d",SoLuongLop);
		for(i = 0;i < SoLuongLop; i ++){
			printf("\n Ten Lop: %s (SoLuong: %d) Dung Thu: %d",Ten[i],SoLuongSinhVien[i],i+1);
		}
		printf("\n Ten Lop Co So Luong Sinh Vien Lon Nhat La: ");
		printf("\n Ten: %s",Ten[ViTriMax]);
		printf("\n So Luong Sinh Vien: %d \n",Max);
		
		printf("\n Ten Lop Co So Luong Sinh Vien Thap Nhat La: ");
		printf("\n Ten: %s",Ten[ViTriMin]);
		printf("\n So Luong Sinh Vien: %d \n",Min);
		
		int Dem = 0;
		for (i = 0;i < SoLuongLop; i ++){
			if (SoLuongSinhVien[i] <= 30){
				printf("\n Ten Lop: %s (SoLuong: %d) Dung Thu: %d",Ten[i],SoLuongSinhVien[i],i+1);
				Dem = 1;
			}
		}
		if (Dem == 0){
			printf("\n Chua Co Lop Nao Co So Luong Sinh Vien Be Hon Hoac Bang 30.");
		}
	}
}
int main(){
	int LuaChon;
	do {
		system("cls");
		HienThiMenu();
		scanf("%d",&LuaChon);
		getchar();
		switch(LuaChon){
			case 1: {
				HienThi1();
				break;
			}
			case 2: {
				HienThi2();
				break;
			}
			case 3: {
				HienThi3();
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default :
				printf("\n Ban Da Chon Sai So Rui !");
				printf("\n Vui Long Chon Lai So Nhe.");
		}
		if (LuaChon != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe......");
			getchar();
			getchar();
		}
	} while (LuaChon != 0);
}
