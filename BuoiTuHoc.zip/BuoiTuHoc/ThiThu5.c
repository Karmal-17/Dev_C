#include <stdio.h>

void HienThiMenu(){
	printf("\n +------------ Menu ------------+");
	printf("\n + 1. Thong Tin Ca Nhan.        +");
	printf("\n + 2. Tong Cac So Tu 1 Den n.   +");
	printf("\n + 3. Thong Tin Tivi.           +");
	printf("\n + 0. Thoat Chuong Trinh.       +");
	printf("\n +------------------------------+");
	printf("\n Vui Long Nhap So: ");
}

void HienThi1(){
	printf("\n Trang Thong Tin Ca Nhan.");
	char Ten[100];
	char MaSV[100];
	int Diem;
	printf("\n Vui Long Nhap Ho Va Ten Cua Ban: ");
	gets(Ten);
	printf("\n Vui Long Nhap Ma So Sinh Vien: ");
	gets(MaSV);
	printf("\n Nhap Diem Cua Ban: ");
	scanf("%d",&Diem);
	
	printf("\n Hien Thi Thong Tin Ca Nhan Cua Ban.");
	printf("\n Ten: %s",Ten);
	printf("\n Ma So Sinh Vien: %s",MaSV);
	printf("\n Diem Cua Ban: %d",Diem);
	
}

void HienThi2(){
	printf("\n Tinh Tong Cac So Tu 1 Den N.");
	int i,n;
	printf("\n Vui Long Nhap So Nguyen N: ");
	scanf("%d",&n);
	int Tong = 0;
	if (n <= 0){
		printf("\n So Nguyen %d Ban Vua Nhap Be Hon Hoac Bang 0.");
		printf("\n Vui Long Chon Va Nhap Lai.");
	} else {
		for(i = 0; i <= n;i++){
			Tong += i;
		}
		printf("\n Tong Cac So Tu 1 Den %d La: %d",n,Tong);
		if (n % 2 == 0){
			printf("\n So %d Ban Vua Nhap La So Chan.",n);
		} else {
			printf("\n So %d Ban Vua Nhap La So Le.",n);
		}
		int SoLon = 0;
		for (i = 0; i < n; i++){
			if (i > SoLon){
				SoLon = i;
			}
		}
		printf("\n So Lon Nhat La: %d",SoLon);
	}
}

void HienThi3(){
	printf("\n +----------- Thong Tin Tivi Cua Hang -------------+");
	int SoLuong;
	printf("\n Vui Long Nhap So Luong Tivi: ");
	scanf("%d",&SoLuong);
	float KichCo[SoLuong];
	int i,j;
	for (i = 0;i < SoLuong; i++){
		printf("\n Nhap Kich Co Cua Tivi Thu %d La: ",i+1);
		scanf("%f",&KichCo[i]);
	}
	float Tong = 0;
	for (i = 0;i < SoLuong; i++){
		Tong += KichCo[i];
	}
	float TrungBinh = Tong / SoLuong;
	
	printf("\n +---------- Xuat Thong Tin ----------+");
	printf("\n So Luong Tivi La: %d",SoLuong);
	printf("\n Trung Binh Kich Co Tivi La: %.1f",TrungBinh);
	float Max = KichCo[0],Min = KichCo[0];
	int ViTriMax = 0,ViTriMin = 0;
	for (i = 0;i <= SoLuong;i++){
		if (KichCo[i] > Max){
			Max = KichCo[i];
			ViTriMax = i;
		} 
		if (KichCo[i] < Min){
			Min = KichCo[i];
			ViTriMin = i;
		}
	}

	printf("\n TiVi Co Kich Co Lon Nhat La: %.1f Dung Thu %d ",Max,ViTriMax );
	printf("\n TiVi Co Kich Co Nho Nhat La: %.1f Dung Thu %d ",Min,ViTriMin );
}
int main(){
	int LuaChon;
	do {
		system("cls");
		HienThiMenu();
		scanf("%d",&LuaChon);
		getchar();
		switch (LuaChon){
			case 1: {
				HienThi1();
				break;
			}
			case 2: {
				HienThi2();
				break;
			}
			case 3: {
				HienThi3();
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh Tinh.");
				printf("\n Cam On Ban Da Su Dung.");
				break;
			}
			default :
				printf("\n Ban Da Chon Sai So Rui!");
				printf("\n Vui Long Chon Lai So Nhe.");
		}
		if (LuaChon != 0){
			printf("\n Nhap Vao Phim Bat Ky De Tiep Tuc Nhe.....");
			getchar();
			getchar();
		}
	} while (LuaChon != 0);
}
