#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int main(){
	char Khoa[] = "Key123";
	char NhapKhoa[50];
	printf("\n Vui Long Nhap Mat Khau: ");
	while (1){
		fgets(NhapKhoa,sizeof(NhapKhoa),stdin);
		NhapKhoa[strcspn(NhapKhoa,"\n")] = 0;
		if (strstr(NhapKhoa,Khoa)){
			printf("\n KHoa Chinh Xac!");
			break;
		}
	}
	return 0;
}
