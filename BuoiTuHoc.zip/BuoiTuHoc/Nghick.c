#include <stdio.h>

void HienThi (){
	printf("\n +------------- Menu ---------------+");
	printf("\n + 1.Tinh Toan.                     +");
	printf("\n + 2.Thoat.                         +");
	printf("\n +----------------------------------+");
	printf("\n Vui Long Chon So: ");
}
void SuLyHienThi1(){
	float a,b,KetQua;
	printf("\n Vui Long Nhap So a: ");
	scanf("%d",&a);
	printf("\n Vui Long Nhap So b: ");
	scanf("%d",&b);
    KetQua = a + b;
	printf("\n Ket Qua Cua %.1f Va %.1f La: %.1f",a,b,KetQua);
}
int main(){
	int LuaChon;
	do{
		system("cls");
		HienThi();
		scanf("%d",&LuaChon);
		switch(LuaChon){
			case 1: {
				SuLyHienThi1();
				break;
			}
			case 2: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default: 
			printf("\n Chon Sai Rui.");
		} 
		if(LuaChon != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc....");
			getchar();
			getchar();
		}
	} while (LuaChon != 0);
}
