#include <stdio.h>
#include <math.h> // Thu vi?n d�ng cho h�m sqrt

// H�m hi?n th? menu
void HienThi1() {
    printf("\n ===== Kiem Tra So Nguyen ======");
    printf("\n + 1. Xac Dinh So Nguyen.       +");
    printf("\n + 2. Xac Dinh So Nguyen To.    +");
    printf("\n + 3. Xac Dinh So Chinh Phuong. +");
    printf("\n + 4. Xac Dinh Ca.              +");
    printf("\n + 0. Thoat Chuong Trinh.       +");
    printf("\n ===============================");
}

// H�m x? l� menu
void SyLyHienThi1() {
    int LuaChon1;
    do {
        system("cls");
        HienThi1();
        printf("\n Nhap Lua Chon Cua Ban: ");
        scanf("%d", &LuaChon1);
        switch (LuaChon1) {
            case 1: {
                printf("\n 1. Xac Dinh So Nguyen.");
                float a;
                printf("\n Vui Long Nhap So Nguyen (Am Hoac Duong): ");
                scanf("%f", &a);
                printf("\n So Ban Vua Nhap La: %.2f", a);
                if (a == (int)a) {
                    if (a > 0) {
                        printf("\n So %d Ban Vua Nhap La So Nguyen Duong.", (int)a);
                    } else if (a == 0) {
                        printf("\n So %d Ban Vua Nhap La So Nguyen Khong Am.", (int)a);
                    } else {
                        printf("\n So %d Ban Vua Nhap La So Nguyen Am.", (int)a);
                    }
                } else {
                    printf("\n So %.2f Khong Phai La So Nguyen.", a);
                }
                break;
            }
            case 2: {
                printf("\n 2. Xac Dinh So Nguyen To.");
                int a,i, isPrime = 1;
                printf("\n Nhap So Nguyen Ban Muon: ");
                scanf("%d", &a);
                if (a <= 1) {
                    isPrime = 0;
                } else {
                    for ( i = 2; i <= sqrt(a); i++) {
                        if (a % i == 0) {
                            isPrime = 0;
                            break;
                        }
                    }
                }
                if (isPrime) {
                    printf("\n So %d La So Nguyen To.", a);
                } else {
                    printf("\n So %d Khong Phai La So Nguyen To.", a);
                }
                break;
            }
            case 3: {
                printf("\n 3. Xac Dinh So Chinh Phuong.");
                int a;
                printf("\n Nhap So Nguyen Ban Muon: ");
                scanf("%d", &a);
                if (a < 0) {
                    printf("\n So %d Khong Phai La So Chinh Phuong.", a);
                } else {
                    int root = (int)sqrt(a);
                    if (root * root == a) {
                        printf("\n So %d La So Chinh Phuong.", a);
                    } else {
                        printf("\n So %d Khong Phai La So Chinh Phuong.", a);
                    }
                }
                break;
            }
            case 4: {
                printf("\n 4. Xac Dinh Ca (Nguyen To Va Chinh Phuong).");
                int a,i, isPrime = 1;
                printf("\n Nhap Mot So Nguyen: ");
                scanf("%d", &a);
                // Ki?m tra s? nguy�n t?
                if (a <= 1) {
                    isPrime = 0;
                } else {
                    for ( i = 2; i <= sqrt(a); i++) {
                        if (a % i == 0) {
                            isPrime = 0;
                            break;
                        }
                    }
                }
                // Ki?m tra s? ch�nh phuong
                int root = (int)sqrt(a);
                int isPerfectSquare = (root * root == a);

                if (isPrime) {
                    printf("\n So %d La So Nguyen To.", a);
                } else {
                    printf("\n So %d Khong Phai La So Nguyen To.", a);
                }
                if (isPerfectSquare) {
                    printf("\n So %d La So Chinh Phuong.", a);
                } else {
                    printf("\n So %d Khong Phai La So Chinh Phuong.", a);
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Su Dung.");
                break;
            }
            default:
                printf("\n Lua Chon Khong Hop Le! Vui Long Thu Lai.");
        }
        if (LuaChon1 != 0) {
            printf("\n Nhan Phim Bat Ky De Tiep Tuc Chuong Trinh...");
            getchar(); // X�a b? d?m
            getchar();
        }
    } while (LuaChon1 != 0);
}

// H�m ch�nh
int main() {
    SyLyHienThi1();
    return 0;
}

