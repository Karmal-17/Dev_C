#include <stdio.h>
#include <string.h>
void HienThiMenu(){
	printf("\n +----------- Menu --------------+");
	printf("\n + 1. Thong Tin Ca Nhan.         +");
	printf("\n + 2. Tinh Tong Tu 1 Den n.      +");
	printf("\n + 3. Thong Tin Tivi.            +");
	printf("\n +-------------------------------+");
	printf("\n Vui Long Chon So Nhe: ");
}

void HienThi1(){
	printf("\n Thong Tin Ca Nhan.");
	char Ten[100];
	char MaSoSinhVien[100];
	int Diem;
	printf("\n Vui Long Nhap Ho Va Ten Cua Ban: ");
	gets(Ten);
	printf("\n Vui Long Nhap Ma So Sinh Vien Cua Ban: ");
	gets(MaSoSinhVien);
	printf("\n Vui Long NHap Diem Cua Ban: ");
	scanf("%d",&Diem);
	
	printf("\n \n Thong Tin Ban Vua Nhap La: ");
	printf("\n Ho Va Ten: %s",Ten);
	printf("\n Ma So Sinh Vien: %s",MaSoSinhVien);
	printf("\n Diem Cua Ban: %d",Diem);
	printf("\n +--- Het Rui ---+");
}

void HienThi2(){
	printf("\n Tinh Tong Cac SO Tu 1 Den n.");
	int i,n;
	printf("\n Vui Long Nhap So Nguyen N: ");
	scanf("%d",&n);
	if (n <= 0){
		printf("\n So %d Ban Vua Nhap Be Hon Hoac Bang Khong.");
		printf("\n Vui Long Chon Va Nhap Lai Nhe.");
	} else {
		int Tong = 0;
		for(i = 0; i <= n; i ++){
			Tong += i;
		}
		printf("\n Tong Cac So Tu 1 Den %d La: %d",n,Tong);
		if (n % 2 == 0){
			printf("\n So %d Ban Vua Nhap La So Chan.");
		} else {
			printf("\n So %d Ban Vua Nhap La So Le.");
		}
		printf("\n +---- Het Rui ----+");
	}
}

void HienThi3(){
	printf("\n +------ Thong Tin Ti Vi Cua Hang ------+");
	int SoLuongTivi;
	printf("\n Vui Long Nhap So Luong Ti Vi: ");
	scanf("%d",&SoLuongTivi);
	getchar();
	char TenTivi[SoLuongTivi][100];
	float KichCo[SoLuongTivi];
	
	if (SoLuongTivi <= 0){
		printf("\n So Luong Ti Vi Ban Vua Nhap Be Hon Hoac Bang 0!");
		printf("\n Vui Long Nhap Lai Nhe.");
	} else {
		int i;
		for (i = 0; i < SoLuongTivi; i ++){
			printf("\n Vui Long Nhap Ten Tivi Thu %d La: ",i+1);
			gets(TenTivi[i]);
			printf("\n Vui Long Nhap Kich Co Cua Tivi %s La: ",TenTivi[i]);
			scanf("%f",&KichCo[i]);
			getchar();
		}
		float Tong = 0;
		for (i = 0; i <SoLuongTivi;i ++){
			Tong += KichCo[i];
		}
		float TrungBinh = Tong / SoLuongTivi;
		printf("\n +---------- Xuat Thong Tin Ti Vi ------------+");
		printf("\n So Luong Tivi La: %d",SoLuongTivi);
		for (i = 0; i <SoLuongTivi; i ++){
			printf("\n Ten Tivi Thu %d La: %s (KichCo: %.2f inch) \n",i+1,TenTivi[i],KichCo[i]);
		}
		printf("\n Kich Co Trung Binh Cua %d Ti Vi La: %.2f",SoLuongTivi,TrungBinh);
		float Max = KichCo[0],Min = KichCo[0];
		int ViTriMax = 0,ViTriMin = 0;
		for (i = 0;i <SoLuongTivi; i ++){
			if(KichCo[i] > Max){
				Max = KichCo[i];
				ViTriMax = i;
			}
			if (KichCo[i] < Min){
				Min = KichCo[i];
				ViTriMin = i;
			}
		}
		printf("\n Ten TiVi Co Kich Co Lon Nhat: %s (KichCo: %.2f) Dung Thu %d",TenTivi[ViTriMax],Max,ViTriMax + 1);
		printf("\n Ten Ti Vi Co Kich Co Nho Nhat: %s (KichCo: %.2f) Dung Thu %d",TenTivi[ViTriMin],Min,ViTriMin + 1);
		printf("\n +----- Het Rui Ne -----+");
	}
}
int main(){
	int LuaChon;
	do {
		system("cls");
		HienThiMenu();
		scanf("%d",&LuaChon);
		switch(LuaChon){
			case 1: {
				HienThi1();
				break;
			}
			case 2: {
				HienThi2();
				break;
			}
			case 3: {
				HienThi3();
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh Tinh.");
				printf("\n Cam On Cac Ban Da Su Dung Trang Tinh.");
				break;
			}
			default: 
			printf("\n Ban Da Chon Sai So Rui!");
			printf("\n Vui Long Chon Lai So Nhe.");
		}
		if(LuaChon != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Chuong Trinh Nhe......");
			getchar();
			getchar();
		}
	} while (LuaChon != 0);
}
