#include <stdio.h>
#include <stdio.h>

void HienThiMenu(){
	printf("\n +----------------- Menu -----------------+");
	printf("\n + 1.Thong Tin Ca Nhan.                   +");
	printf("\n + 2. Tinh Tong Cac So Tu 1 Den N.        +");
	printf("\n + 3.Thong Tin Tivi.                      +");
	printf("\n + 0. Thoat Chuong Trinh.                 +");
	printf("\n +----------------------------------------+");
	printf("\n Moi Ban Chon So : ");
	
}

void Bai1(){
	printf("\n Thong Tinh Ca Nhan.");
	char Ten[100],MaSoSV[100];
	int Diem;
	printf("\n Moi Ban Nhap Ten Sinh Vien: ");
	gets(Ten);
	printf("\n Moi Nhap Ma So Sinh Vien: ");
	gets(MaSoSV);
	printf("\n Moi Ban Nhap Diem: ");
	scanf("%d",&Diem);
	
	printf("\n Thong Tin Sinh Vien Ban Vua Nhap La: ");
	printf("\n Ten Sinh Vien Ban Vua Nhap La: %s",Ten);
	printf("\n Ma So Sinh Vien Ban Vua Nhap La: %s",MaSoSV);
	printf("\n Diem So Ban Vua Nhap La: %d",Diem);
}

void Bai2(){
	printf("\n Tinh Tong Cac So Tu 1 Den N.");
	int n,i;
	printf("\n Moi Ban Nhap So Nguyen N: ");
	scanf("%d",&n);
	int Tong = 0;
	for (i = 0;i <= n; i ++){
		Tong += i;
	}
	printf("\n Cac So Nguyen Tu 1 Den %d La: %d ",n,Tong);
	if (n % 2 == 0){
		printf("\n So %d Ban Vua La So Chan. ",n);
	} else {
		printf("\n So %d Ban Vua La So Le.",n);
	}
}

void Bai3(){
	printf("\n +----------- Thong Tin Cua Hang TiVi -----------+");
	int SoLuong;
	float KichCo[SoLuong];
	printf("\n Moi Ban Nhap So Luong TiVi: ");
	scanf("%d",&SoLuong);
	getchar();
	int i;
	
	if (SoLuong <= 0){
		printf("\n So Luong Sinh Vien Ban Vua Nhap Be Hon Hoac Bang 0.");
		printf("\n Vui Long Chon Va Nhap Lai.");
	} else {
		printf("\n +------------ Xuat Thong Tin TiVi ----------------+");
	    printf("\n So Luong Ti Vi Ban Vua Nhap La: %d",SoLuong);
		for ( i = 0;i < SoLuong;i ++){
			printf("\n Moi Ban Nhap Kich Co Trung Binh Cua Tivi: ");
	        scanf("%f",&KichCo[i]);
		}
		float TrungBinh;
		int Tong = 0;
		for (i = 0;i < SoLuong; i++){
			Tong += i;
		}
		for (i = 0; i < SoLuong; i ++){
			TrungBinh = (float)Tong / SoLuong;
		}
		printf("\n Kich Co Trung Binh Cua %d TiVi La: %.2f",SoLuong,TrungBinh);
		float KichCoLN = 0;
		for (i = 0; i < SoLuong ; i++){
			if (KichCo[i] > KichCoLN){
				KichCoLN = KichCo[i];
			}
		}
		printf("\n Kich Co TiVi Long Nhat La: %.2f Dung Thu %d",KichCoLN,i+1);
		
	}
}
int main(){
	int LuaChon;
	do {
		system("cls");
		HienThiMenu();
		scanf("%d",&LuaChon);
		getchar();
		switch(LuaChon){
			case 1: {
				Bai1();
				break;
			}
			case 2: {
				Bai2();
				break;
			}
			case 3: {
				Bai3();
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh Tinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default : 
			printf("\n Ban Da Chon Sai So Roi !");
			printf("\n Vui Long Chon Lai So Nhe.");
		}
		if (LuaChon != 0){
			printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe......");
			getchar();
			getchar();
		}
	} while (LuaChon != 0);
}
