#include <stdio.h>

int main(){
	printf("\n Thong Tin Lop Hoc.");
	int SoLuongLop;
	printf("\n Vui Long Nhap So Luong Lop Hoc: ");
	scanf("%d",&SoLuongLop);
	getchar();
	char Ten[SoLuongLop][100];
	int SoLuongSinhVien[SoLuongLop];
	int i;
	if (SoLuongLop <= 0){
		printf("\n So Luong Lop Ban Vua Nhap Be Hon Hoac Bang 0.");
		printf("\n Vui Long Chon Va Nhap Lai!");
	} else {
		for (i = 0;i<SoLuongLop ; i++){
			printf("\n Nhap Ten Lop Thu %d La:  ",i+1);
			gets(Ten[i]);
			printf("\n So Luong Sinh Vien Cua Lop %s La:  ",Ten[i]);
			scanf("%d",&SoLuongSinhVien[i]);
			getchar();
		}
		int Min = SoLuongSinhVien[0];
		int ViTri = 0;
		for (i = 0; i < SoLuongLop; i++){
			if (SoLuongSinhVien[i] < Min){
				Min = SoLuongSinhVien[i];
				ViTri = i;
			}
		}
		for (i = 0; i < SoLuongLop; i++){
			printf("\n Ten Lop Thu %d La: %s (SoLuongSV : %d) \n ",i+1,Ten[i],SoLuongSinhVien[i]);
		}
		printf("\n Ten Lop Co So Luong Sinh Vien It Nhat Thu  La: %s (SoLuongSV: %d) \n ",Ten[ViTri], Min);
		
		int Dem = 0;
		printf("\n Ten ");
		for (i = 0;i < SoLuongLop; i++){
			if (SoLuongSinhVien[i] < 30){
				printf("\n Ten Lop Thu %d La: %s (SoLuongSV: %d)",i+1,Ten[i],SoLuongSinhVien[i]);
				Dem = 1;
			}
		}
		if (Dem == 0){
			printf("\n So Lop Ban Vua Nhap Chua Co  Lop Nao Co So Luong Sinh Vien Be Hon 30.");
		}
	}
	return 0;
}
