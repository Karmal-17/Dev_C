#include <stdio.h>
#include <math.h>

void HienThi2(){
    printf("\n ====== Tim Uoc Va Boi Chung ======");
    printf("\n + 1.Tim Uoc Chung.               +");
    printf("\n + 2.Tim Boi Chung.               +");
    printf("\n + 3.Tim Ca Uoc Va Boi Chung.     +");
    printf("\n + 0.Thoat Truong Trinh.          +");
    printf("\n ==================================");
}

int UocChungLN(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int BoiChungNN(int a, int b) {
    return (a * b) / UocChungLN(a, b);
}

void SuLyHienThi2(){
    int LuaChon2;
    do {
        system("cls");
        HienThi2();
        printf("\n Nhap Lua Chon Cua Ban: ");
        scanf("%d", &LuaChon2);
        switch(LuaChon2){
            case 1: {
                printf("\n 1.Tim Uoc Chung Cua Hai So.");
                int a, b;
                printf("\n Nhap So Thu Nhat: ");
                scanf("%d", &a);
                printf("\n Nhap So Thu Hai: ");
                scanf("%d", &b);
                printf("\n So Ban Vua Nhap La: a = %d va b = %d", a, b);
                if (a <= 0 || b <= 0) {
                    printf("\n Ca Hai So Deu Be Hon Hoac Bang 0.");
                    printf("\n Phep Tinh Chua Duoc Thuc Hien.");
                } else {
                    printf("\n Uoc chung lon nhat cua %d va %d la: %d\n", a, b, UocChungLN(a, b));
                }
                break;
            }
            case 2: {
                printf("\n Tim Boi Chung Nho Nhat Cua Hai So.");
                int a, b;
                printf("\n Nhap So a = ");
                scanf("%d", &a);
                printf("\n Nhap So b = ");
                scanf("%d", &b);
                printf("\n Cac So Ban Vua Nhap La: a = %d va b = %d", a, b);
                if (a <= 0 || b <= 0) {
                    printf("\n Hai So Ban Vua Nhap Be Hon Hoac Bang 0.");
                    printf("\n Nen Phep Tinh Chua Duoc Thuc Hien.");
                } else {
                    printf("\n Boi Chung Nho Nhat Cua %d va %d La: %d", a, b, BoiChungNN(a, b));
                }
                break;
            }
            case 3: {
                printf("\n Tim Ca Uoc Chung Lon Nhat Va Boi Chung Nho Nhat Cua Hai So.");
                int a, b;
                printf("\n Nhap So a = ");
                scanf("%d", &a);
                printf("\n Nhap So b = ");
                scanf("%d", &b);
                printf("\n Cac So Ban Vua Nhap La: a = %d va b = %d", a, b);
                if (a <= 0 || b <= 0) {
                    printf("\n Hai So Ban Vua Nhap Be Hon Hoac Bang 0.");
                    printf("\n Nen Phep Tinh Chua Duoc Thuc Hien.");
                } else {
                    printf("\n Uoc Chung Lon Nhat Cua %d Va %d La: %d", a, b, UocChungLN(a, b));
                    printf("\n Boi Chung Nho Nhat Cua %d Va %d La: %d", a, b, BoiChungNN(a, b));
                }
                break;
            }
            case 4: {
                printf("\n Dang Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Tinh.");
                break;
            }
            default:
                printf("\n Ban Chon Sai So Rui!");
                printf("\n Vui Long Chon lai So Nhe.");
        }
        if (LuaChon2 != 0) {
            printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Nhe........");
            getchar();
            getchar();
        }
    } while (LuaChon2 != 0);
}

int main() {
    SuLyHienThi2();
    return 0;
}

