#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void HienThiMeNu() {
    printf("\n ========= MeNu Chinh ==========");
    printf("\n + 1. Thong Tin Gia Dinh.      +");
    printf("\n + 2. Tim 8 So Chia Het Cho 7  +");
    printf("\n + 3. Thong Tin Sinh Vien.     +");
    printf("\n + 0. Thoat Chuong Trinh.      +");
    printf("\n ===============================");
    printf("\n Moi Ban Chon So Ban Muon Nhe: ");
}

int main() {
    int LuaChon;
    do {
        HienThiMeNu();
        scanf("%d", &LuaChon);

        switch (LuaChon) {
            case 1: {
                int i, SoLuongTV;
                printf("\n Nhap So Luong Cua Gia Dinh Ban: ");
                scanf("%d", &SoLuongTV);

                if (SoLuongTV <= 0) {
                    printf("\n So Thanh Vien Trong Gia Dinh Phai Lon Hon 0.\n");
                } else {
                    char TenTV[SoLuongTV][100];
                    int TuoiTV[SoLuongTV];

                    for (i = 0; i < SoLuongTV; i++) {
                        printf("\n Nhap Ten Cua Thanh Vien Thu %d: ", i + 1);
                        gets(TenTV[i]);
                        printf("\n Nhap So Tuoi Cua Thanh Vien %s: ", TenTV[i]);
                        scanf("%d", &TuoiTV[i]);
                    }

                    printf("\n Gia Dinh Cua Ban Co %d Nguoi:\n", SoLuongTV);
                    for (i = 0; i < SoLuongTV; i++) {
                        printf("\n Thanh Vien Thu %d La: %s ", i + 1, TenTV[i]);
                        printf("\n Tuoi: %d", TuoiTV[i]);
                    }
                    printf("\n");
                }
                break;
            }
            case 2: {
                int i, SoLuongSo[8];
                printf("\n Nhap 8 so chia het cho 7:\n");
                for (i = 0; i < 8; i++) {
                    do {
                        printf("Nhap so thu %d: ", i + 1);
                        scanf("%d", &SoLuongSo[i]);
                        if (SoLuongSo[i] % 7 != 0) {
                            printf("So nhap vao khong chia het cho 7. Vui long nhap lai!\n");
                        }
                    } while (SoLuongSo[i] % 7 != 0);
                }
                printf("\nCac so da nhap:\n");
                for (i = 0; i < 8; i++) {
                    printf("%d ", SoLuongSo[i]);
                }
                printf("\n");
                break;
            }
            case 3: {
                int SoLuongSinhVien, i;
                printf("\n Nhap So Luong Sinh Vien: ");
                scanf("%d", &SoLuongSinhVien);

                if (SoLuongSinhVien <= 0) {
                    printf("\n So Luong Sinh Vien Phai Lon Hon 0.\n");
                } else {
                    char TenSV[SoLuongSinhVien][100];
                    int TuoiSV[SoLuongSinhVien];
                    char LopSV[SoLuongSinhVien][50];

                    for (i = 0; i < SoLuongSinhVien; i++) {
                        printf("\n Nhap Ten Sinh Vien %d: ", i + 1);
                        scanf("%s", TenSV[i]);
                        printf("\n Nhap Tuoi Sinh Vien %d: ", i + 1);
                        scanf("%d", &TuoiSV[i]);
                        printf("\n Nhap Lop Sinh Vien %d: ", i + 1);
                        scanf("%s", LopSV[i]);
                    }

                    printf("\n Danh Sach Sinh Vien:\n");
                    for (i = 0; i < SoLuongSinhVien; i++) {
                        printf("\n Sinh Vien Thu %d: ", i + 1);
                        printf("\n Ten: %s", TenSV[i]);
                        printf("\n Tuoi: %d", TuoiSV[i]);
                        printf("\n Lop: %s\n", LopSV[i]);
                    }
                }
                break;
            }
            case 0:
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Su Dung.\n");
                break;
            default:
                printf("\n Lua Chon Khong Hop Le. Vui Long Chon Lai.\n");
        }
    } while (LuaChon != 0);

    return 0;
}

