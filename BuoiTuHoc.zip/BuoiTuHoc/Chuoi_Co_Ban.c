#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void HienThi(){
    char Ten[] = "Nguyen Gia Bao";
    char Nhan[20];
    strcpy(Nhan, Ten);
    printf("\n Ten: %s", Nhan);
    printf("\n \n");

    char Ho[] = "Nguyen ";
    char TenDem[] = "Gia ";
    char Ten1[] = "Bao";
    char HoVaTen[50];
    strcpy(HoVaTen, Ho);
    strcat(HoVaTen, TenDem);
    strcat(HoVaTen, Ten1);
    printf("\n Ho Va Ten: %s", HoVaTen);

    printf("\n \n");
    
    char Nhap1[20], Nhap2[20];
    printf("\n Vui Long Nhap Chuoi 1: ");
    fgets(Nhap1, sizeof(Nhap1), stdin);
    Nhap1[strcspn(Nhap1, "\n")] = 0;

    printf("\n Vui Long Nhap Chuoi 2: ");
    fgets(Nhap2, sizeof(Nhap2), stdin);
    Nhap2[strcspn(Nhap2, "\n")] = 0;

    if (strcmp(Nhap1, Nhap2) > 0){
        printf("\n Chuoi 1 Lon Hon Chuoi 2");
    } else if (strcmp(Nhap1, Nhap2) == 0){
        printf("\n Chuoi 1 Bang Chuoi 2.");
    } else {
        printf("\n Chuoi 1 Be Hon Chuoi 2.");
    }
}

int main(){
    printf("Hello World");
    char Khoa[] = "Key123";
    char NhapKhoa[15];

    printf("\n Vui Long Nhap Mat Khau: ");
    while (1){
        // system("cls");  // Kh�ng c?n thi?t cho vi?c ch?y l?nh n�y
        fgets(NhapKhoa, sizeof(NhapKhoa), stdin);
        NhapKhoa[strcspn(NhapKhoa, "\n")] = 0;

        if (strcmp(NhapKhoa, Khoa) == 0){
            printf("\n Da Mo Khoa.");
            HienThi();
            break;
        } else {
            printf("\n Ban Da Nhap Sai Khoa Roi! Vui Long Nhap Lai: ");
        }
    }

    return 0;
}

