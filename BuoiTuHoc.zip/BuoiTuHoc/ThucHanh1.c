#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void HienThiMeNu(){
	printf("\n ========= MeNu Chinh ==========");
	printf("\n + 1.Thong Tin Gia Dinh.       +");
	printf("\n + 2.Tim 7 So Chia Het Cho 7   +");
	printf("\n + 3.Thong Tin Sinh Vien.      +");
	printf("\n + 0.Thoat Chuong Trinh.       +");
	printf("\n ===============================");
	printf("\n Moi Ban Chon So Ban muon Nhe: ");
}


int main(){
	int LuaChon;
	do {
		HienThiMeNu();
		scanf("%d",&LuaChon);
		switch(LuaChon){
			case 1: {
				int i, SoLuongTV;
				printf("\n Nhap So Luong Cua Gia Dinh Ban: ");
				scanf("%d",&SoLuongTV);
				if (SoLuongTV <= 0){
					printf("\n So Thanh Vien Trong Gia Dinh Phai Lon Hon 0.");
				} else {
					char TenTV[SoLuongTV][100];
				    int TuoiTV[SoLuongTV];
					for (i = 0;i < SoLuongTV;i++){
					printf("\n Nhap Ten Cua Thanh Vien Thu %d : ",i+1);
					gets(TenTV[i]);
					printf("\n Nhap So Tuoi Cua Thanh Vien %s : ",TenTV[i]);
					scanf("%d",&TuoiTV[i]);
				}
				printf("\n Gia Dinh Cua Ban Co %d Nguoi.",SoLuongTV);
				for (i = 0;i < SoLuongTV;i++){
					printf("\n Thanh Vien Thu %d La: %s ",i+1,TenTV[i]);
					printf("\n Tuoi : %d",TuoiTV[i]);
				}
			}
				break;
			}
			case 2: {
				int i,
				SoLuongSo[8];
    		    printf("\n Nhap 8 so chia het cho 7:\n");
   			    for ( i = 0; i < 8; i++) {
        			do {
            			printf("Nhap so thu %d: ", i + 1);
           	 			scanf("%d", &SoLuongSo[i]);
            			if (SoLuongSo[i] % 7 != 0) {
               			    printf("So nhap vao khong chia het cho 7. Vui long nhap lai!\n");
            			}
        			} while (SoLuongSo[i] % 7 != 0);
    			}
    			printf("\nCac so da nhap:\n");
    				for (i = 0; i < 8; i++) {
        				printf("%d ", SoLuongSo[i]);
    				}
    				printf("\n");
				break;
			}
			case 3: {
				int SoLuongSinhVien;
				printf("\n Nhap So Luong Sinh Vien: ");
				scanf("%d",&SoLuongSinhVien);
				char TenSV[SoLuongSinhVien][100];
				int TuoiSV[SoLuongSinhVien];
				char  LopSV[SoLuongSinhVien][50];
				int i;
				if (SoLuongSinhVien <= 0){
					printf("\n So Luong Sinh Vien Bang Hoac Be Hon 0.");
				} else {
					for (i = 0;i < SoLuongSinhVien;i++){
						printf("\n Nhap HoTen Sinh Vien %d: ",i+1);
						scanf("%s",&TenSV[i]);
						printf("\n Nhap Tuoi Sinh Vien %d: ",i + 1);
						scanf("%d",&TuoiSV[i]);
						printf("\n Nhap Lop Sinh Vien %d: ",i + 1);
						scanf("%s",&LopSV[i]);
					}
					printf("\n So Luong Sinh Vien: %d",SoLuongSinhVien);
					for (i = 0;i < SoLuongSinhVien;i++){
						printf("\n Ten Sinh Vien Thu %d : %s",i+1,TenSV[i]);
						printf("\n Tuoi Sinh Vien Thu %d : %s",i+1,TuoiSV[i]);
						printf("\n Lop Sinh Vien Thu %d : %s",i+1,LopSV[i]);
					}
				}
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung.");
				break;
			}
			default: 
			printf("\n Ban Da Chon Sai Rui!");
			printf("\n Vui Long Chon Lai Nhe.");
		} 
		if (LuaChon != 0);
		printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc......");
		getchar();
		getchar();
	} while ( LuaChon != 0);
	return 0;
}
