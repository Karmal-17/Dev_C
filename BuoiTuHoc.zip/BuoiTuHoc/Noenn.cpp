#include <iostream>
#include <string>
#include <chrono>   // Thu vi?n d? t?o d? tr?
#include <thread>   // Thu vi?n d? s? d?ng h�m ng?

using namespace std;

// H�m hi?n th? ch? "I LOVE YOU" kh?ng l? tr�n m�n h�nh
void displayLargeText() {
    string text[] = {
        " IIIIIII   L         OOOOOO   V       V  EEEEEEE     Y   Y   OOOOOO   U     U",
        "    I      L        O      O   V     V   E             Y    O      O  U     U",
        "    I      L        O      O    V   V    EEEEE          Y   O      O  U     U",
        "    I      L        O      O     V V     E              Y   O      O  U     U",
        " IIIIIII   LLLLLL    OOOOOO       V      EEEEEEE        Y    OOOOOO    UUUUU"
    };

    for (string line : text) {
        cout << line << endl;
        this_thread::sleep_for(chrono::milliseconds(200)); // T?o d? tr? 200ms
    }
}

int main() {
    system("cls"); // X�a m�n h�nh tru?c khi hi?n th?
    displayLargeText();
    return 0;
}

