#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
void HienThiMeNu (){
	printf("\n ======= Hien Thi MeNu Chinh Cua Chuong Trinh =======");
	printf("\n + 1.Kiem Tra So Nguyen.                            +");
	printf("\n + 2.Tim Uoc Chung Va Boi So Chung Cua Hai So.      +");
	printf("\n + 3.Truong Trinh Tinh Ten Cho Quan Karaoke.        +");
	printf("\n + 4.Tinh Tien Dien.                                +");
	printf("\n + 5.Doi Tien.                                      +");
	printf("\n + 6.Tinh Lai Xuat Ngan Hang Vay Tra Gop.           +");
	printf("\n + 7.Vay Tien Mua Xe.                               +");
	printf("\n + 8.Sap Xep Th�ng Tin Sinh Vien.                   +");
	printf("\n + 9.Game Poly - Lott.                              +");
	printf("\n + 10.Tinh Phan So.                                 +");
	printf("\n + 0.Thoat Truong Trinh.                           +");
	printf("\n ====================================================");	
}

void HienThi1() {
    printf("\n ===== Kiem Tra So Nguyen ======");
    printf("\n + 1. Xac Dinh So Nguyen.       +");
    printf("\n + 2. Xac Dinh So Nguyen To.    +");
    printf("\n + 3. Xac Dinh So Chinh Phuong. +");
    printf("\n + 4. Xac Dinh Ca.              +");
    printf("\n + 0. Thoat Chuong Trinh.       +");
    printf("\n ===============================");
}
void SuLyHienThi1() {
    int LuaChon1;
    do {
        system("cls");
        HienThi1();
        printf("\n Nhap Lua Chon Cua Ban: ");
        scanf("%d", &LuaChon1);
        switch (LuaChon1) {
            case 1: { 
                printf("\n 1. Xac Dinh So Nguyen.");
                float a;
                printf("\n Vui Long Nhap So (Am Hoac Duong): ");
                scanf("%f", &a);
                if (a == (int)a) { // Ki?m tra n?u a l� s? nguy�n
                    if (a > 0) {
                        printf("\n So %d Ban Vua Nhap La So Nguyen Duong.", (int)a);
                    } else if (a == 0) {
                        printf("\n So %d Ban Vua Nhap La So Nguyen Khong Am.", (int)a);
                    } else {
                        printf("\n So %d Ban Vua Nhap La So Nguyen Am.", (int)a);
                    }
                } else {
                    printf("\n So Ban Vua Nhap Khong Phai La So Nguyen.");
                }
                break;
            }
            case 2: { 
                printf("\n 2. Xac Dinh So Nguyen To.");
                float a;
                int i, XacDinh = 1;
                printf("\n Nhap So Nguyen Can Kiem Tra: ");
                scanf("%f", &a);
                if (a != (int)a) { // Ki?m tra n?u a l� s? th?p ph�n
                    printf("\n So Vua Nhap Khong Phai La So Nguyen.");
                } else {
                    int n = (int)a; // Chuy?n v? ki?u int
                    if (n <= 1) {
                        XacDinh = 0;
                    } else {
                        for (i = 2; i <= sqrt(n); i++) {
                            if (n % i == 0) {
                                XacDinh = 0;
                                break;
                            }
                        }
                    }
                    if (XacDinh) {
                        printf("\n So %d Ban Vua Nhap La So Nguyen To.", n);
                    } else {
                        printf("\n So %d Ban Vua Nhap Khong Phai La So Nguyen To.", n);
                    }
                }
                break;
            }
            case 3: { 
                printf("\n 3. Xac Dinh So Chinh Phuong.");
                float a;
                printf("\n Nhap So Nguyen Can Kiem Tra: ");
                scanf("%f", &a);
                if (a != (int)a) { // Ki?m tra n?u a l� s? th?p ph�n
                    printf("\n So Vua Nhap Khong Phai La So Nguyen.");
                } else {
                    int n = (int)a;
                    if (n >= 0) {
                        int sqrtA = (int)sqrt(n);
                        if (sqrtA * sqrtA == n) {
                            printf("\n So %d Ban Vua Nhap La So Chinh Phuong.", n);
                        } else {
                            printf("\n So %d Ban Vua Nhap Khong Phai La So Chinh Phuong.", n);
                        }
                    } else {
                        printf("\n So %d Khong Phai So Chinh Phuong (Khong Ap Dung Cho So Am).", n);
                    }
                }
                break;
            }
            case 4: { 
                printf("\n 4. Xac Dinh Ca So Nguyen To Va So Chinh Phuong.");
                float a;
                printf("\n Nhap So Nguyen Can Kiem Tra: ");
                scanf("%f", &a);
                if (a != (int)a) { 
                    printf("\n So Vua Nhap Khong Phai La So Nguyen.");
                } else {
                    int n = (int)a;
                    int XacDinh = 1, i;
                    if (n <= 1) {
                        XacDinh = 0;
                    } else {
                        for (i = 2; i <= sqrt(n); i++) {
                            if (n % i == 0) {
                                XacDinh = 0;
                                break;
                            }
                        }
                    }
                    if (XacDinh) {
                        printf("\n So %d Ban Vua Nhap La So Nguyen To.", n);
                    } else {
                        printf("\n So %d Ban Vua Nhap Khong Phai La So Nguyen To.", n);
                    }
                    if (n >= 0) {
                        int sqrtA = (int)sqrt(n);
                        if (sqrtA * sqrtA == n) {
                            printf("\n So %d Ban Vua Nhap La So Chinh Phuong.", n);
                        } else {
                            printf("\n So %d Ban Vua Nhap Khong Phai La So Chinh Phuong.", n);
                        }
                    } else {
                        printf("\n So %d Khong Phai So Chinh Phuong (Khong Ap Dung Cho So Am).", n);
                    }
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Su Dung.");
                break;
            }
            default:
                printf("\n Chon Sai Roi! Vui Long Chon Lai Nhe.");
        }
        if (LuaChon1 != 0) {
            printf("\n Nhan Vao Phim Bat Ky De Tiep Tuc Chuong Trinh.......");
            getchar();
            getchar();
        }
    } while (LuaChon1 != 0);
} 

int main(){
	int LuaChon;
	do {
		system("cls");
		HienThiMeNu();
		printf("\n Nhap Lua Chuon Cua Ban: ");
	    scanf("%d",&LuaChon);
	    
	    switch(LuaChon){
	    	case 1: {
	    		SuLyHienThi1();
				break;
			}
			default: printf("LuahonSai");
		}
	} while (LuaChon != 0);
}
