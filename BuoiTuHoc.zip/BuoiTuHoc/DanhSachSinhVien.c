#include <stdio.h>
#include <string.h>

#define MAX 100

typedef struct {
    char hoTen[50];
    float diem;
    char hocLuc[20];
} SinhVien;

void quanLySinhVien() {
    SinhVien danhSach[MAX];
    int soLuong;
    printf("Nhap so luong sinh vien: ");
    scanf("%d", &soLuong);
    getchar();

    int i,j;
    for (i = 0; i < soLuong; i++) {
        printf("\nNhap thong tin sinh vien thu %d:\n", i + 1);
        printf("Ho ten: ");
        fgets(danhSach[i].hoTen, sizeof(danhSach[i].hoTen), stdin);
        danhSach[i].hoTen[strcspn(danhSach[i].hoTen, "\n")] = '\0'; 
        scanf("%f", danhSach[i].diem);
        getchar();

        if (danhSach[i].diem >= 9.0) {
            strcpy(danhSach[i].hocLuc, "Hoc luc xuat sac");
        } else if (danhSach[i].diem >= 8.0) {
            strcpy(danhSach[i].hocLuc, "Hoc luc gioi");
        } else if (danhSach[i].diem >= 6.5) {
            strcpy(danhSach[i].hocLuc, "Hoc luc kha");
        } else if (danhSach[i].diem >= 5.0) {
            strcpy(danhSach[i].hocLuc, "Hoc luc trung binh");
        } else {
            strcpy(danhSach[i].hocLuc, "Hoc luc yeu");
        }
    }
    for ( i = 0; i < soLuong - 1; i++) {
        for ( j = i + 1; j < soLuong; j++) {
            if (danhSach[i].diem < danhSach[j].diem) {
                SinhVien tam = danhSach[i];
                danhSach[i] = danhSach[j];
                danhSach[j] = tam;
            }
        }
    }

    printf("\nDanh sach sinh vien sau khi sap xep:\n");
    printf("%-30s %-10s %-20s\n", "Ho ten", "Diem", "Hoc luc");
    for ( i = 0; i < soLuong; i++) {
        printf("%-30s %-10.2f %-20s\n", danhSach[i].hoTen, danhSach[i].diem, danhSach[i].hocLuc);
    }
}

int main() {
    quanLySinhVien();
    return 0;
}

