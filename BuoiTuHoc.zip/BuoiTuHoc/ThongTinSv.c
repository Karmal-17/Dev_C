#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Khai b�o c?u tr�c sinh vi�n
typedef struct {
    char id[15];       // M� sinh vi�n
    char name[50];     // H? v� t�n
    int age;           // Tu?i
    float gpa;         // �i?m trung b�nh
} Student;

// H�m nh?p th�ng tin m?t sinh vi�n
void inputStudent(Student *s) {
    printf("\nNhap ma sinh vien: ");
    scanf("%s", s->id);
    printf("Nhap ho va ten: ");
    getchar(); // Lo?i b? k� t? xu?ng d�ng c�n l?i
    fgets(s->name, sizeof(s->name), stdin);
    s->name[strcspn(s->name, "\n")] = 0; // Lo?i b? k� t? xu?ng d�ng
    printf("Nhap tuoi: ");
    scanf("%d", &s->age);
    printf("Nhap GPA: ");
    scanf("%f", &s->gpa);
}

// H�m hi?n th? th�ng tin m?t sinh vi�n
void displayStudent(const Student *s) {
    printf("\nMa sinh vien: %s\n", s->id);
    printf("Ho va ten: %s\n", s->name);
    printf("Tuoi: %d\n", s->age);
    printf("GPA: %.2f\n", s->gpa);
}

// H�m t�m ki?m sinh vi�n theo m�
Student* searchStudentById(Student *students, int count, const char *id) {
	int i;
    for ( i = 0; i < count; i++) {
        if (strcmp(students[i].id, id) == 0) {
            return &students[i];
        }
    }
    return NULL; // Kh�ng t�m th?y
}

int main() {
    int n;
    printf("Nhap so luong sinh vien: ");
    scanf("%d", &n);

    // C?p ph�t b? nh? cho danh s�ch sinh vi�n
    Student *students = (Student *)malloc(n * sizeof(Student));
    if (students == NULL) {
        printf("Khong the cap phat bo nho!\n");
        return 1;
    }

    // Nh?p th�ng tin sinh vi�n
    int i;
    for ( i = 0; i < n; i++) {
        printf("\nNhap thong tin sinh vien thu %d:\n", i + 1);
        inputStudent(&students[i]);
    }

    // Hi?n th? danh s�ch sinh vi�n
    printf("\nDanh sach sinh vien:\n");
    for ( i = 0; i < n; i++) {
        printf("\nSinh vien thu %d:\n", i + 1);
        displayStudent(&students[i]);
    }

    // T�m ki?m sinh vi�n theo m�
    char searchId[15];
    printf("\nNhap ma sinh vien can tim: ");
    scanf("%s", searchId);
    Student *found = searchStudentById(students, n, searchId);
    if (found != NULL) {
        printf("\nThong tin sinh vien duoc tim thay:\n");
        displayStudent(found);
    } else {
        printf("\nKhong tim thay sinh vien voi ma: %s\n", searchId);
    }

    // Gi?i ph�ng b? nh?
    free(students);
    return 0;
}

