#include <stdio.h>
#include <string.h>
void HienThiMenu(){
	printf("\n +------------------Menu-----------------+");
	printf("\n + 1.Nhap Thong Tin Ca Nhan.             +");
	printf("\n + 2.Tinh Tong.                          +");
	printf("\n + 3.Thong Tin Sinh Vien Cac Lop.        +");
	printf("\n + 0.Thoat Chuong Trinh.                 +");
	printf("\n +---------------------------------------+");
	printf("\n Moi Ban Chon So: ");
}

void HienThi1(){
	printf("\n Thong Tin Ca Nhan.");
	char Ten[100];
	printf("\n Nhap Ho Va Ten Cua Ban: ");
	gets(Ten);
	int Tuoi;
	printf("\n Tuoi Cua Ban: ");
	scanf("%d",&Tuoi);
	getchar();
	char DiaChi[100];
	printf("\n Nhap Dia Chi Cua Ban: ");
	gets(DiaChi);
	int HocKy;
	printf("\n Hoc Ky Cua Ban: ");
	scanf("%d",&HocKy);
	getchar();
	char ChuyenNganh[100];
	printf("\n Chuyen Nganh Cua Ban: ");
	gets(ChuyenNganh);
	
	printf("\n Hien Thi Thong Tin Ca Nhan.");
	printf("\n Ho Va Ten: %s",Ten);
	printf("\n Tuoi: %d",Tuoi);
	printf("\n Dia Chi: %s",DiaChi);
	printf("\n Hoc Ky: %d",HocKy);
	printf("\n Chuyen Nganh: %s",ChuyenNganh);
}

void HienThi2(){
	printf("\n Trang Tinh Tong.");
	int n;
	printf("\n Vui Long Nhap So Nguyen n: ");
	scanf("%d",&n);
	int i;
	int Tong = 0;
	for ( i = 0;i <= n; i++){
		Tong += i;
	}
	printf("\n Tong Cac So Tu 1 Den %d La: %d",n,Tong);
}

void HienThi3(){
	printf("\n Thong Tin Lop Hoc.");
	int SoLuongLop;
	printf("\n Vui Long Nhap So Luong Lop Hoc: ");
	scanf("%d",&SoLuongLop);
	getchar();
	char Ten[SoLuongLop][100];
	int SoLuongSinhVien[SoLuongLop];
	int i;
	if (SoLuongLop <= 0){
		printf("\n So Luong Lop Ban Vua Nhap Be Hon Hoac Bang 0.");
		printf("\n Vui Long Chon Va Nhap Lai!");
	} else {
		for (i = 0;i<SoLuongLop ; i++){
			printf("\n Nhap Ten Lop Thu %d La:  ",i+1);
			gets(Ten[i]);
			printf("\n So Luong Sinh Vien Cua Lop %s La:  ",Ten[i]);
			scanf("%d",&SoLuongSinhVien[i]);
			getchar();
		}
		int Min = SoLuongSinhVien[0];
		int ViTri = 0;
		for (i = 0; i <SoLuongLop; i++){
			if (SoLuongSinhVien[i] < Min){
				Min = SoLuongSinhVien[i];
				ViTri = i;
			}
		}
		for (i = 0; i < SoLuongLop; i++){
			printf("\n Ten Lop Thu %d La: %s (SoLuongSV : %d) \n ",i+1,Ten[i],SoLuongSinhVien[i]);
		}
		printf("\n Ten Lop Co So Luong Sinh Vien It Nhat Thu  La: %s (SoLuongSV: %d) \n ",Ten[ViTri], Min);
		
		int Dem = 0;
		printf("\n Ten ");
		for (i = 0;i < SoLuongLop; i++){
			if (SoLuongSinhVien[i] < 30){
				printf("\n Ten Lop Thu %d La: %s (SoLuongSV: %d)",i+1,Ten[i],SoLuongSinhVien[i]);
				Dem = 1;
			}
		}
		if (Dem == 0){
			printf("\n So Lop Ban Vua Nhap Chua Co  Lop Nao Co So Luong Sinh Vien Be Hon 30.");
		}
	}
}
int main (){
	int LuaChon;
	do {
		system("cls");
		HienThiMenu();
		scanf("%d",&LuaChon);
		getchar();
		switch(LuaChon){
			case 1: {
				HienThi1();
				break;
			}
			case 2: {
				HienThi2();
				break;
			}
			case 3: {
				HienThi3();
				break;
			}
			case 0: {
				printf("\n Thoat Chuong Trinh.");
				printf("\n Cam On Ban Da Su Dung Trang Tinh.");
				break;
			}
			default: 
			printf("\n Ban Da Chon Sai So Rui!");
			printf("\n Vui Long Chon Lai Nhe.");
		} 
		if (LuaChon != 0){
			printf("\n Nhan Mot Phim Bat Ky De Tiep Tuc Nhe.....");
			getchar();
			getchar();
		}
	} while (LuaChon != 0);
}
