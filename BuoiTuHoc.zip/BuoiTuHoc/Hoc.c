#include <stdio.h>

int main(){
	printf("Hello Word!");
	printf("\n Ten: Nghiep");
	printf("\n Tuoi: 16");
	printf("\n Dia Chi: TDP Kieu, TT.Bich Dong, TX.Viet Yen, TP. Bac Giang.");
	int a,b;
	printf("\n Vui Long Nhap So a = ");
	scanf("%d",&a);
	printf("\n Vui Long Nhap So b = ");
	scanf("%d",&b);
	int Tong = a + b;
	int Tru = a - b;
	int Tich = a * b;
	float Chia = a / (float)b;
	printf("\n Tong Cua A Va B La: %d",Tong);
	printf("\n Hieu Cua A Va B La: %d",Tru);
	printf("\n Tich Cua A Va B La: %d",Tich);
	printf("\n Chia Cua A Va B La: %.2f",Chia);
	return 0;
}
