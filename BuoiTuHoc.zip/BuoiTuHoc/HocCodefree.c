#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <complex.h>
void HienThi(){
    printf("\n +--------- Menu ---------+");
    printf("\n 1. Cac Phep Tinh Ca Ban.");
    printf("\n 2. Cac Phep Tinh Nang Cao.");
    printf("\n 3. Thong Tin Ca Nhan.");
    printf("\n 4. Thong Tin Ve Sinh Vien Cua 1 Lop.");
    printf("\n 5. Cac Bai Toan Thuc Te.");
    printf("\n 0. Thoat Chuong Trinh.");
    printf("\n +------------------------+");
    printf("\n Vui Long Chon So Ban Muon Nhe: ");
}
void HienThi1(){
    printf("\n +--------- Phep Tinh Co Ban ---------+");
    printf("\n 1. Phep Tinh Cong.");
    printf("\n 2. Phep Tinh Tru.");
    printf("\n 3. Phep Tinh Nhan.");
    printf("\n 4. Phep Tinh Chia.");
    printf("\n 0. Thoat Chuong Trinh.");
    printf("\n +------------------------------------+");
    printf("\n Vui Long Chon So Ban Muon Nhe: ");
}
void HienThi1Y1(){
    printf("\n +---- Phep Tinh Cong ----+");
    printf("\n 1. Phep Tinh Cong Hai So.");
    printf("\n 2. Phep Tinh Cong Ba So.");
    printf("\n 3. Phep Tinh Cong Nhieu So.");
    printf("\n 0. Thoat Chuong Trinh.");
    printf("\n +------------------------+");
    printf("\n Vui Long Chon So: ");
}
void SuLyHienThi1Y1(){
    int LuaChon1Y1;
    do {
        system("cls");
        HienThi1Y1();
        scanf("%d",&LuaChon1Y1);
        switch(LuaChon1Y1){
            case 1: {
                printf("\n Phep Tinh Cong Hai So.");
                int a,b,Tong = 0;
                printf("\n Vui Long Nhap So Thu Nhat: ");
                scanf("%d",&a);
                printf("\n Vui Long Nhap So Thu Hai: ");
                scanf("%d",&b);
                printf("\n Ket Qua Cua Phep Tinh Cong.");
                Tong = a + b;
                printf("\n %d + %d = %d",a,b,Tong);
                break;
            }
            case 2: {
                printf("\n Phep Tinh Cong Ba So.");
                int a,b,c,Tong;
                printf("\n Vui Long Nhap So Thu Nhat: ");
                scanf("%d",&a);
                printf("\n Vui Long Nhap So Thu Hai: ");
                scanf("%d",&b);
                printf("\n Vui LOng Nhap So Thu Ba: ");
                scanf("%d",&c);
                Tong = a + b + c;
                printf("\n Ket Qua Cua Phep Cong.");
                printf("\n %d + %d + %d = %d",a,b,c,Tong);
                break;
            }
            case 3: {
                printf("\n Phep Tinh Cong Nhieu So.");
                int i,n,Tong = 0;
                printf("\n Vui LOng NHap So Luong So Ban Muon: ");
                scanf("%d",&n);
                if (n <= 0){
                    printf("\n So Ban Vua Nhap Be Hon Hoac Bang 0");
                    printf("\n Vui Long Chon Va Nhap Lai So Nhe.");
                } else {
                    for (i = 0; i <= 0; i++){
                        printf("\n Vui Long Nhap So Thu %d La: ",i +1);
                        scanf("%d",&i);
                    }
                    for (i = 0; i <= n; i++){
                        Tong += i;
                    }
                    printf("\n Ket Qua Phep Cong %d So La: %d",n,Tong);
                    
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Su Dung Trang Tinh.");
            }
            default :
            printf("\n Ban Da Chon Sai So Roi!");
            printf("\n Vui Long Chon Lai So Nhe.");
        } 
        if (LuaChon1Y1 != 0){
            printf("\n Nhan Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong TRinh Nhe.....");
            getchar();
            getchar();
        }
    } while (LuaChon1Y1 != 0);
}
void HienThi1Y2(){
    printf("\n +----- Phep Tinh Tru -----+");
    printf("\n 1. Phep Tinh TRu Hai So.");
    printf("\n 2. Phep Tinh Tru Ba So.");
    printf("\n 3. Phep Tinh Tru Nhieu So.");
    printf("\n 0.  Thoat Chuong Trinh.")
    printf("\n +------------------------+");
    printf("\n Vui Long Chon So Ban Muon Nhe: ");
} 
void SuLyHienThi1Y2(){
    int LuaChon1Y2;
    do {
        system("cls");
        HienThi1Y2();
        scanf("%d",&LuaChon1Y2);
        switch(LuaChon1Y2){
            case 1: {
                printf("\n Phep Tinh Tru Hai So.");
                int a,b,Hieu;
                printf("\n Vui Long Nhap So Thu Nhat: ");
                scanf("%d",&a);
                printf("\n Vui Long Nhap So Thu Hai: ");
                scanf("%d",&b);
                Hieu = a - b;
                printf("\n Ket Qua Cua Phep Tru.");
                printf("\n %d - %d = %d",a,b,Hieu);
                break;
            } 
            case 2: {
                printf("\n Phep Tinh Tru Ba So.");
                int a,b,c,Hieu;
                printf("\n Vui Long Nhap So Thu Nhat: ");
                scanf("%d",&a);
                printf("\n Vui Long Nhap So Thu Hai: ");
                scanf("%d",&b);
                printf("\n Vui Long Nhap So Thu Ba: ");
                scanf("%d",&c);
                Hieu = a - b - c;
                printf("\n Ket Qua Cua Phep Tru.");
                printf("\n %d - %d - %d = %d",a,b,c,Hieu);
                break;
            }
            case 3: {
                printf("\n Phep Tinh Tru Nhieu So.");
                int i,n,Hieu;
                printf("\n Vui LOng Nhap So Luong So Ban Muon Tru: ");
                scanf("%d",&n);
                if(n <= 0){
                    printf("\n So Ban Vua NHap Be Hon Hoac Bang 0");
                    printf("\n Vui Long Chon Va Nhap Lai So Nhe.");
                } else {
                    for (i = 0 ; i <= n; i++){
                        printf("\n Vui Long Nhap So Thu %d La: ",i +1);
                        scanf("%d",&i);
                    }
                    for(i = 0; i <= n; i ++){
                        Hieu -= i;
                    }
                    printf("\n Ket Qua Phep Tinh Tru %d So La: %d",n,Hieu);
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ba Da Su Dung Trang Tinh.");
                break;
            }
            default:
            printf("\n Ban Da Chon Sai So Roi!");
            printf("\n Vui LOng Chon Lai So Nhe.");
        }
        if (LuaChon1Y2 != 0){
            printf("\N Nhan Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Nhe....");
            getchar();
            getchar();
        }
    } while (LuaChon1Y2 != 0);
}
void HienThi1Y3(){
    printf("\n +----- Phep Tinh Nhan -----+");
    printf("\n 1. Phep Tinh Nhan Hai So.");
    printf("\n 2. Phep Tinh Nhan Ba So.");
    printf("\n 3. Phep Tinh Nhan Nhieu So.");
    printf("\n 0. Thoat Chuong Trinh.");
    printf("\n +--------------------------+");
    printf("\n Vui Lng Chon So Ban Muon Nhe: ");
} 
void SuLyHienThi1Y3(){
    int LuaChon1Y3;
    do {
        system("cls");
        HienThi1Y3();
        scanf("%d",&LuaChon1Y3);
        switch(LuaChon1Y3){
            case 1: {
                printf("\n Phep Tinh NHan Hai So.");
                int a,b,Nhan;
                printf("\n Vui Long Nhap So Thu Nhat: ");
                scanf("%d",&a);
                printf("\n Vui Long Nhap So Thu Hai: ");
                scanf("%d",&b);
                Nhan = a * b;
                printf("\n Ket Qua Cua Phep Nhan.");
                printf("\n %d * %d = %d",a,b,Nhan);
                break;
            }
            case 2: {
                printf("\n Phep Tinh Nhan Ba So.");
                int a,b,c,Nhan;
                printf("\n Vui Long Nhap So Thu Nhat: ");
                scanf("%d",&a);
                printf("\n Vui Long Nhap So Thu Hai: ");
                scanf("%d",&b);
                printf("\n Vui Long Nhap So Thu Ba: ");
                scanf("%d",&c);
                Nhan = a * b * c;
                printf("\n Ket Qua Cua Phep Nhan.");
                printf("\n %d * %d * %d = %d",a,b,c,Nhan);
                break;
            }
            case 3: {
                printf("\n Phep Tinh NHan Nhieu So.");
                int i,n,Nhan;
                printf("\n Vui Long Nhap So Luong So Ban Muon Nhan: ");
                scanf("%d",&n);
                if (n <= 0){
                    printf("\n So Ban Vua Nhap Be Hon Hoac Bang 0.");
                } else {
                    for (i = 0;i <= n; i ++){
                        printf("\n Vui Long Nhap So Thu %d La: ",i + 1);
                        scanf("%d",&i);
                    }
                    for (i = 0; i <= n; i ++){
                        Nhan *= i;
                    }
                    printf("\n Ket Qua Cua Phep Nhan %d So La: %d",n,Nhan);
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Su Dung Trang Tinh.");
            }
            default:
            printf("\n Ban Da Nhap Sai So Roi!");
            printf("\n Vui Long Chon Lai So Nhe.");
        }
        if (LuaChon1Y3 != 0){
            printf("\n Vui LOng Nhan Vao Phim Bat Ky TRen Ban Phim De Tiep Tuc Chuong TRinh Nhe.....");
            getchar();
            getchar();
        }
    } while (LuaChon1Y3 != 0);
}
void HienThi1Y4(){
    printf("\n +------ Phep Tinh Chia ------+");
    printf("\n 1. Phep Chia Hai So.");
    printf("\n 2. Phep Chia Ba So.");
    printf("\n 3. Phep Tinh Chia Nhieu So.");
    printf("\n 0. Thoat Chuong Trinh.");
    printf("\n +----------------------------+");
    printf("\n Vui Long Chon So Ban Muon Nhe: ");
}
void SuLyHienThi1Y4(){
    int LuaChon1Y4;
    do {
        system("cls");
        HienThi1Y4();
        scanf("%d",&LuaChon1Y4);
        switch(LuaChon1Y4){
            case 1: {
                printf("\n Phep Tinh Chia Hai So.");
                int a,b,Chia;
                printf("\n Vui Long NHap So Thu Nhat: ");
                scanf("%d",&a);
                printf("\n Vui LOng Nhap So Thu Hai: ");
                scanf("%d",&b);
                Chia = a / b;
                printf("\n Ket Qua Cua Phep Chia.");
                printf("\n %d / %d = %d",a,b,Chia);
                break;
            }
            case 2: {
                printf("\n Phep Tinh Chia Ba So.");
                int a,b,c;
                printf("\n Vui Long Nhap So Thu Nhat: ");
                scanf("%d",&a);
                printf("\n Vui Long Nhap So Thu Hai: ");
                scanf("%d",&b);
                printf("\n Vui Long NHap So Thu Ba: ");
                scanf("%d",&c);
                float Chia = a / (float)b / (float)c;
                printf("\n Ket Qua Cua Phep Tinh Chia.");
                printf("\n %d / %d / %d = %d ",a,b,c,Chia);
                break;
            }
            case 3: {
                printf("\n Phep Chia Nhieu So.");
                int i,n;
                float Chia;
                printf("\n Vui Long Nhap So Luong So Ban Muon Chia: ");
                scanf("%d",&n);
                if (n <= 0){
                    printf("\n So Ban Vua NHap Be Hon Hoac Bang 0");
                    printf("\n Vui Long Chon So Va Nhap Lai Nhe.");
                } else {
                    for (i = 0; i <= n; i++){
                        printf("\n  Vui Long Nhap So Thu %d La: ",i + 1);
                        scanf("%d",&i);
                    }
                    for (i = 0; i <= n; i ++){
                        Chia /= (float)i;
                    }
                    printf("\n Ket Qua Cua Phep Tinh Chia %d So La: %d ",n,Chia);
                }
                break;
            }
            case 0: {
                printf("\n Thoat Chuong TRinh.");
                printf("\n Cam On Ban Da Su Dung Chuong Trinh Tinh.");
            }
            default: 
            printf("\n Ba Da Chon Sai So Roi!");
            printf("\n Vui LOng Chon Lai So Nhe.");
        }
        if(LuaChon1Y4 != 0){
            printf("\n Nhan Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong TRing Nhe.......");
            getchar();
            getchar();
        }
    } while (LuaChon1Y4 != 0);
}
void HienThi2(){
    printf("\n +------- Phep Tinh Nang Cao -------+");
    printf("\n 1. Phuong Trinh Bac Nhat.");
    printf("\n 2. Phuong Trinh Bac Hai.");
    printf("\n 3. Phuong Trinh Bac Ba.");
    printf("\n 4. Phuong Trinh Bac Bon.");
    printf("\n 5. Phuong TRinh Bac Nam.");
    printf("\n 6. Phep Tinh Luy Thua.");
    printf("\n 7. Phep Tinh Can Bac Hai.");
    printf("\n 8. Phep Tinh Can Bac Ba.");
    printf("\n 9. Phep Tinh Gia Tri Tuyet Doi.");
    printf("\n 10. Phep Tinh Xac Dinh So Nguyen.");
    printf("\n 11. Phep Tinh Xac Dinh So Chan,Le.");
    printf("\n 0.  Thoat Chuong Trinh.");
    printf("\n +---------------------------------+");
    printf("\n Vui Long Chon So Ban Muon: ");
}
void SuLyHienThi2(){
    int LuaChon2;
    do {
        system("cls");
        HienThi2();
        scanf("%d",&LuaChon2);
        switch(LuaChon2){
            case 1: {
                printf("\n Phuong Trinh bac Nhat");
                float a,b,x;
                printf("\n Vui Long Nhap So Thu NHat: ");
                scanf("%f",&a);
                printf("\n Vui Long Nhap So Thu Hai: ");
                scanf("%f",&b);
                x = - b / a;
                if (a == 0){
                    if (b == 0){
                        printf("\n Phuong Trinh: %.2f * x + %.2f = 0",a,b);
                        printf("\n Co Hai Nghiem Phan Biet.");
                    } else {
                        printf("\n Phuong Trinh: %.2f * x + %.2f = 0",a,b);
                        printf("\n Vo Nhiem.");
                    }
                } else {
                    printf("\n Phuong Trinh: %.2f * x + %.2f = 0",a,b);
                    printf("\n Co Nghiem Duy Nhat: x = %.2f",x);
                }
                break;
            }
            case 2: {
                printf("\n Phuong Trinh Bac Hai.");
                float a,b,c;
                float x,x1,x2,Delta,x3;
                printf("\n Vui Long Nhap So Thu Nhat: ");
                scanf("%f",&a);
                printf("\n Vui LOng Nhap So Thu Hai: ");
                scanf("%f",&b);
                printf("\n Vui LOng Nhap So Thu Ba: ");
                scanf("%f",&c);
                if(a == 0){
                    if (b == 0){
                        if (c == 0){
                            printf("\n Phuong Trinh %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c);
                            printf("\n Co Vo So Nghiem.");
                        }
                        else {
                            printf("\n Phuong Trinh %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c);
                            printf("\n Vo Nghiem.");
                        }
                    } else {
                        printf("\n Phuong Trinh %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c);
                        x = - c / b;
                        printf("\n Co Nghiep Duy Nhat: x = %.2f"x);
                    }
                } else {
                    Delta = b * b - 4 * a * c;
                    x1 = (- b + sqrt(Delta)) / 2 * a;
                    x2 = (- b - sqrt(Delta)) / 2 * a;
                    if (Delta > 0){
                        printf("\n Phuong Trinh %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c);
                        printf("\n Phuong Trinh Co Hai Nghiem Phan Biet.");
                        printf("\n x1 = %.2f",x1);
                        printf("\n x2 = %.2f",x2);
                    } else {
                        if (Delta == 0){
                            x3 = - b / 2 * a;
                            printf("\n Phuong Trinh %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c);
                            printf("\n Phuong Trinh Co Nghiem Kep");
                            printf("\n x1 = x2 = %.2f",x3);
                        } else {
                            printf("\n Phuong Trinh %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c);
                            printf("\n Phuong Trinh Vo Nghiem.");
                        }
                    }
                }
                break;
            } 
            case 3:{
                printf("\n Phuong Trinh Bac Ba."); 
                float a,b,c,d;
                printf("\n Vui Long Nhap So Thu Nhat: ");
                scanf("%f",&a);
                printf("\n Vui Long Nhap So Thu Hai: ");
                scanf("%f",&b);
                printf("\n Vui Long Nhap So Thu Ba: ");
                scanf("%f",&c);
                printf("\n Vui Long Nhap So Thu Tu: ");
                scanf("%f",&d);
                printf("\n Phuong Trinh Ban Vua Nhap: %.2f * x^3 + %.2f * x^2 + %.2f * x + %.2f = 0",a,b,c,d);
                float x1,x2,x3,Delta;
                if(a == 0){
                    if (b == 0){
                        if (c == 0){
                            if (d == 0){
                                printf("\n Phuong Trinh Co Vo So Nghiem.");
                            } else {
                                printf("\n Phuong Trinh Vo Nghiem.")
                            }
                        } else {
                            printf("\n Phuong Trinh Co Nghiem Duy Nhat.");
                            x = - d / c ;
                            printf("\n x = %.2f",x);
                        }
                    } else {
                        Delta1 = c * c - 4 * b * d;
                        x1 = (- c + sqrt(Delta)) / 2 * b;
                        x2 = (- c - sqrt(Delta)) / 2 * b;
                        if (Deltal > 0){
                            printf("\n Phuong Trinh Co Hai Nghiem Phan Biet.");
                            printf("\n x1 = %.2f",x1);
                            printf("\n x2 = %.2f",x2);
                        } else {
                            if (Delta == 0){
                                printf("\n Phuong Trinh Co Nghiem Kep.");
                                x3 = - c / 2 * b;
                                printf("\n x1 = x2 = %.2f",x3);
                            } else {
                                printf("\n Phuong Trinh Vo Nghiem.");
                            }
                        }
                    }
                } else {
                    float u,p,q,v,y1,y2,y3,Delta1;
                    p = (3 * a * c - b * b) / (3 * a * a);
                    q = (2 * b * b * b - 9 * a * b * c + 27 * a * a * d) / (27 * a * a * a);
                    Delta1 = pow(q / 2 , 2) + pow(p / 3 , 3);
                    if (Delta1 > 0){
                        u = cbrt(- q / 2 + sqrt(Delta1));
                        v = cbrt(- p / 2 + sqrt(Delta1));
                        y1 = u + v - b / (3 * a);
                        printf("\n Nghiem Thuc Cua Phuong Trinh La: ");
                        printf("\ x1 = %.3f",y1);
                    } else {
                        if (Delta1 == 0){
                            u = cbrt(- q / 2);
                            y1 = 2 * u - b / (3 * a);
                            y2 = - u - b / (3 * a);
                            printf("\n Phuong Trinh Co Nghiem Kep:");
                            printf("\n Nghiem Kep: x1 = %.3f",y1);
                            printf("\n Nghiem Don: x2 = %.3f",y2);
                        } else {
                            float r,phi;
                            r = sqrt(- pow(p / 3 , 3));
                            phi = acos(- q / (2 * r));
                            y1 = 2 * cbrt(r) * cos(phi / 3) - b / (3 * a);
                            y2 = 2 * cbrt(r) * cos((phi + 2 * M_PI) / 3) - b / (3 * a);
                            y3 = 2 * cbrt(r) * cos((phi + 4 * M_PI) / 3) - b / (3 * a);
                            printf("\n Phuong Trinh Co Ba Nghiem Phan Biet:");
                            printf("\n x1 = %.3f",y1);
                            printf("\n x2 = %.3f",y2);
                            printf("\n x3 = %.3f",y3);
                        }
                    }
                }
                break;
            }
            case 4: {
                printf("\n Phuong Trinh Bac Bon.");
                brekk;
            }
            case 5: {
            	printf("\n Phuong Trinh Bac Nam");
                break;
            }
            case 6: {
                break;
            }
            case 7: {
                break;
            }
            case 8: {
                break;
            }
            case 9: {
                break;
            }
            case 10: {
                break;
            }
            case 11: {
            	printf("\n Phep Tinh Xac Dinh So Chan So Le.");
            	float a;
            	printf("\n Vui Long Nhap So Ban Muon: ");
            	scanf("\n ")
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Su Dung Trang Tinh.");
            }
            default: 
            printf("\n Ban Da Chon Sai So Roi!");
            printf("\n Vui Long Chon Lai So Nhe.");
        }
        if (LuaChon2 != 0){
            printf("\n Vui Long Nhan Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Nhe....");
            getchar();
            getchar();
        }
    } while (LuaChon2 != 0);
}
void SuLyHienThi3(){
    char Ten[100];
    char Ho[100];
    int Tuoi;
    int NamSinh;
    char DiaChi[100];
    char TenNuoc[100];
    char TenTP[100];
    getchar();
    printf("\n Vui Long Nhap Ten Cua Ban: ");
    fgets(Ten,sizeof(Ten),stdin);
    Ten(strcspn[Ten,"\0"]) = 0;
    printf("\n Vui Long Nhap Ho Cua Ban: ");
    fgets(Ho,sizeof(Ho),stdin);
    Ho(strcspn[Ho,"\n"]) = 0;
    printf("\n Vui Long Nhap Tuoi Cua Ban: ");
    scanf("%d",&Tuoi);
    printf("\n Vui Long Nhap Nam Sinh Cua Ban: ");
    scanf("%d",&NamSinh);
    getchar();
    printf("\n Vui Long Nhap Dia Chi Cua Ban: ");
    fgets(DiaChi,sizeof(DiaChi),stdin);
    DiaChi(strcspn[DiaChi,"\n"]) = "\0";
    printf("\n Vui Long Nhap Ten Nuoc Cua Ban: ");
    fgets(TenNuoc,sizeof(TenNuoc),stdin);
    TenNuoc(strcspn[TenNuoc,"\n"]) = "\0";
    printf("\n Vui Long Nhap  Ten Thanh Pho Cua Ban: ");
    fgets(TenTP,sizeof(TenTP),stdin);
    TenTP(strcspn[TenTP,"\n"]) = "\0";
    printf("\n \n \n");
    printf("\n Ho Va Ten Cua Ban La: %s",strcat(Ho,Ten));
    printf("\n Nam Sinh: %d",NamSinh);
    printf("\n Tuoi: %d",Tuoi);
    printf("\n Dia Chi: %s",DiaChi);
    printf("\n Ten Thanh Pho: %s",TenTP);
    printf("\n Ten Nuoc: %s",TenNuoc);
}

void SuLyHienThi1(){
    int LuaChon1;
    do {
        system("cls");
        HienThi1();
        scanf("%d",&LuaChon1);
        switch(LuaChon1){
            case 1: {
                SuLyHienThi1Y1();
                break;
            }
            case 2: {
                SuLyHienThi1Y2();
                break;
            }
            case 3: {
                SuLyHienThi1Y3();
                break;
            }
            case 4: {
                SuLyHienThi1Y4();
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Su Dung Trang Tinh Nhe.");
            }
            default: 
            printf("\n Ban Da Chon Sai So Roi!");
            printf("\n Vui LOng Cho Lai So Nhe.");
        }
        if (LuaChon1 != 0){
            printf("\n Nhan Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Nhe.....");
            getchar();
            getchar();
        }
    } while (LuaChon1 != 0);
}
void SuLyHienThi4(){
    printf("\n +------ Nhap Tonh Tin Sinh Vien Cua Mot Lop ------+");
    int SoLuong;
    printf("\n Vui Long Nhap So Luong Sinh Vien: ");
    scanf("%d",&SoLuong);
    
}
void HienThi5(){
    printf("\n +------- Cac Bai Toan Thuc Te -------+");
    printf("\n 1. Tinh Tien Dien.");
    printf("\n 2. Doi Tien.");
    printf("\n 3. Tinh Tien Quan Karaoke.");
    printf("\n 4. Tinh Tien Xe Taxi.");
    printf("\n 5. Tinh Lai Xuat Ngan Hang.");
    printf("\n 6. Vay Tien Mua Xe.");
    printf("\n 7. Tro Choi Game Poly Lot.");
    printf("\n 0. Thoat Chuong Trinh.");
    printf("\n +-------------------------------------+");
    printf("\n Vui Long Chon So Ban Muon: ");
}
void SuLyHienThi5(){
    int LuaChon5;
    do {
        system("cls");
        HienThi5();
        scanf("%d",&LuaChon5);
        switch(LuaChon5){
            case 1: {
                break;
            }
            case 2: {
                break;
            }
            case 3: {
                break;
            }
            case 4: {
                break;
            }
            case 5: {
                break;
            }
            case 6: {
                break;
            }
            case 7: {
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Su Dung Chuong Trinh.");
                break;
            }
            default:
            printf("\n Ban Da Chon Sai So Roi!");
            printf("\n Vui Long Chon Lai So Nhe.");
        }
        if(LuaChon5 != 0){
            printf("\n Vui Long Nhan Vao Phim Bat Ky Tren Ban Phim De Tiep Tuc Chuong Trinh Nhe.....");
            getchar();
            getchar();
        }
    } while (LuaChon5 != 0);
}
void SuLyHienthi(){
    int LuaChon;
    do {
        system("cls");
        HienThi();
        scanf("%d",&LuaChon);
        switch(LuaChon){
            case 1: {
                SuLyHienThi1();
                break;
            }
            case 2: {
                SuLyHienThi2();
                break;
            }
            case 3: {
                SuLyHienThi3();
                break;
            }
            case 4: {
                SuLyHienThi4();
                break;
            }
            case 5: {
                SuLyHienThi5();
                break;
            }
            case 0: {
                printf("\n Thoat Chuong Trinh.");
                printf("\n Cam On Ban Da Su Dung Chuong Trinh.");
                break;
            }
            default: 
            printf("\n Ban Da Nhap Sai So Roi!");
            printf("\n Vui Long Nhap Lai So Nhe.");
        } 
        if (LuaChon != 0){
            printf("\n Nhap Vao Phim Bat Ky De Tiep Tuc Chuong Trinh.");
            getchar();
            getchar();
        }
    } while (LuaChon != 0);
}
int main()
{
    char Khoa[] = "Key123";
    char NhapKhoa[50];
    printf("\n Vui Long Nhap Mat Khau: ");
    while (1){
        fgets(NhapKhoa,sizeof(NhapKhoa),stdin);
        NhapKhoa(strcspn[NhapKhoa, "\0"]) = 0;
        if (strstr(NhapKhoa,Khoa)){
            printf("\n Da Mo Khoa. ");
        } else {
            printf("\n Ban Da Nhap Khoa Sai Roi! Vui Long Nhap Lai Nhe: ");
        }
    }

    return 0;
}
