#include <stdio.h>

int main() {
    printf("  IIIIIIIIII         LL           OOOOOOO   V        V   EEEEEEEEE        Y    Y   OOOOOOO    UU       UU\n");
    printf("      II             LL          O       O   V      V    EE                Y  Y   O       O   UU       UU\n");
    printf("      II             LL          O       O    V    V     EEEEEE             YY    O       O   UU       UU\n");
    printf("      II             LL          O       O     V  V      EE                 YY    O       O   UU       UU\n");
    printf("  IIIIIIIIII         LLLLLLL     OOOOOOOOO      VV       EEEEEEEEE          YY     OOOOOOO     UUUUUUUUU\n");
    return 0;
}

