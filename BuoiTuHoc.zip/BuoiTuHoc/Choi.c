#include <stdio.h>

int main(){
	printf("\n HH       HH     OOOOOOOOO      MMM              MMM                     NN         NN        AAAA       YY        YY               ");
	printf("\n HH       HH    OO        OO    MMMM            MMMM                     NNNN       NN       AAAAAA       YY      YY              ");
	printf("\n HH       HH  OOO          OOO  MM MM          MM MM                     NNNNN      NN      AA    AA       YY    YY                  ");
	printf("\n HH       HH  OO            OO  MM  MM        MM  MM                     NN  NN     NN     AA      AA       YY  YY                    ");
	printf("\n HHHHHHHHHHH  OO            OO  MM   MM      MM   MM                     NN   NN    NN    AA        AA       YYYY                        ");
	printf("\n HHHHHHHHHHH  OO            OO  MM    MMMMMMM     MM                    NN    NN   NN   AA          AA       YY                          ");
	printf("\n HH       HH  OO            OO  MM     MMMMM      MM                     NN     NN  NN  AAAAAAAAAAAAAAAA      YY                           ");
	printf("\n HH       HH  OOO          OOO  MM                MM                     NN      NN NN  AAAAAAAAAAAAAAAA      YY                              ");
	printf("\n HH       HH    OO        OO    MM                MM                     NN       NNNN  AA            AA      YY                                       ");
	printf("\n HH       HH     OOOOOOOOO      MM                MM                     NN         NN  AA            AA      YY                                      ");

	printf("\n         11111               ");
	printf("\n       1111111             ");
	printf("\n     1111  111                                     ");
	printf("\n    111    111                   "); 
	printf("\n   111     111                              ");
	printf("\n           111                                  ");
	printf("\n           111                                         ");
	printf("\n           111                           ");
	printf("\n           111                                           ");
}
