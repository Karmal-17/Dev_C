#include <stdio.h>
#include <string.h>

int main(){
	char str[20];
	printf("\n Nhap Gia Tri Chuoi : ");
	gets(str);
	printf("\n Chuoi Da Nhap La: %s",str);
	// Chuoi In Ra Chu Thuong Strlwr(str)
	printf("\n Chuoi Chu Thuong La: %s",strlwr(str));
	// Chuoi In Ra Chu In Hoa Strupr(str)
	printf("\n Chuoi Chu In Hoa La: %s",strupr(str));
	
	return 0;
}
