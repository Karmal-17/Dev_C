#include <stdio.h>
#include <string.h>

int main() {
    char str[150];
    int i, nguyenam = 0; // Declare variables properly
    
    printf("\n Nhap Gia Tri Chuoi: ");
    gets(str); // Accept input from the user (but note: gets() is unsafe; use fgets() instead)

    for (i = 0; str[i] != '\0'; i++) { // Use a proper loop to iterate through the string
        // Check for vowels (nguyen am) in a cleaner way
        if (str[i] == 'a' || str[i] == 'e' || str[i] == 'i' || str[i] == 'o' || str[i] == 'u' || 
            str[i] == 'A' || str[i] == 'E' || str[i] == 'I' || str[i] == 'O' || str[i] == 'U') {
            nguyenam++;
        }
    }

    printf("\nSo luong nguyen am trong chuoi la: %d\n", nguyenam);
    return 0;
}

