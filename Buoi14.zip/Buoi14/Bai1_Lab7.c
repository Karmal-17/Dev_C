#include <stdio.h>
#include <string.h>

int main (){
	char str[150];
	printf("\n Nhap Gia Tri Chuoi : ");
	gets(str);
	int i,songuyenam = 0,sophuam = 0;
	for (i = 0;str[i] != '\0';i++){
		if (str[i] == 'a' || str[i] == 'i' || str[i] == 'e' || str[i] == 'u' || str[i] == 'o' || str[i] == 'A' || str[i] == 'I' || str[i] == 'E' || str[i] == 'U' || str[i] == 'O'){
			songuyenam += 1;
		} else {
			sophuam += 1;
		}
	}
	printf("\n Gia Tri Chuoi %s Co So Luong Nguyen Am la : %d",str,songuyenam);
	printf("\n Gia Tri Chuoi %s Co So Luong Phu Am La: %d ",str,sophuam);
	return 0;
}
