#include <stdio.h>
#include <string.h>

int main(){
	char str1[30],str2[30];
	printf("\n Nhap Gia Tri Chuoi 1: ");
	gets(str1);
	printf("\n Nhap Gia Tri Chuoi 2: ");
	gets(str2);
	if (strstr (str1,str2) != NULL){
		printf("\n Tim Thay Gia Tri.");
	} else {
		printf("\n Khong Tim Thay.");
	}
	return 0;
}
