#include <stdio.h>
#include <string.h>

int main (){
	char str1[20],str2[20];
	printf("\n Nhap Gia Tri Chuoi 1: ");
	gets(str1);
	printf("\n Nhap Gia Tri Chuoi 2: ");
	gets(str2);
	
	if (strcmp (str1,str2) == 0){
		printf("\n Hai Chuoi Bang Nhau.");
	} else {
		if(strcmp (str1,str2) > 0){
			printf("\n Chuoi 1 Lon Hon Chuoi Hai.");
		} else {
			printf("\n Chuoi 1 Be Hon Chuoi Hai.");
		}
	}
	// Chuoi Dao Nguoc strrev(str1)
	printf("\n \n Chuoi 1 Da Nhap La: %s ",str1);
	printf("\n Dao Nguoc Chuoi 1 La: %s",strrev(str1));
	return 0;
}
