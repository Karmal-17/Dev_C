#include <stdio.h>
#include <string.h>
int main(){
	char Tinh_Cach[20];
	printf("Nhap Tinh Cach cua bn: ");
	scanf("%s", Tinh_Cach);
	printf("Ban vua nhap la: %s", Tinh_Cach);
	if(strcmp (Tinh_Cach, "Contien") == 0){
		printf("\n Vui Va Khong Bi Doi");
		printf("\n Muon Mua Cai Gi Cung Duoc");
		printf("\n Duoc Di Choi");
	}
	else {
		printf("\n Buon Va Bi Doi");
		printf("\n Khong Mua Duoc Cai Gi Ca");
		printf("\n Khong Duoc Di Dau Choi");
	}
	return 0;
}
