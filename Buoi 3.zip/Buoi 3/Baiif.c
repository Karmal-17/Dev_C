#include <stdio.h>
int main(){
// Neu tuoi > 16 thi in ra man hinh: "Duoc vao rap phim"
    int tuoi; //Khai bao bien
    printf("Nhap Tuoi Cua Ban Vao Day Nao: "); //In ra man hinh tuoi cua bn
    scanf("%d", &tuoi); // Nhap tuoi
    if(tuoi > 16 ){ //Xet dieu kien cua uoi co lon hon 16 hay 0
    	printf("Duoc vao rap chieu phim");
	} else {
		printf("Khong vao duoc rap chieu phim");
	}
    return 0;
}
