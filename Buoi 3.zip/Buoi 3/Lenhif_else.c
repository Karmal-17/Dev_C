#include <stdio.h>
#include <string.h>
int main(){
	char ThoiTiet[20];
	printf("Nhap troi: ");
	scanf("%s", ThoiTiet);
	printf("Ban vua nhap la: %s", ThoiTiet);
	if(strcmp(ThoiTiet, "Nang") == 0){
		printf("\n Di choi ngay va luon: ");
		printf("\n Khong o nha");
	}
	else {
		printf("\n O nha va di ngu: ");
		printf("\n khong di choi");
	}
	return 0;
}
