#include <stdio.h>
int main(){
	float a;
	printf("Ban Nhap so: ");
	scanf("%f", &a);
	printf("Ban Vua Nhap La: %f",a);
	if(a < 0 || a > 10){
		printf("\n Diem khong hop le!");
	}
	else if(a >= 8){
		printf("\n Duoc loai Gioi");
	}
	else if(a >= 7){
		printf("\n Duoc loai Kha");
	}
	else if(a >= 5){
		printf("\n Duoc loai Trung Binh");
    }
    else {
    	printf("\n Duoc loai Yeu");
	}
	return 0;
}
