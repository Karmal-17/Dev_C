#include <stdio.h>
 
void HienThi (int a, int b){
printf("\n Khang Cach So Tu %d va %d La: ",a,b);
int i; 
for (i = a+=1 ; i < b; i ++){
printf("%d  ",i);
}
}
void TinhToan (int a, int b){
	printf("\nTong Cua Hai So %d Va %d La: %d",a,b,a + b);
	printf("\nHieu Cua Hai So %d Va %d La: %d",a,b,a - b);
	printf("\nNhan Cua Hai So %d Va %d La: %d",a,b,a * b);
	printf("\nTrung Binh Cua Hai So %d Va %d La: %f",a,b,(float)(a + b)/2);
	printf("\nPhep Chia Cua Hai So %d Va %d La: %f",a,b,(float)a / b);
	}
int main(){
	int a , b;
	do {
	printf("\n Nhap Hai So Nguyen Ban Muon: ");
	scanf("%d %d",&a,&b);
	printf("\n Ban Vua Nhap So a: ",a);
	printf("\n Ban Vua Nhap So b: ",b);
	} while (int a,int b);
	HienThi(a,b);
	TinhToan(a,b);
	
	return 0;
	}

