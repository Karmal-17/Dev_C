#include <stdio.h>

// H�m hi?n th? menu
void hienThiMenu() {
    printf("===== MENU CHUC NANG =====\n");
    printf("1. Tinh Cong Tru Nhan Chia hai so.\n");
    printf("2. Kiem tra so chan le.\n");
    printf("3. Thoat chuong trinh.\n");
    printf("==========================\n");
    printf("Moi ban chon: ");
}

// H�m x? l� l?a ch?n
void xuLyLuaChon(int luaChon) {
    switch(luaChon) {
        case 1: {
            int a, b;
            printf("Nhap so thu nhat: ");
            scanf("%d", &a);
            printf("Nhap so thu hai: ");
            scanf("%d", &b);
            printf("Tong hai so la: %d\n", a + b);
            printf("Hieu Hai So La: %d\n", a - b);
            printf("Tich Hai So La: %d\n", a * b);
            printf("Chia Hai So la: %f\n", (float)a / b);
            break;
        }
        case 2: {
            int so;
            printf("Nhap mot so: ");
            scanf("%d", &so);
            if (so % 2 == 0) {
                printf("%d la so chan.\n", so);
            } else {
                printf("%d la so le.\n", so);
            }
            break;
        }
        case 3:
            printf("Thoat chuong trinh.\n");
            break;
        default:
            printf("Lua chon khong hop le, vui long thu lai.\n");
    }
}

int main() {
    int luaChon;
    do {
        hienThiMenu();
        scanf("%d", &luaChon);
        xuLyLuaChon(luaChon);
    } while(luaChon != 3); // Tho�t khi ch?n 3
    return 0;
}


