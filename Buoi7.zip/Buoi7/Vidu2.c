#include <stdio.h>

void Tong(int a, int b){
	int tong = a + b;
    printf("Tong Cua %d Va %d La: %d\n",a,b,tong);
    }
void TrungBinh(int a, int b){
	float Tb = (float)(a + b)/2;
	printf("Trung Binh Cua %d Va %d La: %f\n",a,b,Tb);
	}
int main(){
	int a , b;
	printf("Nhap Hai So Nguyen: ");
	scanf("%d %d",&a,&b);
	Tong(a,b);
	TrungBinh(a,b);
	
	}
