#include <stdio.h>

void HienThi(int a, int b) {
    printf("\nKho?ng c�ch gi?a c�c s? t? %d d?n %d l�: ", a, b);
    int i; 
    for (i = a + 1; i < b; i++) {
        printf("%d ", i);
    }
    printf("\n");
}

void TinhToan(int a, int b) {
    printf("\nT?ng c?a hai s? %d v� %d l�: %d", a, b, a + b);
    printf("\nHi?u c?a hai s? %d v� %d l�: %d", a, b, a - b);
    printf("\nT�ch c?a hai s? %d v� %d l�: %d", a, b, a * b);
    printf("\nTrung b�nh c?a hai s? %d v� %d l�: %.2f", a, b, (float)(a + b) / 2);
    if (b != 0) {
        printf("\nPh�p chia c?a hai s? %d v� %d l�: %.2f", a, b, (float)a / b);
    } else {
        printf("\nKh�ng th? th?c hi?n ph�p chia v� b = 0.");
    }
    printf("\n");
}

int main() {
    int a, b;
    char tiepTuc;

    do {
        // Y�u c?u nh?p hai s? nguy�n
        printf("\nNh?p hai s? nguy�n b?n mu?n (a v� b): ");
        scanf("%d %d", &a, &b);

        // Hi?n th? v� t�nh to�n
        HienThi(a, b);
        TinhToan(a, b);

        // H?i ngu?i d�ng c� mu?n ti?p t?c hay kh�ng
        printf("\nB?n c� mu?n ti?p t?c kh�ng? (y/n): ");
        scanf(" %c", &tiepTuc);

    } while (tiepTuc == 'y' || tiepTuc == 'Y');

    printf("\nChuong tr�nh k?t th�c. C?m on b?n!\n");
    return 0;
}

