#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

void setColor(int color) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
}

void hienThiMenu() {
    setColor(14);
    printf("\n+--------------------------+\n");
    printf("�      MENU CHUC NANG      �\n");
    printf("�--------------------------�\n");
    printf("� 1. Tinh tong hai so.     �\n");
    printf("� 2. Kiem tra so chan le.  �\n");
    printf("� 3. Luu danh sach vao file�\n");
    printf("� 4. Doc danh sach tu file �\n");
    printf("� 5. Thoat chuong trinh.   �\n");
    printf("+--------------------------+\n");
    setColor(7);
    printf("Moi ban chon: ");
}

int nhapSoNguyen() {
    int so;
    while (scanf("%d", &so) != 1) {
        printf("Dau vao khong hop le! Vui long nhap so nguyen: ");
        while (getchar() != '\n');
    }
    return so;
}

void tinhTong() {
    int a, b;
    printf("Nhap so thu nhat: ");
    a = nhapSoNguyen();
    printf("Nhap so thu hai: ");
    b = nhapSoNguyen();
    printf("Tong hai so la: %d\n", a + b);
}

void kiemTraChanLe() {
    int so;
    printf("Nhap mot so: ");
    so = nhapSoNguyen();
    if (so % 2 == 0) {
        printf("%d la so chan.\n", so);
    } else {
        printf("%d la so le.\n", so);
    }
}

void luuDanhSach(int arr[], int n) {
    FILE *file = fopen("danhSach.txt", "w");
    if (file == NULL) {
        printf("Khong the mo file de ghi!\n");
        return;
    }
    int i;
    for (i = 0; i < n; i++) {
        fprintf(file, "%d\n", arr[i]);
    }
    fclose(file);
    printf("Danh sach da duoc luu vao file 'danhSach.txt'.\n");
}

void docDanhSach(int arr[], int *n) {
    FILE *file = fopen("danhSach.txt", "r");
    if (file == NULL) {
        printf("Khong the mo file de doc!\n");
        return;
    }
    *n = 0;
    while (fscanf(file, "%d", &arr[*n]) != EOF) {
        (*n)++;
    }
    fclose(file);
    printf("Danh sach da duoc doc tu file 'danhSach.txt'.\n");
}

int main() {
    int luaChon, arr[100], n = 0;
    do {
        hienThiMenu();
        luaChon = nhapSoNguyen();
        switch(luaChon) {
            case 1:
                tinhTong();
                break;
            case 2:
                kiemTraChanLe();
                break;
            case 3:
                if (n == 0) {
                    printf("Danh sach rong, khong co gi de luu!\n");
                } else {
                    luuDanhSach(arr, n);
                }
                break;
            case 4:
                docDanhSach(arr, &n);
                break;
            case 5:
                printf("Thoat chuong trinh\n");
                break;
            default:
                printf("Lua chon khong hop le.\n");
        }
    } while(luaChon != 5);
    return 0;
}

