#include <stdio.h>

// 1. Ham Khong Co Tham So , Khong Tra Ve (Khong Co Reaturn)
void Thongtin (){
	printf("\n Ten: Nghiepnd");
	printf("\n Ma So Sv: TG00418");
}	
// 2. Ham Co Tham So , Khong Tra Ve ( Khong Co Return)
void Hienthi(int a, int b, int c){
	printf("%d %d %d ", a, b, c);
	}
// 3. Ham Co Tham So , Co Gia Tri Tra Ve
int tong(int a, int b){
	return a + b;
}
int main(){
	// Goi Ham Thong Tin()
	Thongtin();
	printf("\n Thong Tin Cua Toi La: ");
	Thongtin();
	printf("\n----------------------\n");
	
	int m = 100, n = 200, p = 500;
	Hienthi(m,n,p);
	Hienthi(0,5,m);
	printf("\n ------------\n");
	
	printf("Tong Cua 2 Va 3 La: %d\n",tong(2,3));
	int sum = tong(m,n);
	printf("Tong Cua %d Va %d La: %d\n",m,n,sum);
	
}	
