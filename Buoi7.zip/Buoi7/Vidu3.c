#include <stdio.h>

void HienThi( int a, int b){
	printf("Cac So Nam Trong Khoang %d va %d La: ",a,b);
    int i;
	for ( i = a; i <= b;i++){
	printf("%d  ",i);
		}
}
int main(){
	int a, b;
	printf("Nhap Hai So Nguyen: ");
	scanf("%d %d", &a, &b);
	HienThi(a,b);
	return 0;
	}
